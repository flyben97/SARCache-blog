"""Qwen-Image-2.1 (diffusers ``QwenImage21Transformer2DModel``) as a resolution-agnostic velocity model.

Facts from the diffusers implementation (``references/transformer_qwenimage21.py``) that the adapter relies on:
  * latents are unpatched (``patch_size=1``, 64 channels, 16x VAE): a 2048^2 image has 128x128 = 16384 target tokens,
    a 512^2 coarse view 32x32 = 1024; the joint sequence reserves one slot per 2x2 target tokens;
  * ``timestep`` is sigma in [0, 1]; the pipeline rounds ``sigma * 1000`` to the latent dtype before dividing;
  * attention is block-causal and text tokens modulate from t = 0, and the text RoPE positions precede the target
    block. The text prefix K/V therefore depend neither on the timestep nor on the target resolution, so one prefix
    cache, filled by the first call, is exact for both branches (verified by the smoke test).

``coarse_positions``:
  ``native``  the coarse grid gets the model's own centred integer grid (what the model saw at that resolution);
  ``aligned`` coarse cell centres are placed at their full-resolution coordinates (fractional RoPE positions).
"""
from __future__ import annotations

from contextlib import contextmanager
from types import MethodType

import torch


def pack(x: torch.Tensor) -> torch.Tensor:
    b, c, h, w = x.shape
    return x.reshape(b, c, h * w).transpose(1, 2)


def unpack(tokens: torch.Tensor, h: int, w: int) -> torch.Tensor:
    b, _, c = tokens.shape
    return tokens.transpose(1, 2).reshape(b, c, h, w)


def pipeline_timestep(sigma: float, batch: int, dtype: torch.dtype, device) -> torch.Tensor:
    t = torch.tensor(sigma, dtype=torch.float32) * 1000.0
    return t.expand(batch).to(device=device, dtype=dtype) / 1000


def centred_positions(n: int) -> torch.Tensor:
    return torch.arange(-(n - n // 2), n // 2, dtype=torch.float64)


def aligned_positions(n_coarse: int, factor: int) -> torch.Tensor:
    """Centres of coarse cells on the full-resolution centred grid."""
    n_full = n_coarse * factor
    start = -(n_full - n_full // 2)
    return start + factor * torch.arange(n_coarse, dtype=torch.float64) + (factor - 1) / 2.0


def _axis_freqs(pos: torch.Tensor, dim: int, theta: float) -> torch.Tensor:
    inv = 1.0 / torch.pow(theta, torch.arange(0, dim, 2, dtype=torch.float64) / dim)
    ang = torch.outer(pos, inv)
    return torch.polar(torch.ones_like(ang), ang).to(torch.complex64)


@contextmanager
def aligned_rope(transformer, h: int, w: int, factor: int):
    """Temporarily overwrite the height/width rotary rows of the target block with full-grid coordinates."""
    rope = transformer.pos_embed
    original = rope.forward
    d_frame, d_h, d_w = (int(d) for d in rope.axes_dim)
    hp = aligned_positions(h, factor)
    wp = aligned_positions(w, factor)

    def forward(self, img_shapes, image_pad_mask, device):
        out = original(img_shapes, image_pad_mask, device).clone()
        rows = image_pad_mask.nonzero(as_tuple=True)[0][-h * w:]
        fh = _axis_freqs(hp, d_h, self.theta).to(device)
        fw = _axis_freqs(wp, d_w, self.theta).to(device)
        grid_h = fh[:, None, :].expand(h, w, -1).reshape(h * w, -1)
        grid_w = fw[None, :, :].expand(h, w, -1).reshape(h * w, -1)
        a, b = d_frame // 2, d_frame // 2 + d_h // 2
        out[rows, a:b] = grid_h.to(out.dtype)
        out[rows, b:] = grid_w.to(out.dtype)
        return out

    rope.forward = MethodType(forward, rope)
    try:
        yield
    finally:
        rope.forward = original


class QwenImage21Adapter:
    def __init__(self, transformer, prompt_embeds: torch.Tensor, prompt_embeds_mask: torch.Tensor | None = None,
                 image_pad_mask: torch.Tensor | None = None, negative: tuple | None = None,
                 true_cfg_scale: float = 1.0, coarse_positions: str = "native", use_kv_cache: bool = True,
                 latent_dtype: torch.dtype | None = None):
        from diffusers.models.transformers.transformer_qwenimage21 import QwenImage21KVCache

        if coarse_positions not in ("native", "aligned"):
            raise ValueError("coarse_positions must be 'native' or 'aligned'")
        self.transformer = transformer
        self._cache_cls = QwenImage21KVCache
        self.dtype = latent_dtype or prompt_embeds.dtype
        self.cond = self._condition(prompt_embeds, prompt_embeds_mask, image_pad_mask)
        self.neg = self._condition(*negative) if negative is not None else None
        self.cfg = float(true_cfg_scale)
        if self.cfg > 1.0 and self.neg is None:
            raise ValueError("true_cfg_scale > 1 needs negative embeddings")
        self.coarse_positions = coarse_positions
        self.use_kv_cache = use_kv_cache and bool(transformer.config.causal_condition)
        self.latent_channels = int(transformer.config.in_channels)
        # Extra CacheContext fields (step_index / sigma / num_inference_steps) attached to every
        # transformer call; the official SeaCache hook requires them. Empty = previous behaviour.
        self.cache_context_extras: dict = {}
        self.begin()

    @staticmethod
    def _condition(embeds, mask=None, pad_mask=None):
        if pad_mask is None:
            pad_mask = torch.zeros(embeds.shape[:2], dtype=torch.bool, device=embeds.device)
        if mask is not None and bool(mask.all()):
            mask = None
        return {"embeds": embeds, "mask": mask, "pad": pad_mask}

    def begin(self):
        n = len(self.transformer.transformer_blocks)
        self._caches = {}
        for name, cond in (("cond", self.cond), ("uncond", self.neg)):
            if cond is not None:
                self._caches[name] = self._cache_cls(n) if self.use_kv_cache else None
        self._filled = {name: False for name in self._caches}

    def text_condition(self) -> dict:
        """ADDED for draft distillation (sarcache/distill.py): expose the cached conditional text
        embeddings so data generation can persist them (avoiding a re-encode at train time).

        Returns the cond-branch dict ``{"embeds": (1, L, D), "mask": (1, L) bool or None,
        "pad": (1, L) bool}`` exactly as the adapter uses it internally."""
        return self.cond

    def _forward(self, name, cond, hs, timestep, h, w):
        b = hs.shape[0]
        img_mask = torch.cat([cond["pad"], cond["pad"].new_ones(cond["pad"].shape[0], h * w // 4)], dim=1)
        cache = self._caches[name]
        mode = None if cache is None else ("cached" if self._filled[name] else "extract")
        with self.transformer.cache_context(name, **self.cache_context_extras):
            out = self.transformer(
                hidden_states=hs, timestep=timestep, encoder_hidden_states=cond["embeds"],
                encoder_hidden_states_mask=cond["mask"], img_shapes=[[(1, h, w)]] * b, img_mask=img_mask,
                kv_cache=cache, kv_cache_mode=mode, return_dict=False,
            )[0]
        if cache is not None:
            self._filled[name] = True
        return out[:, -h * w:]

    def probe_parts(self, x: torch.Tensor, sigma: float) -> tuple[torch.Tensor, torch.Tensor]:
        """The two factors of the TeaCache probe, separately: ``(normed, scale)``.

        ``normed = img_norm1(img_in(hs))`` is the un-modulated block-0 input and ``scale`` the shared
        timestep modulation row. ``probe = normed * (1 + scale)`` reproduces the model's actual block-0
        attention input (``QwenImage21TransformerBlock._modulate``, vendored diffusers line 608-614:
        ``hidden_states * (1 + scale)`` with ``mod1, mod2 = modulation.chunk(2, dim=-1)`` and
        ``scale, gate = mod1.chunk(2, dim=-1)``). Exposed separately for the E-detrend diagnostic: on
        Qwen-Image-2.1 the ``(1 + scale)`` factor is a near-deterministic function of sigma, so the
        relative change of the product is dominated by the timestep trend rather than by the content.
        """
        b, c, h, w = x.shape
        tf = self.transformer
        hs = pack(x.to(self.dtype))
        timestep = pipeline_timestep(sigma, b, self.dtype, x.device)
        if tf.config.causal_condition:
            timestep = torch.cat([timestep, timestep.new_zeros(1)], dim=0)
        temb = tf.time_text_embed(timestep, hs)
        modulation = tf.modulation(temb)                      # [B(+1), 4*dim] or [B(+1), 1, 4*dim]
        mod1 = modulation.chunk(2, dim=-1)[0]
        scale = mod1.chunk(2, dim=-1)[0][:b]                  # target tokens read the sampled-t rows
        if scale.dim() == 2:
            scale = scale.unsqueeze(1)
        normed = tf.transformer_blocks[0].img_norm1(tf.img_in(hs))
        return normed, scale

    def probe(self, x: torch.Tensor, sigma: float) -> torch.Tensor:
        """TeaCache signal: the block-0 AdaLN-modulated input of the target tokens.

        Cheap (input projections + time embedding + one LayerNorm, no attention/MLP). Per-token LayerNorm
        and the per-sample modulation rows make the text prefix irrelevant here: target tokens read the
        sampled-timestep modulation row.
        """
        normed, scale = self.probe_parts(x, sigma)
        return normed * (1 + scale)

    # --- FBCache (FirstBlockCache) interface: the cheap per-step signal is the block-0 *output* of the
    # target tokens; the cached quantity is the hidden-space residual (last-block output - block-0 output),
    # reused by adding it to the current block-0 output before norm_out/proj_out. All three entry points
    # require true_cfg_scale == 1 (single branch); block outputs are sliced to the last h*w tokens, which
    # covers both the prefill layout (target last) and the KV-decode layout (target only).

    def fb_first(self, x: torch.Tensor, sigma: float) -> torch.Tensor:
        """Cheap pass: run the shared front + block 0 (prefix KV-cached) and return its target-token output."""
        if self.cfg != 1.0:
            raise ValueError("fbcache needs true_cfg_scale == 1.0")
        b, c, h, w = x.shape
        hs = pack(x.to(self.dtype))
        timestep = pipeline_timestep(sigma, b, self.dtype, x.device)
        captured = {}

        def hook(module, args, kwargs, output):
            captured["h0"] = output[:, -h * w:]
            raise _AbortBlocks()

        handle = self.transformer.transformer_blocks[0].register_forward_hook(hook, with_kwargs=True)
        try:
            self._forward("cond", self.cond, hs, timestep, h, w)
        except _AbortBlocks:
            pass
        finally:
            handle.remove()
        return captured["h0"]

    def fb_full(self, x: torch.Tensor, sigma: float):
        """Full forward capturing block-0 and last-block outputs; returns (velocity, h0, hN - h0)."""
        if self.cfg != 1.0:
            raise ValueError("fbcache needs true_cfg_scale == 1.0")
        b, c, h, w = x.shape
        hs = pack(x.to(self.dtype))
        timestep = pipeline_timestep(sigma, b, self.dtype, x.device)
        captured = {}
        blocks = self.transformer.transformer_blocks

        def hook0(module, args, kwargs, output):
            captured["h0"] = output[:, -h * w:]

        def hookN(module, args, kwargs, output):
            captured["hN"] = output[:, -h * w:]

        handles = [blocks[0].register_forward_hook(hook0, with_kwargs=True),
                   blocks[-1].register_forward_hook(hookN, with_kwargs=True)]
        try:
            out = self._forward("cond", self.cond, hs, timestep, h, w)
        finally:
            for handle in handles:
                handle.remove()
        return unpack(out, h, w), captured["h0"], captured["hN"] - captured["h0"]

    def fb_reuse(self, x: torch.Tensor, sigma: float, h0: torch.Tensor, residual: torch.Tensor) -> torch.Tensor:
        """Reuse pass: current block-0 output + stale hidden residual, then norm_out/proj_out."""
        if self.cfg != 1.0:
            raise ValueError("fbcache needs true_cfg_scale == 1.0")
        b, c, h, w = x.shape
        tf = self.transformer
        hs = pack(x.to(self.dtype))
        timestep = pipeline_timestep(sigma, b, self.dtype, x.device)
        if tf.config.causal_condition:
            timestep = torch.cat([timestep, timestep.new_zeros(1)], dim=0)
        # target tokens read their own sample's modulation row (the real-timestep rows, not the t=0 row)
        temb = tf.time_text_embed(timestep, hs)[:b]
        out = tf.proj_out(tf.norm_out(h0 + residual, temb, None))
        return unpack(out, h, w)

    # --- Whole-stack hidden-residual interface (official TeaCache / EasyCache form): the cached quantity is
    # the hidden-space residual (last-block output - img_in output) of the target tokens; reuse adds it to the
    # *current* img_in output before norm_out/proj_out, so a reuse step still sees the current x_t. img_in is
    # timestep-independent, so the stack input can be read without running the transformer.

    def embed(self, x: torch.Tensor) -> torch.Tensor:
        """Stack input of the target tokens: ``img_in`` applied to the packed latents (cheap, no transformer)."""
        b, c, h, w = x.shape
        return self.transformer.img_in(pack(x.to(self.dtype)))

    def embed_full(self, x: torch.Tensor, sigma: float):
        """Full forward capturing the last-block output; returns (velocity, embed, hN - embed)."""
        if self.cfg != 1.0:
            raise ValueError("embed_full needs true_cfg_scale == 1.0")
        b, c, h, w = x.shape
        hs = pack(x.to(self.dtype))
        timestep = pipeline_timestep(sigma, b, self.dtype, x.device)
        emb = self.transformer.img_in(hs)
        captured = {}

        def hookN(module, args, kwargs, output):
            captured["hN"] = output[:, -h * w:]

        handle = self.transformer.transformer_blocks[-1].register_forward_hook(hookN, with_kwargs=True)
        try:
            out = self._forward("cond", self.cond, hs, timestep, h, w)
        finally:
            handle.remove()
        hN = captured["hN"]
        # decode layout: block input rows are exactly img_in(hs); prefill layout: the target rows of the joint
        # sequence are the same img_in rows (target tokens are the sequence suffix), so hN - emb is exact both ways.
        if hN.shape != emb.shape:
            raise AssertionError(f"last-block target output {tuple(hN.shape)} != img_in output {tuple(emb.shape)}")
        return unpack(out, h, w), emb, hN - emb

    def embed_reuse(self, x: torch.Tensor, sigma: float, residual: torch.Tensor) -> torch.Tensor:
        """Reuse pass: current img_in output + stale hidden residual, then norm_out/proj_out."""
        if self.cfg != 1.0:
            raise ValueError("embed_reuse needs true_cfg_scale == 1.0")
        b, c, h, w = x.shape
        tf = self.transformer
        hs = pack(x.to(self.dtype))
        timestep = pipeline_timestep(sigma, b, self.dtype, x.device)
        if tf.config.causal_condition:
            timestep = torch.cat([timestep, timestep.new_zeros(1)], dim=0)
        emb = tf.img_in(hs)
        if residual.shape != emb.shape:
            raise AssertionError(f"cached residual {tuple(residual.shape)} != embed {tuple(emb.shape)}")
        # target tokens read their own sample's modulation row (the real-timestep rows, not the t=0 row)
        temb = tf.time_text_embed(timestep, hs)[:b]
        out = tf.proj_out(tf.norm_out(emb + residual, temb, None))
        return unpack(out, h, w)

    def partial_forward(self, x: torch.Tensor, sigma: float, mask: torch.Tensor) -> torch.Tensor:
        """spec_tok token-level partial refresh: Krea 2 Raw only for now.

        Qwen-Image-2.1's block-causal layout with the text-prefix KV cache needs its own variant
        (the prefix cache is exact, but partial target-token forwards inside the block-causal
        attention have no equivalent of Krea's joint full-attention K/V injection), so the
        predictor is rejected here rather than silently approximated.
        """
        raise NotImplementedError("partial_forward (spec_tok) is implemented for Krea 2 Raw only")

    def __call__(self, x: torch.Tensor, sigma: float, role: str = "full", factor: int = 1) -> torch.Tensor:
        b, c, h, w = x.shape
        if (h * w) % 4:
            raise ValueError(f"Qwen-Image-2.1 needs an even number of 2x2 slots, got grid {h}x{w}")
        hs = pack(x.to(self.dtype))
        timestep = pipeline_timestep(sigma, b, self.dtype, x.device)
        use_aligned = role == "coarse" and factor > 1 and self.coarse_positions == "aligned"
        ctx = aligned_rope(self.transformer, h, w, factor) if use_aligned else _null()
        with ctx:
            out = self._forward("cond", self.cond, hs, timestep, h, w)
            if self.cfg > 1.0:
                neg = self._forward("uncond", self.neg, hs, timestep, h, w)
                out = neg + self.cfg * (out - neg)
        return unpack(out, h, w)


class _AbortBlocks(Exception):
    """Internal control flow: abort the transformer forward right after block 0 (FBCache cheap pass)."""


@contextmanager
def _null():
    yield
