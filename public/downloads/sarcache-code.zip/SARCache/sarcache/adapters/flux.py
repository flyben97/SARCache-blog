"""FLUX.1 (diffusers ``FluxTransformer2DModel``) as a resolution-agnostic velocity model.

Spatial latents ``[B, 16, H, W]`` (8x VAE) are packed into 2x2 tokens exactly like ``FluxPipeline._pack_latents``;
``img_ids`` carry (0, row, col) token coordinates, which are floats, so ``aligned`` coarse positions are exact.
FLUX.1-dev is guidance-distilled: ``guidance_scale`` feeds the guidance embedding, not a CFG batch.
"""
from __future__ import annotations

import torch

from .qwenimage21 import pipeline_timestep


def pack(x: torch.Tensor) -> torch.Tensor:
    b, c, h, w = x.shape
    x = x.view(b, c, h // 2, 2, w // 2, 2).permute(0, 2, 4, 1, 3, 5)
    return x.reshape(b, (h // 2) * (w // 2), c * 4)


def unpack(tokens: torch.Tensor, h: int, w: int) -> torch.Tensor:
    b, _, ch = tokens.shape
    x = tokens.view(b, h // 2, w // 2, ch // 4, 2, 2).permute(0, 3, 1, 4, 2, 5)
    return x.reshape(b, ch // 4, h, w)


def image_ids(th: int, tw: int, factor: int = 1, aligned: bool = False, device=None, dtype=torch.float32):
    rows = torch.arange(th, dtype=torch.float64)
    cols = torch.arange(tw, dtype=torch.float64)
    if aligned and factor > 1:
        rows = factor * rows + (factor - 1) / 2.0
        cols = factor * cols + (factor - 1) / 2.0
    ids = torch.zeros(th, tw, 3, dtype=torch.float64)
    ids[..., 1] = rows[:, None]
    ids[..., 2] = cols[None, :]
    return ids.reshape(th * tw, 3).to(device=device, dtype=dtype)


class FluxAdapter:
    def __init__(self, transformer, prompt_embeds: torch.Tensor, pooled_prompt_embeds: torch.Tensor,
                 text_ids: torch.Tensor | None = None, guidance_scale: float = 3.5, negative: tuple | None = None,
                 true_cfg_scale: float = 1.0, coarse_positions: str = "native",
                 latent_dtype: torch.dtype | None = None):
        if coarse_positions not in ("native", "aligned"):
            raise ValueError("coarse_positions must be 'native' or 'aligned'")
        self.transformer = transformer
        self.dtype = latent_dtype or prompt_embeds.dtype
        self.pe, self.pooled = prompt_embeds, pooled_prompt_embeds
        dev = prompt_embeds.device
        self.txt_ids = text_ids if text_ids is not None else torch.zeros(prompt_embeds.shape[1], 3, device=dev,
                                                                           dtype=self.dtype)
        self.neg = negative
        self.cfg = float(true_cfg_scale)
        if self.cfg > 1.0 and negative is None:
            raise ValueError("true_cfg_scale > 1 needs negative (embeds, pooled[, text_ids])")
        self.guidance_scale = guidance_scale
        self.coarse_positions = coarse_positions
        self.latent_channels = int(transformer.config.in_channels) // 4

    def _call(self, hs, timestep, guidance, pe, pooled, txt_ids, ids):
        return self.transformer(
            hidden_states=hs, timestep=timestep, guidance=guidance, pooled_projections=pooled,
            encoder_hidden_states=pe, txt_ids=txt_ids, img_ids=ids, return_dict=False,
        )[0]

    def __call__(self, x: torch.Tensor, sigma: float, role: str = "full", factor: int = 1) -> torch.Tensor:
        b, c, h, w = x.shape
        if h % 2 or w % 2:
            raise ValueError(f"FLUX packs 2x2 latents; grid {h}x{w} must be even")
        hs = pack(x.to(self.dtype))
        timestep = pipeline_timestep(sigma, b, self.dtype, x.device)
        guidance = None
        if self.transformer.config.guidance_embeds:
            guidance = torch.full([1], self.guidance_scale, device=x.device, dtype=torch.float32).expand(b)
        aligned = role == "coarse" and self.coarse_positions == "aligned"
        ids = image_ids(h // 2, w // 2, factor, aligned, device=x.device, dtype=self.dtype)
        out = self._call(hs, timestep, guidance, self.pe, self.pooled, self.txt_ids, ids)
        if self.cfg > 1.0:
            npe, npooled, *rest = self.neg
            ntxt = rest[0] if rest else self.txt_ids
            neg = self._call(hs, timestep, guidance, npe, npooled, ntxt, ids)
            out = neg + self.cfg * (out - neg)
        return unpack(out, h, w)
