"""Krea 2 Raw (diffusers ``Krea2Transformer2DModel``) as a resolution-agnostic velocity model.

Facts from the vendored diffusers implementation (``pipelines/krea2/pipeline_krea2.py``,
``models/transformers/transformer_krea2.py``) that the adapter relies on:
  * latents are spatial ``[B, C_lat, H, W]`` (f8 VAE, 16 ch at 1024px) and packed into ``patch_size``-square
    tokens by ``Krea2Pipeline._pack_latents``; the effective pixel-to-token factor is ``vae_scale_factor *
    patch_size`` (16 at patch 2). The transformer joint sequence is ``[text, image]``: text tokens sit at
    RoPE origin and carry a padding mask, image tokens carry integer ``(0, h, w)`` grid coordinates — the
    same layout family as FLUX, so the ``aligned`` coarse positions are exact (fractional rows/cols).
  * ``timestep`` is the flow time in [0, 1] (1 = pure noise); the sinusoidal embedding multiplies by 1e3
    internally (``Krea2TimestepEmbedding``), so the pipeline's ``t / num_train_timesteps`` equals sigma.
  * guidance follows the Krea convention: ``cond + guidance_scale * (cond - uncond)`` with CFG enabled
    whenever ``guidance_scale > 0`` (i.e. Krea's 3.5 corresponds to the usual CFG scale 4.5). The official
    recipe is cfg 3.5 at 52 steps; the official feature-level baselines run at cfg = 0 (single branch,
    the Krea analogue of their cfg == 1 requirement).
  * text conditioning is a stack of tapped text-encoder hidden states ``[B, L, num_text_layers, text_dim]``
    fused inside the transformer (``text_fusion`` + ``txt_in``); it is timestep- and resolution-independent,
    so the same tensors serve full and coarse forwards.

Coarse path: ``CoarseView`` hands the adapter a block-pooled latent on a coarser spatial grid; the adapter
packs it with the same ``patch_size`` and gives the model either its native integer grid (``native``) or the
full-grid cell centres as fractional coordinates (``aligned``), then returns the velocity on the coarse grid
so the view's lift maps it back. No prefix KV cache: unlike Qwen-Image's block-causal prefix, Krea's text
fusion is re-run per forward (it is part of the transformer stack).
"""
from __future__ import annotations

from contextlib import contextmanager

import torch
import torch.nn.functional as F


def pack(x: torch.Tensor, patch_size: int = 2) -> torch.Tensor:
    """``Krea2Pipeline._pack_latents``: spatial ``[B, C, H, W]`` -> packed ``[B, HW/p^2, C p^2]``."""
    p = patch_size
    b, c, h, w = x.shape
    if h % p or w % p:
        raise ValueError(f"Krea 2 packs {p}x{p} latents; grid {h}x{w} must be divisible by {p}")
    x = x.view(b, c, h // p, p, w // p, p).permute(0, 2, 4, 1, 3, 5)
    return x.reshape(b, (h // p) * (w // p), c * p * p)


def unpack(tokens: torch.Tensor, h: int, w: int, patch_size: int = 2) -> torch.Tensor:
    b, _, ch = tokens.shape
    p = patch_size
    x = tokens.view(b, h // p, w // p, ch // (p * p), p, p).permute(0, 3, 1, 4, 2, 5)
    return x.reshape(b, ch // (p * p), h, w)


def position_ids(text_len: int, grid_h: int, grid_w: int, factor: int = 1, aligned: bool = False,
                 device=None, dtype=torch.float32) -> torch.Tensor:
    """``(0, h, w)`` rotary rows: ``native`` integer grid or ``aligned`` full-grid cell centres."""
    rows = torch.arange(grid_h, dtype=torch.float64)
    cols = torch.arange(grid_w, dtype=torch.float64)
    if aligned and factor > 1:
        rows = factor * rows + (factor - 1) / 2.0
        cols = factor * cols + (factor - 1) / 2.0
    ids = torch.zeros(grid_h, grid_w, 3, dtype=torch.float64)
    ids[..., 1] = rows[:, None]
    ids[..., 2] = cols[None, :]
    image_ids = ids.reshape(grid_h * grid_w, 3)
    text_ids = torch.zeros(text_len, 3, dtype=torch.float64)
    return torch.cat([text_ids, image_ids], dim=0).to(device=device, dtype=dtype)


def krea_timestep(sigma: float, batch: int, dtype: torch.dtype, device) -> torch.Tensor:
    """``timestep = (t / 1000).expand(batch).to(dtype)`` with ``t = fp32(sigma) * 1000``.

    Mirrors the pipeline's arithmetic ORDER (pipeline_krea2.py: ``(t / num_train_timesteps)...
    .to(latents.dtype)``): the fp32 divide happens BEFORE the cast to the model dtype. The
    qwen/flux formula (cast ``sigma * 1000`` to the model dtype, then divide) rounds sigma*1000
    to bf16 first and shifts the sinusoidal time embedding by up to ~0.4% in bf16 — that broke
    GPU parity with rel_l2 0.12 while CPU fp32 stayed bitwise exact (state.md 8.28).
    """
    t = torch.tensor(sigma, dtype=torch.float32) * 1000.0
    return (t / 1000.0).expand(batch).to(device=device, dtype=dtype)


class Krea2Adapter:
    def __init__(self, transformer, prompt_embeds: torch.Tensor, prompt_embeds_mask: torch.Tensor | None = None,
                 negative: tuple | None = None, guidance_scale: float = 3.5, patch_size: int = 2,
                 coarse_positions: str = "native", latent_dtype: torch.dtype | None = None):
        if coarse_positions not in ("native", "aligned"):
            raise ValueError("coarse_positions must be 'native' or 'aligned'")
        self.transformer = transformer
        self.patch_size = int(patch_size)
        self.dtype = latent_dtype or prompt_embeds.dtype
        self.guidance = float(guidance_scale)
        self.use_cfg = self.guidance > 0.0
        if self.use_cfg and negative is None:
            raise ValueError("guidance_scale > 0 needs negative (embeds, mask)")
        if self.use_cfg:
            self.pe, self.mask = prompt_embeds, prompt_embeds_mask
            self._neg = negative
        else:
            self.pe, self.mask = prompt_embeds, prompt_embeds_mask
            self._neg = None
        self.coarse_positions = coarse_positions
        self.latent_channels = int(transformer.config.in_channels) // (self.patch_size ** 2)
        # Extra CacheContext fields (step_index / sigma / num_inference_steps) attached to every
        # transformer call; the official SeaCache hook requires them. Empty = previous behaviour.
        self.cache_context_extras: dict = {}
        self._cache_context_name: str | None = None
        self.begin()

    def text_condition(self) -> dict:
        """ADDED for draft distillation (sarcache/distill.py): expose the cached prompt embeddings
        so data generation can persist them (avoiding a re-encode at train time).

        Returns ``{"embeds": (1, L, n_layers, D), "mask": (1, L) bool or None, "pad": (1, L) bool}``
        — batch dim kept (gen_distill_data indexes ``[0]``); ``pad`` is an all-False placeholder
        (Krea has no VLM image slots)."""
        pad = torch.zeros(self.pe.shape[0], self.pe.shape[1], dtype=torch.bool,
                          device=self.pe.device)
        return {"embeds": self.pe, "mask": self.mask, "pad": pad}

    def begin(self):
        # spec_tok state: per-branch per-layer K/V cache (K post norm+RoPE, pre head-repeat, in the
        # joint [text, image] sequence order), its shape fingerprint, and the last committed
        # velocity (the copy source for unselected patches). Reset per trajectory and on any
        # resolution or shape change (see partial_forward).
        self._tok_kv: dict = {}
        self._tok_meta: dict = {}
        self._tok_committed: torch.Tensor | None = None

    def _cache_ctx(self, name: str):
        """``transformer.cache_context`` when the CacheMixin interface is installed (official_hooks),
        a no-op otherwise — the plain sampler path never installs the hook glue."""
        cache_context = getattr(self.transformer, "cache_context", None)
        if cache_context is None:
            return _null()
        return cache_context(name, **self.cache_context_extras)

    def _forward(self, hs: torch.Tensor, timestep: torch.Tensor, pos_ids: torch.Tensor) -> torch.Tensor:
        with self._cache_ctx(self._cache_context_name or "cond"):
            return self.transformer(
                hidden_states=hs, encoder_hidden_states=self.pe.to(self.dtype),
                timestep=timestep, position_ids=pos_ids,
                encoder_attention_mask=self.mask, return_dict=False,
            )[0]

    # --- Whole-stack hidden-residual interface (official TeaCache / EasyCache form): the cached quantity is
    # the hidden-space residual (last-block output - img_in output) of the image tokens; reuse adds it to the
    # *current* img_in output before final_layer, so a reuse step still sees the current x_t. img_in is
    # timestep-independent, so the stack input can be read without running the transformer. Block outputs are
    # the joint [text, image] sequence, so the captured tensors are sliced to the image rows.

    def probe_parts(self, x: torch.Tensor, sigma: float) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """The factors of the TeaCache probe, separately: ``(normed, prescale, preshift)``.

        ``normed = norm1(img_in(hs))`` is the un-modulated block-0 image-token input and ``prescale`` /
        ``preshift`` are the first two rows of the shared block-0 modulation
        (``temb_mod.unflatten(-1, (6, -1)) + scale_shift_table``, vendored transformer_krea2.py
        ``Krea2TransformerBlock.forward``). ``probe = normed * (1 + prescale) + preshift`` reproduces the
        model's actual block-0 attention input on the image rows (the modulation broadcasts over tokens, so
        the text prefix is irrelevant here). Cheap: input projection + time embedding, no attention/MLP.
        """
        b, c, h, w = x.shape
        p = self.patch_size
        tf = self.transformer
        hs = pack(x.to(self.dtype), p)
        timestep = krea_timestep(sigma, b, self.dtype, x.device)
        temb = tf.time_embed(timestep, dtype=hs.dtype)
        temb_mod = tf.time_mod_proj(F.gelu(temb, approximate="tanh"))  # (B, 1, 6*hidden)
        block0 = tf.transformer_blocks[0]
        modulation = temb_mod.unflatten(-1, (6, -1)) + block0.scale_shift_table
        prescale, preshift = modulation.unbind(-2)[:2]
        normed = block0.norm1(tf.img_in(hs))
        return normed, prescale, preshift

    def probe(self, x: torch.Tensor, sigma: float) -> torch.Tensor:
        """TeaCache signal: the block-0 AdaLN-modulated attention input of the image tokens."""
        normed, prescale, preshift = self.probe_parts(x, sigma)
        return normed * (1 + prescale) + preshift

    def embed(self, x: torch.Tensor) -> torch.Tensor:
        """Stack input of the image tokens: ``img_in`` applied to the packed latents (cheap, no transformer)."""
        b, c, h, w = x.shape
        return self.transformer.img_in(pack(x.to(self.dtype), self.patch_size))

    def embed_full(self, x: torch.Tensor, sigma: float):
        """Full forward capturing the last-block output; returns (velocity, embed, hN - embed)."""
        if self.guidance != 0.0:
            raise ValueError("embed_full needs guidance_scale == 0.0 (single denoising branch)")
        b, c, h, w = x.shape
        p = self.patch_size
        hs = pack(x.to(self.dtype), p)
        timestep = krea_timestep(sigma, b, self.dtype, x.device)
        pos_ids = position_ids(self.pe.shape[1], h // p, w // p, device=x.device, dtype=torch.float32)
        emb = self.transformer.img_in(hs)
        text_len = self.pe.shape[1]
        captured = {}

        def hookN(module, args, kwargs, output):
            captured["hN"] = output[:, text_len:]

        handle = self.transformer.transformer_blocks[-1].register_forward_hook(hookN, with_kwargs=True)
        try:
            out = self._forward(hs, timestep, pos_ids)
        finally:
            handle.remove()
        hN = captured["hN"]
        if hN.shape != emb.shape:
            raise AssertionError(f"last-block image output {tuple(hN.shape)} != img_in output {tuple(emb.shape)}")
        return unpack(out, h, w, p), emb, hN - emb

    def embed_reuse(self, x: torch.Tensor, sigma: float, residual: torch.Tensor) -> torch.Tensor:
        """Reuse pass: current img_in output + stale hidden residual, then final_layer."""
        if self.guidance != 0.0:
            raise ValueError("embed_reuse needs guidance_scale == 0.0 (single denoising branch)")
        b, c, h, w = x.shape
        p = self.patch_size
        tf = self.transformer
        hs = pack(x.to(self.dtype), p)
        timestep = krea_timestep(sigma, b, self.dtype, x.device)
        emb = tf.img_in(hs)
        if residual.shape != emb.shape:
            raise AssertionError(f"cached residual {tuple(residual.shape)} != embed {tuple(emb.shape)}")
        temb = tf.time_embed(timestep, dtype=hs.dtype)
        out = tf.final_layer(emb + residual, temb)
        return unpack(out, h, w, p)

    def __call__(self, x: torch.Tensor, sigma: float, role: str = "full", factor: int = 1) -> torch.Tensor:
        b, c, h, w = x.shape
        p = self.patch_size
        hs = pack(x.to(self.dtype), p)
        timestep = krea_timestep(sigma, hs.shape[0], self.dtype, x.device)
        aligned = role == "coarse" and self.coarse_positions == "aligned"
        pos_ids = position_ids(self.pe.shape[1], h // p, w // p, factor, aligned,
                               device=x.device, dtype=torch.float32)
        out = self._forward(hs, timestep, pos_ids)
        if self.use_cfg:
            # Two separate forwards, exactly like the official pipeline: the transformer's joint
            # attention-mask construction (cat of text pad mask and image ones) is not batch-CFG
            # safe, and parity is defined against the official per-branch calls.
            npe, npm = self._neg
            with self._cache_ctx("uncond"):
                neg = self.transformer(
                    hidden_states=hs, encoder_hidden_states=npe.to(self.dtype),
                    timestep=timestep, position_ids=pos_ids,
                    encoder_attention_mask=npm, return_dict=False,
                )[0]
            # Krea convention (pipeline line 666): cond + g * (cond - uncond), i.e. the usual
            # CFG scale is 1 + g (Krea's 3.5 == usual 4.5). Same arithmetic order as the pipeline.
            out = out + self.guidance * (out - neg)
        # Keep the model dtype (like the qwen/flux adapters): the sampler upcasts via acc(), and
        # the Euler update's bf16 product rounding then matches the official scheduler.step
        # bitwise; returning fp32 here would compute dt*v in fp32 and break bf16 GPU parity.
        out = unpack(out, h, w, p)
        self._tok_committed = out   # spec_tok: the copy source for unselected patches
        return out

    # --- Token-level partial refresh (spec_tok). Every step runs the joint [text, image] stack on
    # a SELECTED subset of image tokens; the unselected image tokens (and the text prefix) never
    # get queries -- they contribute their per-layer K/V, injected from a cache filled by the last
    # committed forward. Stale K/V is the core approximation of the mechanism.

    def partial_forward(self, x: torch.Tensor, sigma: float, mask: torch.Tensor) -> torch.Tensor:
        """Recompute the selected image tokens at full resolution; copy the rest from the committed velocity.

        ``mask``: bool ``[gh, gw]`` on the patch grid (``gh = H / patch_size``), True = recompute
        this patch's token this step. Selected tokens get fresh Q/K/V through the standard stack;
        every layer's attention then sees the full joint sequence -- cached (stale) K/V for text
        and unselected tokens, fresh for the selection (the key-padding mask covers the whole
        set). An all-true mask is exactly the regular full forward (bitwise) and rebuilds the K/V
        cache; an empty selection returns the committed velocity unchanged (pure frozen field).
        The cache and the committed velocity reset in ``begin()`` and on any shape change.
        """
        b, c, h, w = x.shape
        p = self.patch_size
        gh, gw = h // p, w // p
        if tuple(mask.shape) != (gh, gw):
            raise ValueError(f"spec_tok mask {tuple(mask.shape)} does not match the patch grid {(gh, gw)}")
        mask = mask.to(device=x.device, dtype=torch.bool).reshape(-1)
        sel = mask.nonzero(as_tuple=True)[0]
        committed = self._tok_committed
        full = bool(mask.all()) or committed is None or committed.shape != x.shape
        if sel.numel() == 0 and not full:
            return committed.clone()
        branches = [("cond", self.pe, self.mask)]
        if self.use_cfg:
            branches.append(("uncond", self._neg[0], self._neg[1]))
        hs = pack(x.to(self.dtype), p)
        timestep = krea_timestep(sigma, b, self.dtype, x.device)
        pos_ids = position_ids(self.pe.shape[1], gh, gw, device=x.device, dtype=torch.float32)
        outs = {name: self._tok_branch(name, hs, timestep, pos_ids, sel, full, pe, pm)
                for name, pe, pm in branches}
        out = outs["cond"]
        if self.use_cfg:
            # Krea convention, same arithmetic order as __call__: cond + g * (cond - uncond)
            out = out + self.guidance * (out - outs["uncond"])
        if full:
            v = unpack(out, h, w, p)
        else:
            toks = pack(committed, p)
            toks[:, sel] = out
            v = unpack(toks, h, w, p)
        self._tok_committed = v
        return v

    def _tok_branch(self, name, hs, timestep, pos_ids, sel, full, pe, pm):
        """One conditioning branch of a partial forward; returns image-token velocities.

        Full selection (or a cold/stale cache) runs the regular transformer forward and captures
        per-layer K/V from the to_k/to_v outputs -- post-norm/post-RoPE for K, pre head-repeat, in
        joint sequence order, exactly the quantities the attention processor attends with. A proper
        subset carries only the selected tokens through the stack (img_in -> blocks -> final_layer),
        replacing the cached K/V rows of the selection each layer.
        """
        from diffusers.models.attention_dispatch import dispatch_attention_fn
        from diffusers.models.transformers.transformer_krea2 import apply_rotary_emb

        b = hs.shape[0]
        tf = self.transformer
        text_len = pe.shape[1]
        n_img = hs.shape[1]
        rot = tf.rotary_emb(pos_ids)
        if pm is not None:
            am = torch.cat([pm, pm.new_ones((b, n_img))], dim=1)[:, None, None, :]
        else:
            am = None
        meta = (n_img, text_len, hs.device, hs.dtype)
        cache = self._tok_kv.get(name)
        if full or cache is None or self._tok_meta.get(name) != meta:
            captured = {}

            def cap(li, which):
                def hook(module, args, output):
                    captured[(li, which)] = output
                return hook

            hooks = []
            for li, blk in enumerate(tf.transformer_blocks):
                hooks.append(blk.attn.to_k.register_forward_hook(cap(li, "k")))
                hooks.append(blk.attn.to_v.register_forward_hook(cap(li, "v")))
            try:
                with self._cache_ctx(self._cache_context_name or name):
                    out = self.transformer(
                        hidden_states=hs, encoder_hidden_states=pe.to(self.dtype),
                        timestep=timestep, position_ids=pos_ids,
                        encoder_attention_mask=pm, return_dict=False,
                    )[0]
            finally:
                for hk in hooks:
                    hk.remove()
            layers = []
            for li, blk in enumerate(tf.transformer_blocks):
                attn = blk.attn
                k = captured[(li, "k")].unflatten(-1, (attn.num_kv_heads, attn.head_dim))
                k = attn.norm_k(k)
                k = apply_rotary_emb(k, rot, sequence_dim=1)
                v = captured[(li, "v")].unflatten(-1, (attn.num_kv_heads, attn.head_dim))
                layers.append({"k": k, "v": v})
            self._tok_kv[name] = layers
            self._tok_meta[name] = meta
            return out
        rows = text_len + sel                        # joint-sequence rows of the selection
        rot_sel = (rot[0][rows], rot[1][rows])
        temb = tf.time_embed(timestep, dtype=hs.dtype)
        temb_mod = tf.time_mod_proj(F.gelu(temb, approximate="tanh"))
        hsel = tf.img_in(hs.index_select(1, sel))
        for li, blk in enumerate(tf.transformer_blocks):
            attn = blk.attn
            ck, cv = cache[li]["k"], cache[li]["v"]
            modulation = temb_mod.unflatten(-1, (6, -1)) + blk.scale_shift_table
            prescale, preshift, pregate, postscale, postshift, postgate = modulation.unbind(-2)
            a_in = (1.0 + prescale) * blk.norm1(hsel) + preshift
            q = attn.to_q(a_in).unflatten(-1, (attn.num_heads, attn.head_dim))
            k = attn.to_k(a_in).unflatten(-1, (attn.num_kv_heads, attn.head_dim))
            v = attn.to_v(a_in).unflatten(-1, (attn.num_kv_heads, attn.head_dim))
            gate = attn.to_gate(a_in)
            q = attn.norm_q(q)
            k = attn.norm_k(k)
            q = apply_rotary_emb(q, rot_sel, sequence_dim=1)
            k = apply_rotary_emb(k, rot_sel, sequence_dim=1)
            kf = ck.clone()                        # full-sequence K/V: cached, selection overwritten
            vf = cv.clone()
            kf[:, rows] = k
            vf[:, rows] = v
            groups = attn.num_heads // attn.num_kv_heads
            if groups > 1:
                kf = kf.repeat_interleave(groups, dim=2)
                vf = vf.repeat_interleave(groups, dim=2)
            ao = dispatch_attention_fn(
                q, kf, vf, attn_mask=am,
                backend=attn.processor._attention_backend,
                parallel_config=attn.processor._parallel_config,
            )
            ao = ao.flatten(2, 3) * torch.sigmoid(gate)
            hsel = hsel + pregate * attn.to_out[0](ao)
            f_in = (1.0 + postscale) * blk.norm2(hsel) + postshift
            hsel = hsel + postgate * blk.ff(f_in)
            ck[:, rows] = k                        # commit fresh rows for the next step
            cv[:, rows] = v
        return tf.final_layer(hsel, temb)


@contextmanager
def _null():
    yield
