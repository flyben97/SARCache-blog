"""Sana (diffusers ``SanaTransformer2DModel``) as a resolution-agnostic velocity model.

Sana takes spatial latents directly (DC-AE, 32x), predicts flow velocity and, for 1.0 checkpoints, has no absolute
position embedding. The pipeline passes ``timestep = sigma * 1000 * timestep_scale`` and uses batched CFG.
"""
from __future__ import annotations

import torch


class SanaAdapter:
    def __init__(self, transformer, prompt_embeds: torch.Tensor, prompt_attention_mask: torch.Tensor,
                 negative: tuple | None = None, guidance_scale: float = 4.5,
                 latent_dtype: torch.dtype | None = None):
        self.transformer = transformer
        self.dtype = latent_dtype or next(transformer.parameters()).dtype
        self.cfg = float(guidance_scale) if negative is not None else 1.0
        if self.cfg > 1.0:
            self.pe = torch.cat([negative[0], prompt_embeds], dim=0)
            self.mask = torch.cat([negative[1], prompt_attention_mask], dim=0)
        else:
            self.pe, self.mask = prompt_embeds, prompt_attention_mask
        self.latent_channels = int(transformer.config.in_channels)

    def __call__(self, x: torch.Tensor, sigma: float, role: str = "full", factor: int = 1) -> torch.Tensor:
        inp = torch.cat([x, x], dim=0) if self.cfg > 1.0 else x
        t = torch.tensor(sigma, dtype=torch.float32) * 1000.0
        timestep = (t.expand(inp.shape[0]) * self.transformer.config.timestep_scale).to(x.device)
        out = self.transformer(
            inp.to(self.dtype), encoder_hidden_states=self.pe.to(self.dtype), encoder_attention_mask=self.mask,
            timestep=timestep, return_dict=False,
        )[0].float()
        if self.cfg > 1.0:
            uncond, cond = out.chunk(2)
            out = uncond + self.cfg * (cond - uncond)
        if self.transformer.config.out_channels // 2 == self.latent_channels:
            out = out.chunk(2, dim=1)[0]
        return out
