"""Analytic velocity fields for scientific checks (no network, no weights).

Data model: ``x0 = P z0 + h0`` on a full grid ``[C, f*hc, f*wc]`` with
  * ``z0`` a Gaussian mixture on the coarse grid (means ``m_k``, isotropic variance ``lam_z``),
  * ``h0 ~ N(0, lam_h (I - P R))`` independent block-zero-mean detail.

The *full* velocity ``E[eps - x0 | x_sigma]`` is computed directly in full space with the projector ``P R`` and the
full covariance (eigenvalue ``q lam_z`` on block-constant fields, ``lam_h`` on the complement). The *coarse* velocity
is the exact flow-matching velocity of the pooled data ``z0`` on the coarse grid, optionally with a deliberately
mismatched prior (``coarse_lam_z``, ``coarse_mean_shift``) to emulate the distribution gap of proposal Sec. 4.2.
Neither side uses the proposal's ``tau`` mapping, so ``G_aligned == P R F`` is a non-circular test of Sec. 4.1.
"""
from __future__ import annotations

import torch

from ..operators import pool, unpool


class SeparableGMMOracle:
    def __init__(self, means: torch.Tensor, weights: torch.Tensor | None = None, factor: int = 4,
                 lam_z: float = 0.25, lam_h: float = 0.05, coarse_lam_z: float | None = None,
                 coarse_mean_shift: float = 0.0):
        if means.ndim != 4:
            raise ValueError("means must be [K, C, hc, wc] on the coarse grid")
        self.m = means.double()
        k = means.shape[0]
        w = torch.full((k,), 1.0 / k, dtype=torch.float64) if weights is None else weights.double()
        self.log_pi = (w / w.sum()).log()
        self.factor = factor
        self.q = factor * factor
        self.lam_z, self.lam_h = float(lam_z), float(lam_h)
        self.c_lam = float(lam_z if coarse_lam_z is None else coarse_lam_z)
        self.c_m = self.m + coarse_mean_shift
        self.coarse_hw = tuple(means.shape[-2:])
        self.full_hw = (factor * self.coarse_hw[0], factor * self.coarse_hw[1])
        self.calls = {"full": 0, "coarse": 0}

    @classmethod
    def random(cls, channels: int = 4, coarse_hw=(4, 4), components: int = 6, factor: int = 4,
               mean_scale: float = 1.0, seed: int = 0, **kw) -> "SeparableGMMOracle":
        g = torch.Generator().manual_seed(seed)
        means = mean_scale * torch.randn(components, channels, *coarse_hw, generator=g, dtype=torch.float64)
        return cls(means, factor=factor, **kw)

    def sample_x0(self, n: int, generator: torch.Generator | None = None) -> torch.Tensor:
        k = torch.multinomial(self.log_pi.exp(), n, replacement=True, generator=generator)
        z0 = self.m[k] + self.lam_z ** 0.5 * torch.randn(n, *self.m.shape[1:], generator=generator,
                                                        dtype=torch.float64)
        g = torch.randn(n, self.m.shape[1], *self.full_hw, generator=generator, dtype=torch.float64)
        h0 = self.lam_h ** 0.5 * (g - unpool(pool(g, self.factor), self.factor))
        return unpool(z0, self.factor) + h0

    def begin(self):
        self.calls = {"full": 0, "coarse": 0}

    def __call__(self, x: torch.Tensor, sigma: float, role: str = "full", factor: int = 1) -> torch.Tensor:
        hw = tuple(x.shape[-2:])
        if hw == self.full_hw:
            self.calls["full"] += 1
            return self.full_velocity(x.double(), float(sigma)).to(x.dtype)
        if hw == self.coarse_hw:
            self.calls["coarse"] += 1
            return self.coarse_velocity(x.double(), float(sigma)).to(x.dtype)
        raise ValueError(f"oracle supports grids {self.full_hw} and {self.coarse_hw}, got {hw}")

    def _posterior(self, sq_dist: torch.Tensor) -> torch.Tensor:
        logits = self.log_pi[None] - 0.5 * sq_dist
        return torch.softmax(logits, dim=1)

    def full_velocity(self, x: torch.Tensor, sigma: float) -> torch.Tensor:
        f, one = self.factor, 1.0 - sigma
        mu = unpool(self.m, f)                                   # [K, C, H, W], block-constant
        c_s = one ** 2 * self.q * self.lam_z + sigma ** 2
        c_h = one ** 2 * self.lam_h + sigma ** 2
        d = x[:, None] - one * mu[None]                          # [B, K, C, H, W]
        low = unpool(pool(d.flatten(0, 1), f), f).view_as(d)
        high = d - low
        w = self._posterior(low.pow(2).flatten(2).sum(-1) / c_s)  # [B, K]
        e_eps = sigma * (low / c_s + high / c_h)
        e_x0 = mu[None] + one * (self.q * self.lam_z / c_s * low + self.lam_h / c_h * high)
        return (w[..., None, None, None] * (e_eps - e_x0)).sum(1)

    def coarse_velocity(self, y: torch.Tensor, tau: float) -> torch.Tensor:
        one = 1.0 - tau
        c = one ** 2 * self.c_lam + tau ** 2
        d = y[:, None] - one * self.c_m[None]
        w = self._posterior(d.pow(2).flatten(2).sum(-1) / c)
        e_xi = tau / c * d
        e_z0 = self.c_m[None] + one * self.c_lam / c * d
        return (w[..., None, None, None] * (e_xi - e_z0)).sum(1)
