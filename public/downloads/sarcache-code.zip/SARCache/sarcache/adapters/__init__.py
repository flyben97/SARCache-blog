from .oracle import SeparableGMMOracle

__all__ = ["SeparableGMMOracle", "QwenImage21Adapter", "FluxAdapter", "SanaAdapter"]


def __getattr__(name):
    if name == "QwenImage21Adapter":
        from .qwenimage21 import QwenImage21Adapter
        return QwenImage21Adapter
    if name == "FluxAdapter":
        from .flux import FluxAdapter
        return FluxAdapter
    if name == "SanaAdapter":
        from .sana import SanaAdapter
        return SanaAdapter
    raise AttributeError(name)
