"""Integration of the vendored diffusers (commit bdc2bea37a36038c44452811610489ea30ede229) official cache hooks
with the Qwen-Image-2.1 and Krea 2 adapters, for the official-baseline runs (R-Opus/04_BASELINE_FIX_ZH.md S2).

Three pieces of glue, none of which modifies the vendored diffusers (all runtime monkeypatches, installed once per
process by ``install_qwen21_hook_patches`` / ``install_krea2_hook_patches``):

1. ``hooks/_helpers.py`` only registers block metadata for Qwen-Image 1.0's ``QwenImageTransformerBlock``.
   ``QwenImage21TransformerBlock.forward`` returns a plain tensor (single stream, no encoder output), so the
   metadata is ``return_hidden_states_index=None, return_encoder_hidden_states_index=None``.
2. KV-cache layout trap: the adapter runs step 0 as a full prefill of the joint (text+image) sequence and later
   steps in KV-decode mode with target tokens only, so a cache hook sees different ``hidden_states`` token counts
   across steps. The target tokens are always the sequence suffix (the model appends the target image last), so
   the FBCache residual comparison/reuse is patched to align operands by suffix; MagCache's residual application
   is patched the same way (upstream only handles the "cached residual shorter than input" case). TaylorSeer and
   SeaCache handle the shape change themselves (taylorseer_cache.py restarts the expansion on a shape change;
   sea_cache.py fails open to a full compute), so they are used unpatched.
3. Per-image state reset goes through ``CacheMixin._reset_stateful_cache``; ``attach_official_cache`` /
   ``detach_official_cache`` wrap ``enable_cache`` / ``disable_cache``.
"""
from __future__ import annotations

import json
from pathlib import Path

import torch

DIFFUSERS_COMMIT = "bdc2bea37a36038c44452811610489ea30ede229"

HOOK_FAMILIES = ("fbcache_off", "taylorseer_off", "magcache_off", "seacache_off")

_PATCHED = False
_KREA2_PATCHED = False


def _suffix_align(a: torch.Tensor, b: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Align two [B, L, D] activations to their common token suffix (target tokens are the suffix of the joint
    prefill sequence; KV-decode passes contain target tokens only)."""
    if a.shape == b.shape:
        return a, b
    if a.ndim != 3 or b.ndim != 3 or a.shape[0] != b.shape[0] or a.shape[2] != b.shape[2]:
        raise AssertionError(f"cannot suffix-align {tuple(a.shape)} and {tuple(b.shape)}")
    n = min(a.shape[1], b.shape[1])
    return a[:, -n:], b[:, -n:]


def register_qwen21_block_metadata() -> bool:
    """Register ``QwenImage21TransformerBlock`` in diffusers' TransformerBlockRegistry. Returns True if the
    registration was added by this call (idempotent)."""
    from diffusers.hooks._helpers import TransformerBlockMetadata, TransformerBlockRegistry
    from diffusers.models.transformers.transformer_qwenimage21 import QwenImage21TransformerBlock

    try:
        TransformerBlockRegistry.get(QwenImage21TransformerBlock)
        return False
    except ValueError:
        pass
    TransformerBlockRegistry.register(
        model_class=QwenImage21TransformerBlock,
        metadata=TransformerBlockMetadata(
            return_hidden_states_index=None,      # forward returns a plain tensor, not a tuple
            return_encoder_hidden_states_index=None,
            hidden_states_argument_name="hidden_states",
        ),
    )
    return True


def register_krea2_block_metadata() -> bool:
    """Register ``Krea2TransformerBlock`` in diffusers' TransformerBlockRegistry. Returns True if the
    registration was added by this call (idempotent). Same metadata as Qwen-Image 2.1: the block is
    single-stream and returns a plain tensor."""
    from diffusers.hooks._helpers import TransformerBlockMetadata, TransformerBlockRegistry
    from diffusers.models.transformers.transformer_krea2 import Krea2TransformerBlock

    try:
        TransformerBlockRegistry.get(Krea2TransformerBlock)
        return False
    except ValueError:
        pass
    TransformerBlockRegistry.register(
        model_class=Krea2TransformerBlock,
        metadata=TransformerBlockMetadata(
            return_hidden_states_index=None,
            return_encoder_hidden_states_index=None,
            hidden_states_argument_name="hidden_states",
        ),
    )
    return True


def _ensure_krea2_cache_mixin() -> None:
    """Give ``Krea2Transformer2DModel`` the CacheMixin interface (vendored diffusers does not mix it in).
    Method binding, not a bases change: enable_cache/disable_cache/_reset_stateful_cache/cache_context
    are model-agnostic and operate on HookRegistry state only."""
    from diffusers.models.cache_utils import CacheMixin
    from diffusers.models.transformers.transformer_krea2 import Krea2Transformer2DModel

    if hasattr(Krea2Transformer2DModel, "enable_cache"):
        return
    Krea2Transformer2DModel._cache_config = None
    Krea2Transformer2DModel.is_cache_enabled = CacheMixin.is_cache_enabled
    Krea2Transformer2DModel.enable_cache = CacheMixin.enable_cache
    Krea2Transformer2DModel.disable_cache = CacheMixin.disable_cache
    Krea2Transformer2DModel._reset_stateful_cache = CacheMixin._reset_stateful_cache
    Krea2Transformer2DModel.cache_context = CacheMixin.cache_context


# --- FBCache patches (upstream: hooks/first_block_cache.py @ bdc2bea) -------------------------------------
#
# Upstream ``FBCHeadBlockHook._should_compute_remaining_blocks`` (lines 133-142) subtracts the stored residual
# from the current one; across the prefill->decode layout change the shapes differ and the subtraction would
# raise. The reuse branch of ``new_forward`` (lines 94-115) adds the cached tail residual to the current head
# output with the same problem. Both are patched with suffix alignment; the compute path is byte-identical to
# upstream.


def _fbc_should_compute_patched(self, hidden_states_residual: torch.Tensor) -> bool:
    shared_state = self.state_manager.get_state()
    if shared_state.head_block_residual is None:
        return True
    prev_hidden_states_residual = shared_state.head_block_residual
    current, prev = _suffix_align(hidden_states_residual, prev_hidden_states_residual)
    absmean = (current - prev).abs().mean()
    prev_hidden_states_absmean = prev.abs().mean()
    diff = (absmean / prev_hidden_states_absmean).item()
    return diff > self.threshold


def _fbc_head_new_forward_patched(self, module: torch.nn.Module, *args, **kwargs):
    original_hidden_states = self._metadata._get_parameter_from_args_kwargs("hidden_states", args, kwargs)

    output = self.fn_ref.original_forward(*args, **kwargs)
    is_output_tuple = isinstance(output, tuple)

    if is_output_tuple:
        hidden_states_residual = output[self._metadata.return_hidden_states_index] - original_hidden_states
    else:
        hidden_states_residual = output - original_hidden_states

    shared_state = self.state_manager.get_state()
    hidden_states = encoder_hidden_states = None
    should_compute = self._should_compute_remaining_blocks(hidden_states_residual)
    shared_state.should_compute = should_compute

    if not should_compute:
        # Apply caching (patched: suffix-align the cached tail residual against the current head output)
        out_hs = output[self._metadata.return_hidden_states_index] if is_output_tuple else output
        residual, out_hs = _suffix_align(shared_state.tail_block_residuals[0], out_hs)
        hidden_states = residual + out_hs

        if self._metadata.return_encoder_hidden_states_index is not None:
            assert is_output_tuple
            encoder_hidden_states = (
                shared_state.tail_block_residuals[1] + output[self._metadata.return_encoder_hidden_states_index]
            )

        if is_output_tuple:
            return_output = [None] * len(output)
            return_output[self._metadata.return_hidden_states_index] = hidden_states
            return_output[self._metadata.return_encoder_hidden_states_index] = encoder_hidden_states
            return_output = tuple(return_output)
        else:
            return_output = hidden_states
        output = return_output
    else:
        if is_output_tuple:
            head_block_output = [None] * len(output)
            head_block_output[0] = output[self._metadata.return_hidden_states_index]
            head_block_output[1] = output[self._metadata.return_encoder_hidden_states_index]
        else:
            head_block_output = output
        shared_state.head_block_output = head_block_output
        shared_state.head_block_residual = hidden_states_residual

    return output


# --- MagCache patch (upstream: hooks/mag_cache.py @ bdc2bea, MagCacheHeadHook.new_forward lines 184-280) -----
#
# Upstream handles "cached residual shorter than the block input" (Flux-style txt+img concat) but not the
# Qwen-2.1 KV case, where the cached residual comes from the joint prefill and is *longer* than the decode-step
# input: upstream then logs a warning and returns the block input unchanged (a silent zero-residual step). The
# patch suffix-aligns instead. The compute path and the gating arithmetic are byte-identical to upstream. With
# ``retention_step >= 2`` (enforced by ``attach_official_cache``) this branch is unreachable in practice, because
# the residual in use at the first skippable step already comes from a decode-step compute.


def _magcache_head_new_forward_patched(self, module: torch.nn.Module, *args, **kwargs):
    from diffusers.hooks.hooks import CacheContext

    if self.state_manager._context is None:
        self.state_manager.set_context(CacheContext(name="inference"))

    arg_name = self._metadata.hidden_states_argument_name
    hidden_states = self._metadata._get_parameter_from_args_kwargs(arg_name, args, kwargs)

    state = self.state_manager.get_state()
    state.head_block_input = hidden_states

    should_compute = True

    if self.config.calibrate:
        should_compute = True
    else:
        current_step = state.step_index
        if current_step >= len(self.config.mag_ratios):
            current_scale = 1.0
        else:
            current_scale = self.config.mag_ratios[current_step]

        retention_step = int(self.config.retention_ratio * self.config.num_inference_steps + 0.5)

        if current_step >= retention_step:
            state.accumulated_ratio *= current_scale
            state.accumulated_steps += 1
            state.accumulated_err += abs(1.0 - state.accumulated_ratio)

            if (
                state.previous_residual is not None
                and state.accumulated_err <= self.config.threshold
                and state.accumulated_steps <= self.config.max_skip_steps
            ):
                should_compute = False
            else:
                state.accumulated_ratio = 1.0
                state.accumulated_steps = 0
                state.accumulated_err = 0.0

    state.should_compute = should_compute

    if not should_compute:
        output = hidden_states
        res = state.previous_residual
        if res.device != output.device:
            res = res.to(output.device)
        # patched: suffix-align in both directions instead of only handling res shorter than output
        res, output = _suffix_align(res, output)
        output = output + res

        if self._metadata.return_encoder_hidden_states_index is not None:
            original_encoder_hidden_states = self._metadata._get_parameter_from_args_kwargs(
                "encoder_hidden_states", args, kwargs
            )
            max_idx = max(
                self._metadata.return_hidden_states_index, self._metadata.return_encoder_hidden_states_index
            )
            ret_list = [None] * (max_idx + 1)
            ret_list[self._metadata.return_hidden_states_index] = output
            ret_list[self._metadata.return_encoder_hidden_states_index] = original_encoder_hidden_states
            return tuple(ret_list)
        return output

    return self.fn_ref.original_forward(*args, **kwargs)


# Upstream ``MagCacheBlockHook._perform_calibration_step`` (mag_cache.py lines 363-377) divides per-token
# residual norms elementwise; across the prefill->decode transition the token counts differ and the division
# raises. Patched to suffix-align first (calibration mode only; the inference path never calls this). The
# step-1 ratio then compares the decode-step target-token residual against the target suffix of the prefill
# residual, which is exact given the prefix KV cache is.


def _magcache_calibration_step_patched(self, state, current_residual: torch.Tensor):
    if state.previous_residual is None:
        # First step has no previous residual to compare against; log 1.0 as a neutral starting point.
        ratio = 1.0
    else:
        current_residual, previous_residual = _suffix_align(current_residual, state.previous_residual)
        curr_norm = torch.linalg.norm(current_residual.float(), dim=-1)
        prev_norm = torch.linalg.norm(previous_residual.float(), dim=-1)
        ratio = (curr_norm / (prev_norm + 1e-8)).mean().item()
    state.calibration_ratios.append(ratio)


def install_qwen21_hook_patches() -> None:
    """Idempotent process-wide installation of the Qwen-Image-2.1 hook glue (metadata + suffix-align patches)."""
    global _PATCHED
    if _PATCHED:
        return
    register_qwen21_block_metadata()

    from diffusers.hooks import first_block_cache, mag_cache

    first_block_cache.FBCHeadBlockHook._should_compute_remaining_blocks = torch.compiler.disable(
        _fbc_should_compute_patched
    )
    first_block_cache.FBCHeadBlockHook.new_forward = _fbc_head_new_forward_patched
    mag_cache.MagCacheHeadHook.new_forward = torch.compiler.disable(_magcache_head_new_forward_patched)
    mag_cache.MagCacheBlockHook._perform_calibration_step = _magcache_calibration_step_patched
    _PATCHED = True


def install_krea2_hook_patches() -> None:
    """Idempotent process-wide installation of the Krea 2 hook glue (block metadata + CacheMixin interface).

    No numerical patches: Krea has no KV cache and no prefill/decode layout switch, so the upstream
    FBCache/MagCache forwards apply unchanged (the Qwen suffix-align patches are inert when shapes match,
    and are not installed here)."""
    global _KREA2_PATCHED
    if _KREA2_PATCHED:
        return
    register_krea2_block_metadata()
    _ensure_krea2_cache_mixin()
    _KREA2_PATCHED = True


# --- attach / detach / probes ---------------------------------------------------------------------------


def attach_official_cache(transformer, mcfg: dict, *, num_steps: int, latent_hw: tuple[int, int],
                          magcache_ratios: list[float] | None = None, kind: str = "qwenimage21",
                          patch_size: int = 1):
    """``transformer.enable_cache(<official config>)`` for one baseline method dict. Returns the config object."""
    from diffusers.hooks import (
        FirstBlockCacheConfig,
        MagCacheConfig,
        SeaCacheConfig,
        TaylorSeerCacheConfig,
    )

    family = mcfg["predictor"]
    if family == "fbcache_off":
        config = FirstBlockCacheConfig(threshold=float(mcfg["threshold"]))
    elif family == "taylorseer_off":
        dtype_name = mcfg.get("taylor_factors_dtype", "float32")
        config = TaylorSeerCacheConfig(
            cache_interval=int(mcfg.get("cache_interval", 5)),
            disable_cache_before_step=int(mcfg.get("disable_cache_before_step", 3)),
            disable_cache_after_step=mcfg.get("disable_cache_after_step"),
            max_order=int(mcfg.get("max_order", 1)),
            taylor_factors_dtype=getattr(torch, dtype_name),
            cache_identifiers=mcfg.get("cache_identifiers"),
            skip_predict_identifiers=mcfg.get("skip_predict_identifiers"),
        )
        if config.cache_interval > 1 and config.disable_cache_before_step < 2:
            # KV-layout guard: step 0 is a joint prefill, so Taylor factors recorded there have the joint
            # token count; TaylorSeerState.update restarts the expansion on the shape change but
            # TaylorSeerState.predict would still emit prefill-shaped features into a decode step and crash.
            # Two warmup steps (prefill + one decode update) put the factors in the decode layout before the
            # first prediction.
            raise ValueError(
                "taylorseer_off with the adapter's KV-cache layout needs disable_cache_before_step >= 2 "
                f"(got {config.disable_cache_before_step}) unless cache_interval == 1 (identity mode)"
            )
    elif family == "magcache_off":
        if magcache_ratios is None:
            raise ValueError("magcache_off needs calibrated mag_ratios (--calibrate-magcache / --magcache-ratios)")
        config = MagCacheConfig(
            threshold=float(mcfg["threshold"]),
            max_skip_steps=int(mcfg.get("max_skip_steps", 3)),
            retention_ratio=float(mcfg.get("retention_ratio", 0.2)),
            num_inference_steps=num_steps,
            mag_ratios=list(magcache_ratios),
            calibrate=False,
        )
        retention_step = int(config.retention_ratio * num_steps + 0.5)
        if config.threshold > 0 and config.max_skip_steps > 0 and retention_step < 2:
            raise ValueError(
                f"magcache_off retention resolves to {retention_step} step(s); with the adapter's KV-cache layout "
                "the first skippable step must be >= 2 so the cached residual comes from a decode-step compute"
            )
    elif family == "seacache_off":
        h, w = latent_hw
        if kind == "krea2":
            raw_vision_callback = make_krea2_raw_vision_callback(h, w, patch_size)
        else:
            raw_vision_callback = make_qwen21_raw_vision_callback(h, w)
        config = SeaCacheConfig(
            threshold=float(mcfg["threshold"]),
            residual_order=int(mcfg.get("residual_order", 1)),
            retention_steps=int(mcfg.get("retention_steps", 1)),
            cache_end_steps=int(mcfg.get("cache_end_steps", 1)),
            max_consecutive_cached=int(mcfg.get("max_consecutive_cached", 2)),
            power_exp=float(mcfg.get("power_exp", 3.0)),
            raw_vision_callback=raw_vision_callback,
        )
    else:
        raise ValueError(f"not a hook-based family: {family!r}")
    transformer.enable_cache(config)
    return config


def detach_official_cache(transformer) -> None:
    if getattr(transformer, "is_cache_enabled", False):
        transformer.disable_cache()


def reset_hook_state(transformer) -> None:
    """Per-image reset of every stateful cache hook (no-op when no cache is enabled)."""
    if getattr(transformer, "is_cache_enabled", False):
        transformer._reset_stateful_cache()


def make_qwen21_raw_vision_callback(h: int, w: int):
    """SeaCache ``raw_vision_callback`` for the adapter's call convention: the transformer-level
    ``hidden_states`` kwarg is always the packed target latents ``(B, h*w, C)`` (the adapter assembles the joint
    sequence inside the model), so the raw vision latent is recovered by unpacking. Returns ``[(C, T=1, H, W)]``;
    ``None`` (fail-open full compute) on any layout surprise."""
    from .adapters.qwenimage21 import unpack

    def callback(module, args, kwargs):
        hs = kwargs.get("hidden_states", None)
        if hs is None and args:
            hs = args[0]
        if not isinstance(hs, torch.Tensor) or hs.ndim != 3 or hs.shape[1] != h * w:
            return None
        lat = unpack(hs, h, w)  # (B, C, h, w)
        return [lat[0].unsqueeze(1).detach()]  # (C, T=1, h, w), batch is 1 in all our runs

    return callback


def make_krea2_raw_vision_callback(h: int, w: int, patch_size: int = 2):
    """SeaCache ``raw_vision_callback`` for the Krea 2 adapter: the transformer-level ``hidden_states`` kwarg
    is the packed image latents ``(B, (h/p)*(w/p), C*p*p)`` (the joint text+image sequence is assembled inside
    the model), so the raw vision latent is recovered by patch-2 unpacking. Returns ``[(C, T=1, H, W)]``;
    ``None`` (fail-open full compute) on any layout surprise."""
    from .adapters.krea2 import unpack

    def callback(module, args, kwargs):
        hs = kwargs.get("hidden_states", None)
        if hs is None and args:
            hs = args[0]
        if not isinstance(hs, torch.Tensor) or hs.ndim != 3 \
                or hs.shape[1] != (h // patch_size) * (w // patch_size):
            return None
        lat = unpack(hs, h, w, patch_size)  # (B, C, h, w)
        return [lat[0].unsqueeze(1).detach()]  # (C, T=1, h, w), batch is 1 in all our runs

    return callback


def make_decision_probe(transformer, mcfg: dict):
    """Return ``probe(step_index) -> bool`` telling whether step ``step_index`` actually ran the full stack.
    Read after the transformer call; hook state persists (keyed by the ``cond`` cache context) after the
    context is cleared."""
    family = mcfg["predictor"]

    if family == "taylorseer_off":
        # deterministic schedule, evaluated with the hook's own formula
        interval = int(mcfg.get("cache_interval", 5))
        before = int(mcfg.get("disable_cache_before_step", 3))
        after = mcfg.get("disable_cache_after_step")

        def probe(i: int) -> bool:
            if i < before:
                return True
            if after is not None and i >= after:
                return True
            return (i - before - 1) % interval == 0

        return probe

    if family == "fbcache_off":
        from diffusers.hooks.first_block_cache import _FBC_LEADER_BLOCK_HOOK

        hook = transformer.transformer_blocks[0]._diffusers_hook.get_hook(_FBC_LEADER_BLOCK_HOOK)
    elif family == "magcache_off":
        from diffusers.hooks.mag_cache import _MAG_CACHE_LEADER_BLOCK_HOOK

        hook = transformer.transformer_blocks[0]._diffusers_hook.get_hook(_MAG_CACHE_LEADER_BLOCK_HOOK)
    elif family == "seacache_off":
        from diffusers.hooks.sea_cache import _SEA_CACHE_ROOT_HOOK

        hook = transformer._diffusers_hook.get_hook(_SEA_CACHE_ROOT_HOOK)
    else:
        raise ValueError(f"no decision probe for {family!r}")
    if hook is None:
        raise RuntimeError(f"{family}: expected hook not found; was attach_official_cache called?")
    state_manager = hook.state_manager

    if family == "seacache_off":
        def probe(i: int) -> bool:
            state = state_manager._state_cache.get("cond")
            # a full (re)execution zeroes the consecutive-cache counter; a cache hit increments it
            return True if state is None else state.consecutive_cached == 0

        return probe

    def probe(i: int) -> bool:
        state = state_manager._state_cache.get("cond")
        return True if state is None else bool(state.should_compute)

    return probe


def load_magcache_ratios(path: str | Path) -> list[float]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return [float(v) for v in data["mag_ratios"]]


def load_teacache_coeffs(path: str | Path) -> list[float]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    coeffs = [float(v) for v in data["coefficients"]]
    if len(coeffs) != 5:
        raise ValueError(f"expected 5 TeaCache coefficients (degree-4, highest first), got {len(coeffs)}")
    return coeffs
