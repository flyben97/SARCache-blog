"""Week-1 mechanism diagnostics (proposal Sec. 7): is the cross-resolution difference ``D`` easier to carry
across steps than the full output ``F`` and its strong forecasters?

``teacher_trace`` runs the full model at every step of the baseline trajectory and, at the *same* state, the coarse
view, so ``F_t``, ``G_t`` and ``D_t = F_t - G_t`` share inputs. Extra teacher forwards are research cost only.

All errors share the denominator ``||F_{t+k}|| + eps`` as specified:
  E_D     = ||D_{t+k} - D_t||                      proposed zero-order difference reuse
  E_Dlin  = ||D_{t+k} - lin(D_{t-k}, D_t)||        matched-order control for E_Flin (not the first-version method)
  E_F     = ||F_{t+k} - F_t||                      zero-order full-output cache
  E_Flin  = ||F_{t+k} - lin(F_{t-k}, F_t)||        first-order output forecast in sigma
  E_Fcheb = ||F_{t+k} - cheb(F_{t-(M-1)k..t})||     Chebyshev ridge forecast (Spectrum-style, output level)
  E_G     = ||F_{t+k} - G_{t+k}||                  coarse only (D = 0)
Low/high-frequency parts use the orthogonal split ``P R`` / ``I - P R``; an optional latent-grid mask restricts
errors to a region such as rendered text.

Note: Spectrum and MeanCache forecast internal features; the output-level forecasters here are cheap proxies for
the mechanism plot and do not replace running the official baselines in Sec. 8.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

import numpy as np
import torch

from .operators import CoarseView, low_high_split
from .sampler import VelocityModel, _begin, acc, euler_update

EPS = 1e-8
BASELINES = ("E_F", "E_Flin", "E_Fcheb")


@dataclass
class Trace:
    sigmas: np.ndarray
    F: list = field(default_factory=list)
    G: list = field(default_factory=list)
    final: torch.Tensor | None = None

    @property
    def D(self) -> list:
        return [f - g for f, g in zip(self.F, self.G)]


@torch.no_grad()
def teacher_trace(model: VelocityModel, x_init: torch.Tensor, sigmas, factor: int,
                  coarse_mode: str = "aligned", store_device: str = "cpu") -> Trace:
    sig = torch.as_tensor(sigmas, dtype=torch.float32).cpu()
    view = CoarseView(factor, coarse_mode)
    _begin(model)
    x = x_init
    tr = Trace(sigmas=sig.numpy().astype(np.float64))
    for i in range(len(sig) - 1):
        s = float(sig[i])
        f = model(x, s, "full", 1)
        g = view(lambda y, t: model(y, t, "coarse", factor), x, s)
        tr.F.append(acc(f).to(store_device))
        tr.G.append(acc(g).to(store_device))
        x = euler_update(x, f, sig[i], sig[i + 1])
    tr.final = acc(x).to(store_device)
    return tr


def _norm(e: torch.Tensor, mask: torch.Tensor | None) -> float:
    if mask is not None:
        e = e * mask
    return float(e.double().norm())


def lin_forecast(s1: float, f1: torch.Tensor, s2: float, f2: torch.Tensor, s: float) -> torch.Tensor:
    return f2 + (f2 - f1) * ((s - s2) / (s2 - s1))


def cheb_forecast(ss: Sequence[float], fs: Sequence[torch.Tensor], s: float, degree: int = 2,
                  ridge: float = 1e-3) -> torch.Tensor:
    """Ridge fit of Chebyshev coefficients over the history window, evaluated at ``s``."""
    ss = np.asarray(ss, dtype=np.float64)
    lo, hi = ss.min(), ss.max()
    u = lambda v: 2.0 * (v - lo) / (hi - lo) - 1.0
    deg = min(degree, len(ss) - 1)
    basis = np.polynomial.chebyshev.chebvander(u(ss), deg)
    target = np.polynomial.chebyshev.chebvander(np.array([u(s)]), deg)[0]
    weights = target @ np.linalg.solve(basis.T @ basis + ridge * np.eye(deg + 1), basis.T)
    out = torch.zeros_like(fs[0])
    for w, f in zip(weights, fs):
        out = out + float(w) * f
    return out


def trace_errors(tr: Trace, intervals: Sequence[int] = (2, 4, 6, 8), factor: int = 4,
                 mask: torch.Tensor | None = None, cheb_points: int = 4) -> dict:
    """Per-(t, k) error arrays of shape ``[N, len(intervals)]`` (NaN where a predictor is undefined)."""
    F, G = tr.F, tr.G
    D = tr.D
    n = len(F)
    names = ("E_D", "E_Dlin", "E_F", "E_Flin", "E_Fcheb", "E_G", "E_D_low", "E_D_high", "E_F_low", "E_F_high",
             "E_gate", "E_best")
    out = {k: np.full((n, len(intervals)), np.nan) for k in names}
    sig = tr.sigmas
    for j, k in enumerate(intervals):
        for t in range(n - k):
            tk = t + k
            den = _norm(F[tk], mask) + EPS
            ed = D[tk] - D[t]
            ef = F[tk] - F[t]
            out["E_D"][t, j] = _norm(ed, mask) / den
            out["E_F"][t, j] = _norm(ef, mask) / den
            out["E_G"][t, j] = _norm(F[tk] - G[tk], mask) / den
            for name, e in (("E_D", ed), ("E_F", ef)):
                lo, hi = low_high_split(e, factor)
                out[name + "_low"][t, j] = _norm(lo, mask) / den
                out[name + "_high"][t, j] = _norm(hi, mask) / den
            if t - k >= 0:
                pred_f = lin_forecast(sig[t - k], F[t - k], sig[t], F[t], sig[tk])
                out["E_Flin"][t, j] = _norm(F[tk] - pred_f, mask) / den
                pred = lin_forecast(sig[t - k], D[t - k], sig[t], D[t], sig[tk])
                out["E_Dlin"][t, j] = _norm(D[tk] - pred, mask) / den
                # gate-efficacy probe: closed-loop gate signal = relative divergence between the
                # cross-resolution draft (G + stale D) and the free forecast; E_best = realized error
                # of the better of the two cheap predictors (what fusion/gating can approach)
                draft = G[tk] + D[t]
                out["E_gate"][t, j] = _norm(draft - pred_f, mask) / (_norm(pred_f, mask) + EPS)
                out["E_best"][t, j] = min(out["E_D"][t, j], out["E_Flin"][t, j])
            idx = [t - m * k for m in range(cheb_points - 1, -1, -1)]
            if idx[0] >= 0:
                pred = cheb_forecast([sig[i] for i in idx], [F[i] for i in idx], sig[tk])
                out["E_Fcheb"][t, j] = _norm(F[tk] - pred, mask) / den
    out["intervals"] = list(intervals)
    out["sigmas"] = sig[:n].tolist()
    return out


def cost_matrices(tr: Trace, mask: torch.Tensor | None = None) -> dict[str, np.ndarray]:
    """``cost[r, t]`` for ``r < t``: error of reusing refresh ``r`` at step ``t`` (for ``dp_refresh``)."""
    D = tr.D
    n = len(tr.F)
    cd = np.zeros((n, n))
    cf = np.zeros((n, n))
    for t in range(n):
        den = _norm(tr.F[t], mask) + EPS
        for r in range(t):
            cd[r, t] = _norm(D[t] - D[r], mask) / den
            cf[r, t] = _norm(tr.F[t] - tr.F[r], mask) / den
    return {"diff": cd, "fcache": cf}


def _stage(t: int, n: int) -> str:
    return ("early", "mid", "late")[min(2, 3 * t // max(n, 1))]


def summarize(errors: Sequence[dict], min_rel_improvement: float = 0.30, min_prompt_fraction: float = 0.75) -> dict:
    """Aggregate per-trace error arrays and evaluate the proposal's continue gate per interval.

    Per trace and interval, the strongest baseline is the smallest of E_F / E_Flin / E_Fcheb over the steps where
    all defined baselines exist. A trace "improves" if the median E_D is below the median strongest baseline.
    """
    errors = [{k: (np.asarray(v, dtype=np.float64) if k.startswith("E_") else v) for k, v in e.items()}
              for e in errors]
    intervals = errors[0]["intervals"]
    report = {"intervals": intervals, "per_interval": {}}
    for j, k in enumerate(intervals):
        rows, improved, rel = [], 0, []
        stage_vals: dict[str, dict[str, list]] = {}
        for err in errors:
            n = err["E_D"].shape[0]
            ed = err["E_D"][:, j]
            valid = ~np.isnan(ed)
            base_meds = {}
            for b in BASELINES:
                bv = err[b][:, j]
                ok = valid & ~np.isnan(bv)
                if ok.any():
                    base_meds[b] = float(np.median(bv[ok]))
            if not base_meds:
                continue
            strongest = min(base_meds, key=base_meds.get)
            bv = err[strongest][:, j]
            ok = valid & ~np.isnan(bv)
            med_d = float(np.median(ed[ok]))
            med_b = float(np.median(bv[ok]))
            rows.append(ed[valid])
            improved += med_d < med_b
            rel.append(1.0 - med_d / max(med_b, EPS))
            for t in np.nonzero(valid)[0]:
                st = stage_vals.setdefault(_stage(int(t), n), {"E_D": [], "E_F": []})
                st["E_D"].append(float(err["E_D"][t, j]))
                st["E_F"].append(float(err["E_F"][t, j]))
        if not rows:
            continue
        all_d = np.concatenate(rows)
        stats = {"E_D_median": float(np.median(all_d)), "E_D_p90": float(np.quantile(all_d, 0.9))}
        for name in BASELINES + ("E_Dlin", "E_G", "E_D_low", "E_D_high", "E_F_low", "E_F_high"):
            v = np.concatenate([e[name][:, j] for e in errors])
            v = v[~np.isnan(v)]
            if v.size:
                stats[name + "_median"] = float(np.median(v))
                stats[name + "_p90"] = float(np.quantile(v, 0.9))
        stats["stages"] = {s: {m: float(np.median(v)) for m, v in d.items()} for s, d in stage_vals.items()}
        frac = improved / len(rel)
        med_rel = float(np.median(rel))
        stats.update(
            prompts=len(rel),
            fraction_improved=frac,
            median_relative_improvement_vs_strongest=med_rel,
            gate_pass=bool(med_rel >= min_rel_improvement and frac >= min_prompt_fraction),
        )
        report["per_interval"][str(k)] = stats
    report["gate_rule"] = (
        f"median relative improvement >= {min_rel_improvement:.0%} vs strongest output forecaster and "
        f">= {min_prompt_fraction:.0%} of traces improved (teacher trajectory only; closed loop checked separately)"
    )
    return report
