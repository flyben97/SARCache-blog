"""Training-free staleness-aware residual caching for diffusion transformers."""
from .budget import Measured, max_full_forwards, speedup, time_ratio
from .operators import CoarseView, alignment, pool, sd3_shift, subsample, unpool
from .sampler import Method, SampleResult, sample
from .schedules import dp_refresh, dynamic_sigmas, shifted_sigmas, uniform_refresh

__version__ = "0.2.0"
