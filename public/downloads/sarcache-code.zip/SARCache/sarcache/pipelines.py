"""Build (adapter, initial noise, sigma grid, decoder) from an official diffusers pipeline.

Initial noise and sigmas follow each pipeline's own ``prepare_latents`` / scheduler code, so the ``exact`` method
reproduces the official sampler and every method starts from the same ``x_init`` (proposal Sec. 5.1). Passing
``embeds`` skips text encoding (used by the smoke test's tiny pipelines and for caching prompt encodings).
"""
from __future__ import annotations

import inspect
import os
from dataclasses import dataclass, field
from typing import Callable

import torch

from .schedules import scheduler_sigmas

KINDS = ("qwenimage21", "flux", "sana", "krea2")
DTYPES = {"bfloat16": torch.bfloat16, "float16": torch.float16, "float32": torch.float32}


@dataclass
class Request:
    adapter: Callable
    x_init: torch.Tensor
    sigmas: torch.Tensor
    decode: Callable[[torch.Tensor], list]
    meta: dict = field(default_factory=dict)


def pipeline_class(kind: str):
    import diffusers

    names = {"qwenimage21": "QwenImage21Pipeline", "flux": "FluxPipeline", "sana": "SanaPipeline",
             "krea2": "Krea2Pipeline"}
    if kind not in names:
        raise ValueError(f"unknown model kind {kind!r}; expected one of {KINDS}")
    try:
        return getattr(diffusers, names[kind])
    except AttributeError as exc:
        raise ImportError(f"diffusers {diffusers.__version__} does not provide {names[kind]}; "
                          "install requirements-models.txt") from exc


def load_pipeline(kind: str, path: str, dtype: str = "bfloat16", device: str = "cuda", offload: bool = False,
                  *, local_files_only: bool = True):
    if dtype not in DTYPES:
        raise ValueError(f"unknown dtype {dtype!r}; expected one of {tuple(DTYPES)}")
    target = torch.device(device)
    if offload and target.type != "cuda":
        raise ValueError("CPU offload requires a CUDA execution device")
    pipe = pipeline_class(kind).from_pretrained(path, torch_dtype=DTYPES[dtype],
                                               local_files_only=local_files_only)
    if kind == "sana":
        # Sana ships a DPMSolverMultistepScheduler, but this project's sampler -- and the method under
        # study -- is an Euler flow-match integrator, so Sana is driven with the Euler solver at the
        # model's own flow_shift. This has to happen HERE rather than at one call site: every consumer
        # (parity, budget, run_methods) must agree, and DPMSolver's set_timesteps() does not even accept
        # the `sigmas=` argument that scheduler_sigmas() passes.
        # Consequence for the paper: Sana results are Euler-sampled, not DPM-Solver-sampled.
        from diffusers import FlowMatchEulerDiscreteScheduler

        shift = float(getattr(pipe.scheduler.config, "flow_shift", None) or 1.0)
        pipe.scheduler = FlowMatchEulerDiscreteScheduler(num_train_timesteps=1000, shift=shift)
        print(f"sana: scheduler -> FlowMatchEulerDiscreteScheduler(shift={shift})", flush=True)
    if kind == "krea2" and pipe.scheduler.__class__.__name__ != "FlowMatchEulerDiscreteScheduler":
        # Same Euler-unification rule as Sana, but a no-op in practice: Krea 2 ships a
        # FlowMatchEulerDiscreteScheduler with the resolution-aware dynamic shift (base_shift 0.5,
        # max_shift 1.15). The guard only protects against a checkpoint shipping a different
        # scheduler; the shift parameters are carried over via from_config.
        from diffusers import FlowMatchEulerDiscreteScheduler

        pipe.scheduler = FlowMatchEulerDiscreteScheduler.from_config(pipe.scheduler.config)
        print("krea2: scheduler -> FlowMatchEulerDiscreteScheduler(from_config)", flush=True)
    if offload:
        pipe.enable_model_cpu_offload(device=target)
    else:
        pipe.to(device)
    pipe.set_progress_bar_config(disable=True)
    return pipe


def _identity(t):
    """No-op pack for pipelines whose latents are already spatial (Sana)."""
    return t


_DRAFT_CACHE: dict = {}


def _attach_draft_net(adapter):
    """Attach a distilled draft net (spec_distill) when DISTILL_DRAFT_PATH is set.

    Called lazily by run_methods for spec_distill methods only (the attach must NOT happen for
    exact/official rows: it would build a student nobody uses). The trunk is a frozen shared view
    over the teacher's modules, so the only extra memory is the ~tens-of-MB heads. No-op when the
    env var is absent; sarcache.distill is imported only when the env var is set.
    """
    path = os.environ.get("DISTILL_DRAFT_PATH")
    if not path:
        return
    try:
        from .distill import DraftStudent
    except ImportError as exc:
        raise ImportError("DISTILL_DRAFT_PATH is set but sarcache.distill could not be "
                          "imported (distilled-draft support is missing); unset "
                          "DISTILL_DRAFT_PATH to run without the draft net") from exc
    # qwen adapter: cond dict; krea adapter: pe carries the (1, L, n_layers, D) stack directly.
    text_embeds = adapter.cond["embeds"] if hasattr(adapter, "cond") else adapter.pe
    draft = _DRAFT_CACHE.get(path)
    if draft is None or getattr(draft, "teacher", None) is not adapter.transformer:
        draft = DraftStudent.from_checkpoint(path, teacher=adapter, shared=True)
        draft.to(text_embeds.device)
        draft.teacher = adapter.transformer      # pin: cache stays valid across prompts
        _DRAFT_CACHE[path] = draft
    draft.set_conditioning(text_embeds)
    depth = int(os.environ.get("DISTILL_DRAFT_DEPTH", "0") or 0)
    if depth:
        draft.set_depth(depth)
    adapter.draft_net = draft


def _device(pipe):
    return pipe._execution_device


def build_request(pipe, kind: str, prompt: str | None = None, *, height: int, width: int, num_steps: int,
                  seed: int, negative_prompt: str | None = None, cfg: float | None = None,
                  coarse_positions: str = "native", embeds: dict | None = None) -> Request:
    builders = {"qwenimage21": _qwenimage21, "flux": _flux, "sana": _sana, "krea2": _krea2}
    return builders[kind](pipe, prompt, height, width, num_steps, seed, negative_prompt, cfg, coarse_positions,
                          embeds or {})


def _qwenimage21(pipe, prompt, height, width, num_steps, seed, negative_prompt, cfg, coarse_positions, embeds):
    from .adapters.qwenimage21 import QwenImage21Adapter, pack, unpack

    device = _device(pipe)
    multiple = pipe.vae_scale_factor * 2
    height, width = height // multiple * multiple, width // multiple * multiple
    pe, pm, pad = pipe.encode_prompt(
        prompt=None if "prompt_embeds" in embeds else prompt, device=device,
        prompt_embeds=embeds.get("prompt_embeds"), prompt_embeds_mask=embeds.get("prompt_embeds_mask"),
        image_pad_mask=embeds.get("image_pad_mask"),
    )
    cfg = 1.0 if cfg is None else cfg
    negative = None
    if cfg > 1.0:
        negative = pipe.encode_prompt(
            prompt=None if "negative_prompt_embeds" in embeds else (negative_prompt or " "), device=device,
            prompt_embeds=embeds.get("negative_prompt_embeds"),
            prompt_embeds_mask=embeds.get("negative_prompt_embeds_mask"),
        )
    generator = torch.Generator(device=device).manual_seed(seed)
    c = pipe.transformer.config.in_channels
    packed, _ = pipe.prepare_latents(None, 1, c, height, width, pe.dtype, device, generator)
    h, w = height // pipe.vae_scale_factor, width // pipe.vae_scale_factor
    x_init = unpack(packed, h, w)
    sigmas = scheduler_sigmas(pipe.scheduler, num_steps, image_seq_len=packed.shape[1])
    adapter = QwenImage21Adapter(pipe.transformer, pe, pm, pad, negative=negative, true_cfg_scale=cfg,
                                 coarse_positions=coarse_positions)

    def decode(latents):
        vae = pipe.vae
        lat = latents.unsqueeze(2).to(vae.dtype)
        mean = torch.tensor(vae.config.latents_mean).view(1, vae.config.z_dim, 1, 1, 1).to(lat.device, lat.dtype)
        std = torch.tensor(vae.config.latents_std).view(1, vae.config.z_dim, 1, 1, 1).to(lat.device, lat.dtype)
        image = vae.decode(lat * std + mean, return_dict=False)[0][:, :, 0]
        return pipe.image_processor.postprocess(image, output_type="pil")

    meta = {"height": height, "width": width, "latent_hw": [h, w], "tokens": h * w, "cfg": cfg,
            "pack": "flatten", "_pack": pack}
    return Request(adapter, x_init, sigmas, decode, meta)


def _flux(pipe, prompt, height, width, num_steps, seed, negative_prompt, cfg, coarse_positions, embeds):
    from .adapters.flux import FluxAdapter, pack, unpack

    device = _device(pipe)
    multiple = pipe.vae_scale_factor * 2
    height, width = height // multiple * multiple, width // multiple * multiple
    if "prompt_embeds" in embeds:
        pe, pooled = embeds["prompt_embeds"], embeds["pooled_prompt_embeds"]
        text_ids = torch.zeros(pe.shape[1], 3, device=device, dtype=pe.dtype)
    else:
        pe, pooled, text_ids = pipe.encode_prompt(prompt=prompt, prompt_2=None, device=device,
                                                  max_sequence_length=512)
    generator = torch.Generator(device=device).manual_seed(seed)
    c = pipe.transformer.config.in_channels // 4
    packed, _ = pipe.prepare_latents(1, c, height, width, pe.dtype, device, generator)
    h, w = 2 * (height // multiple), 2 * (width // multiple)
    x_init = unpack(packed, h, w)
    sigmas = scheduler_sigmas(pipe.scheduler, num_steps, image_seq_len=packed.shape[1])
    guidance = 3.5 if cfg is None else cfg
    adapter = FluxAdapter(pipe.transformer, pe, pooled, text_ids, guidance_scale=guidance,
                          coarse_positions=coarse_positions)

    def decode(latents):
        vae = pipe.vae
        lat = latents.to(vae.dtype) / vae.config.scaling_factor + vae.config.shift_factor
        image = vae.decode(lat, return_dict=False)[0]
        return pipe.image_processor.postprocess(image, output_type="pil")

    meta = {"height": height, "width": width, "latent_hw": [h, w], "tokens": packed.shape[1],
            "guidance": guidance, "_pack": pack}
    return Request(adapter, x_init, sigmas, decode, meta)


def _sana(pipe, prompt, height, width, num_steps, seed, negative_prompt, cfg, coarse_positions, embeds):
    from .adapters.sana import SanaAdapter

    device = _device(pipe)
    cfg = 4.5 if cfg is None else cfg
    if "prompt_embeds" in embeds:
        pe, pm = embeds["prompt_embeds"], embeds["prompt_attention_mask"]
        npe, npm = embeds.get("negative_prompt_embeds"), embeds.get("negative_prompt_attention_mask")
    else:
        default_chi = inspect.signature(pipe.__call__).parameters["complex_human_instruction"].default
        pe, pm, npe, npm = pipe.encode_prompt(prompt, do_classifier_free_guidance=cfg > 1.0,
                                              negative_prompt=negative_prompt or "", device=device,
                                              complex_human_instruction=default_chi)
    generator = torch.Generator(device=device).manual_seed(seed)
    c = pipe.transformer.config.in_channels
    x_init = pipe.prepare_latents(1, c, height, width, torch.float32, device, generator)
    shift = float(getattr(pipe.scheduler.config, "flow_shift", None) or 1.0)
    # Read the grid OUT of the pipeline's own scheduler, exactly as the qwen and flux builders do. Building
    # it by hand (shifted_sigmas) happened to match FlowMatchEuler's static shift but NOT the schedule Sana
    # actually ships (DPMSolverMultistep with use_flow_sigmas), so the sampler would have silently run a
    # different schedule from the official pipeline -- which is what the parity check caught.
    sigmas = scheduler_sigmas(pipe.scheduler, num_steps)
    negative = (npe, npm) if cfg > 1.0 else None
    adapter = SanaAdapter(pipe.transformer, pe, pm, negative=negative, guidance_scale=cfg)

    def decode(latents):
        vae = pipe.vae
        image = vae.decode(latents.to(vae.dtype) / vae.config.scaling_factor, return_dict=False)[0]
        return pipe.image_processor.postprocess(image, output_type="pil")

    # Sana consumes spatial latents directly (no packing), but every request carries a "_pack" callable so
    # downstream comparison code can be model-agnostic -- for Sana it is the identity.
    meta = {"height": height, "width": width, "latent_hw": list(x_init.shape[-2:]), "cfg": cfg,
            "flow_shift": shift, "_pack": _identity}
    return Request(adapter, x_init, sigmas, decode, meta)


def _krea2(pipe, prompt, height, width, num_steps, seed, negative_prompt, cfg, coarse_positions, embeds):
    from .adapters.krea2 import Krea2Adapter, pack, unpack

    device = _device(pipe)
    p = int(getattr(pipe, "patch_size", 2))
    multiple = pipe.vae_scale_factor * p
    height, width = height // multiple * multiple, width // multiple * multiple
    cfg = 3.5 if cfg is None else cfg
    if "prompt_embeds" in embeds:
        pe, pm = embeds["prompt_embeds"], embeds["prompt_embeds_mask"]
        npe, npm = embeds.get("negative_prompt_embeds"), embeds.get("negative_prompt_embeds_mask")
    else:
        pe, pm = pipe.encode_prompt(prompt, device=device)
        npe = npm = None
        if cfg > 0:
            npe, npm = pipe.encode_prompt(negative_prompt or "", device=device)
    generator = torch.Generator(device=device).manual_seed(seed)
    c = pipe.transformer.config.in_channels // (p ** 2)
    packed = pipe.prepare_latents(1, c, height, width, pe.dtype, device, generator)
    lh, lw = height // pipe.vae_scale_factor, width // pipe.vae_scale_factor
    x_init = unpack(packed, lh, lw, p)
    # The Krea 2 grid is resolution-aware (dynamic shift on the image token count), so the sigma
    # grid is read out of the pipeline's own scheduler exactly like qwen/flux (Sana lesson 8.11o:
    # never hand-build the grid).
    sigmas = scheduler_sigmas(pipe.scheduler, num_steps, image_seq_len=packed.shape[1])
    negative = (npe, npm) if cfg > 0 else None
    adapter = Krea2Adapter(pipe.transformer, pe, pm, negative=negative, guidance_scale=cfg,
                           patch_size=p, coarse_positions=coarse_positions)

    def decode(latents):
        vae = pipe.vae
        lat = pipe._unpack_latents(pack(latents, p), height, width).to(vae.dtype)
        mean = torch.tensor(vae.config.latents_mean).view(1, vae.config.z_dim, 1, 1, 1).to(lat.device, lat.dtype)
        std = 1.0 / torch.tensor(vae.config.latents_std).view(1, vae.config.z_dim, 1, 1, 1).to(lat.device, lat.dtype)
        lat = lat / std + mean
        image = vae.decode(lat, return_dict=False)[0][:, :, 0]
        return pipe.image_processor.postprocess(image, output_type="pil")

    meta = {"height": height, "width": width, "latent_hw": [lh, lw], "tokens": packed.shape[1],
            "guidance": cfg, "patch_size": p, "_pack": lambda t: pack(t, p)}
    return Request(adapter, x_init, sigmas, decode, meta)


def sigmas_for(pipe, kind: str, meta: dict, num_steps: int) -> torch.Tensor:
    """Sigma grid of the same pipeline for another step count (the "fewer sampling steps" baseline).

    Every kind reads the grid from its own scheduler; only the dynamic-shift models need the sequence
    length. Sana used to hand-build a static-shift grid, which diverged from the schedule it actually
    ships -- see the note in ``_sana``.
    """
    if kind == "sana":
        return scheduler_sigmas(pipe.scheduler, num_steps)
    return scheduler_sigmas(pipe.scheduler, num_steps, image_seq_len=meta["tokens"])


def public_meta(meta: dict) -> dict:
    return {k: v for k, v in meta.items() if not k.startswith("_")}
