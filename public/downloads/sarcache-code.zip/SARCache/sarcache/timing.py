"""Wall-clock accounting per call category. Synchronises CUDA so batch-1 latencies are attributable.

Two protocols (reviewer C7):
  - ``instrumented`` (default): sync before/after every category bucket. Bucket seconds are exact,
    but the number of extra syncs varies with the method's bucket structure.
  - ``boundary_only``: no sync inside the sampler at all; category buckets are reported as None.
    Wall times (prepare/sample/decode) still come from the run function's own boundary syncs, which
    every method shares, so cross-method latency comparisons carry no per-method sync overhead.
"""
from __future__ import annotations

import time
from collections import defaultdict
from contextlib import contextmanager

import torch


class Timer:
    def __init__(self, enabled: bool = True, device: torch.device | str | None = None,
                 boundary_only: bool = False):
        self.enabled = enabled
        self.boundary_only = boundary_only
        self.cuda = torch.cuda.is_available() and (device is None or torch.device(device).type == "cuda")
        self.seconds: dict[str, float] = defaultdict(float)
        self.calls: dict[str, int] = defaultdict(int)

    def _sync(self):
        if self.cuda:
            torch.cuda.synchronize()

    @contextmanager
    def __call__(self, name: str):
        self.calls[name] += 1
        if not self.enabled or self.boundary_only:
            yield
            return
        self._sync()
        start = time.perf_counter()
        try:
            yield
        finally:
            self._sync()
            self.seconds[name] += time.perf_counter() - start

    def summary(self) -> dict:
        if self.boundary_only:
            return {"seconds": {name: None for name in self.calls}, "calls": dict(self.calls),
                    "total_s": None, "protocol": "boundary_only"}
        return {"seconds": dict(self.seconds), "calls": dict(self.calls),
                "total_s": sum(self.seconds.values()), "protocol": "instrumented"}
