"""Spatial operators and the noise-consistent coarse view (proposal Sec. 4).

Conventions used throughout the package:
  * latents are spatial tensors ``[B, C, H, W]`` in the model's normalised latent space;
  * the forward path is ``x_sigma = (1 - sigma) x0 + sigma * eps`` and every velocity is ``dx/dsigma``;
  * ``R`` averages non-overlapping ``f x f`` blocks, ``P`` repeats each coarse cell ``f x f`` times, so ``R P = I``
    and ``P R`` is the orthogonal projector onto block-constant fields.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import torch
import torch.nn.functional as F

COARSE_MODES = ("aligned", "naive", "subsample")


def pool(x: torch.Tensor, factor: int) -> torch.Tensor:
    """R: block average over ``factor x factor`` latent positions, channels untouched."""
    if factor == 1:
        return x
    h, w = x.shape[-2:]
    if h % factor or w % factor:
        raise ValueError(f"latent grid {h}x{w} is not divisible by factor {factor}")
    return F.avg_pool2d(x, kernel_size=factor, stride=factor)


def unpool(y: torch.Tensor, factor: int) -> torch.Tensor:
    """P: nearest-neighbour repeat, the right inverse of ``pool``."""
    if factor == 1:
        return y
    return y.repeat_interleave(factor, dim=-2).repeat_interleave(factor, dim=-1)


def subsample(x: torch.Tensor, factor: int, offset: tuple[int, int] = (0, 0)) -> torch.Tensor:
    """Binary block selection (one latent position per block), the operator family used by Preview Generation."""
    if factor == 1:
        return x
    dy, dx = offset
    if not (0 <= dy < factor and 0 <= dx < factor):
        raise ValueError("offset must lie inside the block")
    h, w = x.shape[-2:]
    if h % factor or w % factor:
        raise ValueError(f"latent grid {h}x{w} is not divisible by factor {factor}")
    return x[..., dy::factor, dx::factor]


def low_high_split(x: torch.Tensor, factor: int) -> tuple[torch.Tensor, torch.Tensor]:
    """Orthogonal split ``x = P R x + (I - P R) x`` into block-constant and block-zero-mean parts."""
    low = unpool(pool(x, factor), factor)
    return low, x - low


def band_mse(pred: torch.Tensor, target: torch.Tensor, band_w: float = 1.0,
             band_factor: int = 4) -> torch.Tensor:
    """Frequency-band-weighted MSE over the ``low_high_split`` block bands.

    ``band_w == 1`` is exactly plain MSE (the split is orthogonal, so the two band
    means sum to the total). ``band_w > 1`` upweights the block-constant low band —
    the band the draft-MSE diagnosis (state.md §8.52) identifies as carrying the
    dominant share of the caching error, so distillation capacity is steered there.
    """
    if band_w == 1.0:
        return F.mse_loss(pred, target)
    p_lo, p_hi = low_high_split(pred, band_factor)
    t_lo, t_hi = low_high_split(target, band_factor)
    return band_w * (p_lo - t_lo).square().mean() + (p_hi - t_hi).square().mean()


def sea_wiener_filter(x: torch.Tensor, a: float, b: float, power_exp: float = 2.0,
                      dims=None, norm_mode: str = "mean") -> torch.Tensor:
    """SeaCache's separable N-D Wiener filter (faithful port of the vendored official
    implementation, baselines_src/seacache_official/*/util_seacache.py) — used to
    filter the cached hidden residual before reuse (the spec_fusion_sea member, §8.83).

    Per axis the gain is ``H1 = (a*Sx0)/(a*a*Sx0 + b*b)`` with the 1/f^power_exp signal
    power prior ``Sx0 = 1/(rad**power_exp + eps)``; the ND filter is the product over
    axes, mean-normalized, applied in the Fourier domain. Semantics: ``a`` = signal
    level, ``b`` = noise level of the residual — ``b -> 0`` reproduces the input
    (nothing to filter), large ``b`` crushes the output toward 0, and in between the
    filter is a low-pass whose cutoff follows the signal/noise ratio.
    """
    eps = 1e-16
    orig_dtype = x.dtype
    x = x.contiguous()
    x32 = x.to(torch.float32)
    if dims is None:
        dims = tuple(range(x32.ndim)) if x32.ndim <= 2 else tuple(range(1, x32.ndim))
    X = torch.fft.fftn(x32, dim=dims)
    H = None
    for ax in dims:
        N = x32.shape[ax]
        f = torch.fft.fftfreq(N, device=x32.device, dtype=torch.float32)
        rad = torch.abs(f)
        Sx0 = 1.0 / ((rad ** power_exp) + eps)
        H1 = (a * Sx0) / (a * a * Sx0 + b * b + eps)
        shape_i = [1] * x32.ndim
        shape_i[ax] = H1.shape[0]
        H1 = H1.reshape(shape_i)
        H = H1 if H is None else (H * H1)
    if norm_mode.lower() == "peak":
        maxv = torch.amax(H)
        if torch.isfinite(maxv) and maxv > 0:
            H = H / maxv
    else:
        meanv = torch.mean(H)
        if torch.isfinite(meanv) and meanv > 0:
            H = H / meanv
    y = torch.fft.ifftn(X * H, dim=dims).real
    return y.to(orig_dtype)


def alignment(sigma: float, factor: int) -> tuple[float, float, float]:
    """Return ``(s, a, tau)`` with ``s = 1/sqrt(q) = 1/factor``, ``a = 1 - sigma + s sigma``, ``tau = s sigma / a``.

    ``tau(sigma)`` coincides with the inverse of the SD3 resolution-dependent timestep shift with
    ``alpha = sqrt(q)``; see ``sd3_shift``.
    """
    s = 1.0 / factor
    a = 1.0 - sigma + s * sigma
    return s, a, s * sigma / a


def sd3_shift(t: float, alpha: float) -> float:
    """SD3 (Esser et al. 2024, Eq. 23) timestep shift from a base resolution to one with ``alpha**2`` more pixels."""
    return alpha * t / (1.0 + (alpha - 1.0) * t)


VelocityFn = Callable[[torch.Tensor, float], torch.Tensor]


@dataclass(frozen=True)
class CoarseView:
    """Builds ``G(x, sigma)``: run the frozen model on a coarse view of ``x`` and map the output to the full grid.

    ``aligned``   proposal Sec. 4.1: ``y = R x / a``, model time ``tau``, ``G = P[(s-1) y + (s/a) F^L(y, tau)]``.
    ``naive``     ablation "no noise alignment": ``G = P F^L(R x, sigma)``.
    ``subsample`` binary selection keeps unit noise variance: ``G = P F^L(S x, sigma)``.
    """

    factor: int
    mode: str = "aligned"
    offset: tuple[int, int] = (0, 0)

    def __post_init__(self):
        if self.mode not in COARSE_MODES:
            raise ValueError(f"unknown coarse mode {self.mode!r}; expected one of {COARSE_MODES}")
        if self.factor < 1:
            raise ValueError("factor must be >= 1")

    def model_input(self, x: torch.Tensor, sigma: float) -> tuple[torch.Tensor, float]:
        """Coarse latent and the noise level at which the model must be queried."""
        if self.mode == "aligned":
            _, a, tau = alignment(sigma, self.factor)
            return pool(x, self.factor) / a, tau
        if self.mode == "naive":
            return pool(x, self.factor), sigma
        return subsample(x, self.factor, self.offset), sigma

    def lift(self, y: torch.Tensor, coarse_velocity: torch.Tensor, sigma: float) -> torch.Tensor:
        """Map the coarse model output back to a full-grid velocity in ``dx/dsigma`` units."""
        if self.mode == "aligned":
            s, a, _ = alignment(sigma, self.factor)
            return unpool((s - 1.0) * y + (s / a) * coarse_velocity, self.factor)
        return unpool(coarse_velocity, self.factor)

    def __call__(self, velocity: VelocityFn, x: torch.Tensor, sigma: float) -> torch.Tensor:
        y, t_model = self.model_input(x, sigma)
        return self.lift(y, velocity(y, t_model), sigma)
