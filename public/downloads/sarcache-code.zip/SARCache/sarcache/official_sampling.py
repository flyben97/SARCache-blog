"""Sampling loops for the official-baseline runner (R-Opus/04_BASELINE_FIX_ZH.md S2).

Families:
  * hook-based (fbcache_off / taylorseer_off / magcache_off / seacache_off): the official diffusers hook,
    attached to the shared transformer by the caller, decides per step; the loop just calls the adapter and
    records the hook's compute/skip decision. Hook overhead is timed inside the sampling window.
  * teacache_off: TeaCache (2411.19108) in its official form on Qwen-Image-2.1 / Krea 2 — accumulated
    polynomial-rescaled rel-L1 of the block-0 modulated input gates reuse of the *hidden-space residual*
    (last-block output minus img_in output), added to the current img_in output before the final layer
    (norm_out/proj_out on Qwen, final_layer on Krea). Coefficients are re-fitted per model
    (scripts/fit_teacache_coeffs.py); threshold <= 0 is an explicit always-compute identity mode (the
    official form has no identity guarantee because the polynomial can be non-positive for tiny inputs).
  * easycache_off: EasyCache (2507.02860) in its official form as described in 04_BASELINE_FIX_ZH §2.4 —
    reuse of the *transformation vector* (stack output minus stack input, the same hidden residual as TeaCache)
    added to the current input; the error estimate is the current input's relative change times the observed
    transformation rate k; warmup is a fraction of the total step count.

Porting notes (what is official vs assumed) are in R-Opus/out/baseline_implementation_audit.md.
"""
from __future__ import annotations

import numpy as np
import torch

from .official_hooks import make_decision_probe, reset_hook_state
from .sampler import Method, SampleResult, _shadow_isolated, acc, euler_update, sample
from .timing import Timer


def _require_single_branch(adapter, family: str) -> None:
    """Explicit per-kind check that the adapter runs a single denoising branch; no silent defaults."""
    if hasattr(adapter, "cfg"):
        if adapter.cfg != 1.0:
            raise ValueError(f"{family} needs true_cfg_scale == 1.0")
    elif hasattr(adapter, "guidance"):
        if adapter.guidance != 0.0:
            raise ValueError(f"{family} needs guidance_scale == 0.0 (Krea single-branch convention)")
    else:
        raise ValueError(f"{family}: adapter {type(adapter).__name__} exposes neither cfg nor guidance")


def sample_full(req, timer: Timer) -> SampleResult:
    """The exact baseline, through the main sampler so it is bitwise identical to run_methods.py's full."""
    return sample(req.adapter, req.x_init, req.sigmas, Method(name="full", predictor="exact"),
                  timer=timer, record=True)


@torch.no_grad()
def sample_hooked(req, mcfg: dict, timer: Timer) -> SampleResult:
    """Euler loop driven by an official diffusers cache hook already attached to req.adapter.transformer."""
    adapter = req.adapter
    family = mcfg["predictor"]
    sig = torch.as_tensor(req.sigmas, dtype=torch.float32).cpu()
    n = len(sig) - 1
    reset_hook_state(adapter.transformer)
    adapter.begin()  # defensive: fresh prefix KV cache (a new adapter per request already implies this)
    probe = make_decision_probe(adapter.transformer, mcfg)
    x = req.x_init
    steps, computed_steps = [], []
    counts = {"full": 0, "coarse": 0, "skipped": 0}
    for i in range(n):
        s, s_next = sig[i], sig[i + 1]
        sf = float(s)
        if family == "seacache_off":
            # the SeaCache hook requires scheduler coordinates on every call
            adapter.cache_context_extras = {"step_index": i, "sigma": sf, "num_inference_steps": n}
        with timer("model"):
            v = adapter(x, sf, "full", 1)
        computed = probe(i)
        if computed:
            counts["full"] += 1
            computed_steps.append(i)
        else:
            counts["skipped"] += 1
        with timer("ops"):
            x = euler_update(x, v, s, s_next)
        steps.append({"step": i, "sigma": sf, "used": "F" if computed else "cached"})
    adapter.cache_context_extras = {}
    return SampleResult(latents=x, refresh=computed_steps, counts=counts, timing=timer.summary(), steps=steps)


@torch.no_grad()
def sample_teacache_off(req, mcfg: dict, coeffs: list[float], timer: Timer) -> SampleResult:
    """Official-form TeaCache on Qwen-Image-2.1 / Krea 2 (see module docstring). ``coeffs`` are degree-4, highest first."""
    adapter = req.adapter
    _require_single_branch(adapter, "teacache_off")
    threshold = float(mcfg["threshold"])
    a, b, c, d, e = coeffs

    def poly(r: float) -> float:
        return ((((a * r) + b) * r + c) * r + d) * r + e

    sig = torch.as_tensor(req.sigmas, dtype=torch.float32).cpu()
    n = len(sig) - 1
    x = req.x_init
    steps, computed_steps = [], []
    counts = {"full": 0, "coarse": 0, "skipped": 0}
    probe_prev = None
    acc_dist = 0.0
    residual = None
    for i in range(n):
        s, s_next = sig[i], sig[i + 1]
        sf = float(s)
        with timer("ops"):
            m_t = adapter.probe(x, sf)
            if probe_prev is not None:
                rel_l1 = float((m_t - probe_prev).abs().mean() / (probe_prev.abs().mean() + 1e-8))
                acc_dist += poly(rel_l1)
            probe_prev = m_t
            # official: skip while accumulated < thresh, so compute at accumulated >= thresh
            compute = threshold <= 0.0 or acc_dist >= threshold  # threshold <= 0: identity mode (always compute)
            if i == 0 or i == n - 1 or residual is None:
                compute = True  # TeaCache always computes the first and last step
        if compute:
            acc_dist = 0.0
            with timer("full"):
                v, _, residual = adapter.embed_full(x, sf)
            counts["full"] += 1
            computed_steps.append(i)
            used = "tea_F"
        else:
            with timer("ops"):
                v = adapter.embed_reuse(x, sf, residual)
            counts["skipped"] += 1
            used = "tea_reuse"
        with timer("ops"):
            x = euler_update(x, v, s, s_next)
        steps.append({"step": i, "sigma": sf, "used": used})
    return SampleResult(latents=x, refresh=computed_steps, counts=counts, timing=timer.summary(), steps=steps)


@torch.no_grad()
def sample_easycache_off(req, mcfg: dict, timer: Timer) -> SampleResult:
    """Official-form EasyCache on Qwen-Image-2.1 / Krea 2.

    Ported from the official repository (``H-EmbodVis/EasyCache``, ``EasyCache4Wan2.1/easycache_generate.py``,
    ``easycache_forward``, lines 486-640). The gate, transcribed to our stack-input/velocity notation
    (official ``raw_input`` = the latent fed to the model, ``output`` = the model's velocity; ours are the
    stack input ``emb = img_in(hs)`` and the velocity ``v``):

      pred_change_t = k * mean|emb_t - emb_{t-1}| / mean|v_s|          # s = most recent computed step
      acc_err      += pred_change_t ; compute iff acc_err >= threshold  (skip while acc_err < threshold)
      k             = mean|v_t - v_s| / mean|emb_t - emb_s|            # refreshed at each computed step

    Three details that are easy to get wrong and are taken verbatim from the official source: (a) the input
    change in ``pred_change`` is measured against the **previous step** (official ``previous_raw_input_even``
    is refreshed every step), while ``k`` is measured over the interval between the two most recent **computed**
    steps; (b) the normaliser is the **velocity** magnitude ``mean|v_s|``, not the input magnitude — this makes
    the budget sigma-aware, since the velocity scale varies strongly along the trajectory; (c) the changes are
    plain mean-abs, made relative only through that single division.

    Warmup is ``ret_steps`` (official default 10 real steps) and the last step always computes, matching
    official ``cutoff_steps``. Official also only decides on even (condition) steps because Wan pairs every
    cond step with an uncond step; at true_cfg_scale == 1 there is no odd path, so that branch is vacuous here.

    Structural port note: official caches ``output - raw_input`` and returns it added to the current latent
    without re-running the head. Here the cached object is the hidden-space residual ``hN - emb`` and the head
    (``norm_out``/``proj_out``) is re-applied to ``emb_t + residual`` — the same construction the diffusers
    FBCache and official TeaCache ports use, and the only one available at this level of abstraction (the
    velocity and the stack input have different channel counts, so the official velocity-space difference has
    no direct analogue).
    """
    adapter = req.adapter
    _require_single_branch(adapter, "easycache_off")
    threshold = float(mcfg["threshold"])
    sig = torch.as_tensor(req.sigmas, dtype=torch.float32).cpu()
    n = len(sig) - 1
    warmup = int(mcfg["ret_steps"]) if "ret_steps" in mcfg else int(round(float(mcfg.get("warmup_ratio", 0.25)) * n))
    x = req.x_init
    steps, computed_steps = [], []
    counts = {"full": 0, "coarse": 0, "skipped": 0}
    emb_prev = None            # stack input at the previous step (refreshed every step, as official does)
    v_compute = None           # velocity at the most recent computed step
    emb_compute = None         # stack input at the most recent computed step
    delta_prev = None          # transformation vector (hN - emb) at the most recent computed step
    k = None                   # observed output/input finite-difference ratio between the last two computed steps
    acc_err = 0.0
    # R1-Q1 diagnostic / novelty-design step 1: with ``shadow`` set, evaluate the exact full forward at EVERY
    # step (record-only, cache-isolated) and store, per step, EC's own gate signal alongside the REALIZED
    # error of whatever that step actually used. That is the same measurement the project already performs
    # for the spec gate (E1 / analyze_gate.py), so the two signals become directly comparable on one axis:
    # does the proxy predict the error the gate is trying to bound? Cost roughly doubles (one extra full
    # forward per step) -- acceptable for a diagnostic.
    shadow_on = bool(mcfg.get("shadow"))   # record-only diagnostic; off by default
    shadow: list = []
    for i in range(n):
        s, s_next = sig[i], sig[i + 1]
        sf = float(s)
        with timer("ops"):
            emb_t = adapter.embed(x)
            raw_input_change = None
            if emb_prev is not None:
                raw_input_change = float((emb_t - emb_prev).abs().mean())
            # official: pred_change = k * raw_input_change / mean|v_s|
            pred_change = None
            if k is not None and raw_input_change is not None and v_compute is not None:
                pred_change = k * raw_input_change / (float(v_compute.abs().mean()) + 1e-8)
            compute = (
                threshold <= 0.0            # identity mode
                or i < warmup               # ret_steps
                or i == n - 1               # last step always computes
                or pred_change is None      # no rate estimate / no previous input yet
                or (acc_err + pred_change) >= threshold
            )
        acc_err_at_decision = acc_err
        if compute:
            with timer("full"):
                v, emb_c, delta = adapter.embed_full(x, sf)
            with timer("ops"):
                if v_compute is not None:
                    # k = mean|v_t - v_s| / mean|emb_t - emb_s| over the interval between the last two computed steps
                    num = float((v - v_compute).abs().mean())
                    den = float((emb_c - emb_compute).abs().mean())
                    k = num / max(den, 1e-8)
                v_compute = v
                emb_compute = emb_c
                delta_prev = delta
                acc_err = 0.0
            counts["full"] += 1
            computed_steps.append(i)
            used = "easy_F"
        else:
            with timer("ops"):
                acc_err += pred_change
                v = adapter.embed_reuse(x, sf, delta_prev)
            counts["skipped"] += 1
            used = "easy_reuse"
        if shadow_on:
            with timer("shadow"):
                with _shadow_isolated(adapter):
                    fs, _, _ = adapter.embed_full(x, sf)
                counts["shadow_full"] = counts.get("shadow_full", 0) + 1
                den = fs.double().norm() + 1e-8
                shadow.append({
                    "step": i, "sigma": sf, "state": "computed" if compute else "reuse",
                    "used": used,
                    # EC's signal: the per-step increment and the accumulated value the gate compared
                    "pred_change": pred_change,
                    "acc_err_at_decision": acc_err_at_decision,
                    "acc_err_after": (acc_err_at_decision + pred_change) if pred_change is not None else None,
                    "threshold": threshold,
                    "budget_remaining": threshold - acc_err_at_decision,
                    # the REALIZED error of the velocity this step actually returned, vs the exact forward
                    "E_realized": float((acc(v).double() - fs.double()).norm() / den),
                })
        emb_prev = emb_t
        with timer("ops"):
            x = euler_update(x, v, s, s_next)
        steps.append({"step": i, "sigma": sf, "used": used})
    return SampleResult(latents=x, refresh=computed_steps, counts=counts, timing=timer.summary(),
                        steps=steps, shadow=shadow)


# --- calibration collectors -------------------------------------------------------------------------------


@torch.no_grad()
def collect_teacache_pairs(req) -> dict[str, np.ndarray]:
    """One full trajectory, recording per step the TeaCache probe rel-L1 and the output rel-L1 against the
    previous step (04_BASELINE_FIX_ZH §2.2/§3 S1). Returns arrays of length num_steps - 1.

    When the adapter exposes ``probe_parts`` (the Qwen-Image-2.1 and Krea 2 adapters do; Krea returns a
    3-tuple with the additive preshift row as the third element), the two factors of the probe
    are recorded separately as well — ``normed`` (the un-modulated block-0 input, i.e. the probe with the
    timestep modulation divided out) and the ``1 + scale`` modulation factor. This is the "detrend" arm of
    the calibration: on Qwen-Image-2.1 the factor is a near-deterministic function of sigma, so the probe's
    per-step relative change tracks the timestep rather than the state, which is what makes the official
    polynomial fit fail (R^2 ~= 0.09). Recording both lets the analysis attribute the failure.
    """
    adapter = req.adapter
    sig = torch.as_tensor(req.sigmas, dtype=torch.float32).cpu()
    n = len(sig) - 1
    x = req.x_init
    probe_prev = None
    normed_prev = None
    mod_prev = None
    v_prev = None
    has_parts = hasattr(adapter, "probe_parts")
    rows = []
    for i in range(n):
        s, s_next = sig[i], sig[i + 1]
        sf = float(s)
        if has_parts:
            parts = adapter.probe_parts(x, sf)
            normed, scale = parts[0], parts[1]
            shift = parts[2] if len(parts) > 2 else None  # Krea's block-0 modulation adds a preshift row
            mod_t = (1 + scale).float()
            m_t = normed * (1 + scale) if shift is None else normed * (1 + scale) + shift
        else:
            normed = mod_t = None
            m_t = adapter.probe(x, sf)
        v = adapter(x, sf, "full", 1).float()
        if probe_prev is not None:
            rel_probe = float((m_t - probe_prev).abs().mean() / (probe_prev.abs().mean() + 1e-8))
            rel_out = float((v - v_prev).abs().mean() / (v_prev.abs().mean() + 1e-8))
            row = [i, sf, rel_probe, rel_out]
            if has_parts:
                nf = normed.float()
                row += [
                    # content-only signal: relative change with the timestep factor divided out
                    float((nf - normed_prev).abs().mean() / (normed_prev.abs().mean() + 1e-8)),
                    # direction-only content signal (LayerNorm'd tokens have near-constant magnitude)
                    float(1.0 - torch.nn.functional.cosine_similarity(
                        nf.flatten(1), normed_prev.flatten(1), dim=1).mean()),
                    # the timestep trend itself
                    float((mod_t - mod_prev).abs().mean() / (mod_prev.abs().mean() + 1e-8)),
                    float(mod_t.abs().mean()),
                ]
            rows.append(row)
        probe_prev = m_t
        if has_parts:
            normed_prev = normed.float()
            mod_prev = mod_t
        v_prev = v
        x = euler_update(x, v, s, s_next)
    keys = ["step_idx", "sigma", "rel_l1_probe", "rel_l1_out"]
    if has_parts:
        keys += ["rel_l1_normed", "cos_dist_normed", "rel_l1_mod", "mod_abs"]
    return {
        key: np.array([r[j] for r in rows], dtype=np.int32 if key == "step_idx" else np.float64)
        for j, key in enumerate(keys)
    }


@torch.no_grad()
def collect_magcache_ratios(transformer, req) -> list[float]:
    """One full trajectory under ``MagCacheConfig(calibrate=True)``; returns the per-step magnitude ratios.

    The hook's auto-reset fires when its step counter reaches ``num_inference_steps``, wiping the ratios, so
    calibration runs with ``num_inference_steps = n + 1`` (calibration never skips, so this only defers the
    reset/print); the ratios are read back from the hook state here instead.
    """
    from diffusers.hooks.mag_cache import _MAG_CACHE_LEADER_BLOCK_HOOK, MagCacheConfig

    from .official_hooks import detach_official_cache, reset_hook_state

    adapter = req.adapter
    sig = torch.as_tensor(req.sigmas, dtype=torch.float32).cpu()
    n = len(sig) - 1
    transformer.enable_cache(MagCacheConfig(num_inference_steps=n + 1, calibrate=True))
    try:
        reset_hook_state(transformer)
        adapter.begin()
        x = req.x_init
        for i in range(n):
            s, s_next = sig[i], sig[i + 1]
            v = adapter(x, float(s), "full", 1)
            x = euler_update(x, v, s, s_next)
        hook = transformer.transformer_blocks[0]._diffusers_hook.get_hook(_MAG_CACHE_LEADER_BLOCK_HOOK)
        ratios = list(hook.state_manager._state_cache["cond"].calibration_ratios)
    finally:
        detach_official_cache(transformer)
    if len(ratios) != n:
        raise RuntimeError(f"magcache calibration collected {len(ratios)} ratios for {n} steps")
    return [float(r) for r in ratios]
