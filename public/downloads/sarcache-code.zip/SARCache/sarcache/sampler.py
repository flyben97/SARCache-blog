"""Euler sampling on the full-resolution sigma grid with cross-resolution difference reuse (proposal Sec. 3, 5.1).

Predictors at non-refresh steps (refresh steps always use the exact full output ``F_r``):

  exact        ``F_t`` every step (the baseline; the refresh list is ignored)
  diff         ``G_t + D_r`` with ``D_r = F_r - G_r``            -- the proposed method
  fcache       ``F_r``                                            -- zero-order full-output cache
  stale_g      ``G_r + D_r`` computed explicitly                  -- must equal ``fcache`` (Sec. 3.3 control)
  coarse_only  ``G_t``                                            -- ablation D = 0
  linear_f     ``F_r2 + (F_r2 - F_r1)(sigma_t - sigma_r2)/(sigma_r2 - sigma_r1)`` -- first-order output forecast
  diff_linear  ``G_t + lin(D_r1, D_r2)(sigma_t)``                 -- extension only: matched-order control for
                                                                    ``linear_f``; not the first-version mechanism
  spec         speculative draft-verify: draft ``G_t + D_r`` every non-refresh step; when the draft diverges
               from the free linear forecast of F by more than ``spec_threshold`` (relative L2), pay a full
               forward to verify/refresh (capped at ``num_full`` total full forwards). ``refresh`` lists the
               mandatory initial full steps (default [0, 1]). Verification updates both D and the F history.
               ``spec_tail_full`` forces the last k steps to be full (detail-formation phase);
               ``spec_tail_in_budget`` reserves those k slots inside ``num_full`` (fair-cost variant);
               ``spec_hf_gate`` tightens the gate on the block-high-frequency band (threshold
               ``spec_threshold * spec_hf_gate``) so texture-level draft errors trigger verification;
               ``spec_tau_end`` ramps the threshold linearly from ``spec_threshold`` to this value
               over the trajectory (a smaller end value protects the detail phase);
               ``spec_draft_order=1`` extrapolates the cached difference linearly inside the draft;
               ``spec_ref_order=2`` uses a quadratic (Newton) reference forecast from three points;
               ``spec_ref_hi_damp`` ([0,1]) damps that forecast's zero-mean (texture) band toward the
               last verified value (1 = undamped): texture evolves fast, so polynomial extrapolation
               overshoots there and pollutes the gate divergence and the fusion weighting;
               (10-08: FALSIFIED — the hi-band divergence is load-bearing for the gate);
               ``spec_gate_learned`` (path to a scripts/train_gate.py checkpoint) replaces the
               div > tau decision with a tiny MLP's predicted committed-error increment vs a
               saved threshold — trained on spec_shadow_full dumps (real per-step error labels,
               §8.81). Fusion/drift/feedback/ladder/tail all compose; scalar-gate shapings
               (hf_gate/gate_mean/gate_sub/autotau/tau_end/step_weight/wprofile) are rejected;
               ``spec_step_weight`` gates on the committed-error estimate (divergence x step size);
               ``spec_fusion`` replaces accepted drafts with an inverse-error empirical fusion of
               draft and forecast (inverse of the online MSE vs verified truth as the weight);
               ``spec_fusion_band`` refines this to per-band weights (block-constant vs
               zero-mean orthogonal split), letting the draft win where it is reliable and the
               forecast where it is not;
               ``spec_fusion_mode`` (none|fixed05|select|scalar|band) is the explicit form of the
               accepted-step combination rule (E2 fusion ablation): ``none`` uses the draft as-is,
               ``fixed05`` uses 0.5*draft + 0.5*forecast, ``select`` commits to whichever predictor
               has the lower accumulated error, ``scalar`` a single inverse-error weight, ``band``
               the per-band weights. The legacy flags are aliases: spec_fusion+band == band,
               spec_fusion alone == scalar, neither == none; conflicting spellings raise;
               ``spec_fusion3`` (R10-a) extends the fusion to THREE members: the draft, the
               forecast, and ``f_ref`` (the last exact velocity — stale but exact content; its
               per-band error ``||fa - f_ref||`` accumulates at verifies, weights stay inverse-
               error normalized, band mode blends the lo band over all three and commits the hi
               band to the member with the smallest accumulated hi error, select picks among the
               three; commit-only — no interaction with the gate or the budget);
               ``spec_reuse_cap`` (R10-b) bounds the reuse span: more than k steps since the last
               full forward force a verify even when the gate is silent (and past the budget),
               i.e. at most k consecutive reuse steps between verifies;
               ``spec_coarse_acc_gate`` (R11) adds a second, ORed gate on the accumulated
               relative step-to-step drift of the cheap coarse output: C += ||acc(g_t) -
               acc(g_{t-1})|| / ||acc(g_t)|| at every reuse step, a verify (and C reset) when
               C > tau_c, C reset at every verify and the drift reference reset at full steps;
               the spec_tau_end ramp touches only the divergence gate, not this one;
               ``spec_shadow_full`` (E1/E04 diagnostics) additionally evaluates the exact full
               forward ``F_i`` on the *current accelerated latent* at every step, record-only:
               it never updates ``x``, the difference/reference histories, the fusion statistics,
               the gate or the budget. Adapter cache state is isolated and restored around the
               call, and shadow forwards are counted/timed separately (``shadow_full`` / ``shadow``);
               ``spec_nodraft`` (R1 separation probe, §8.12d) removes the coarse forward entirely:
               no draft and no D cache are ever built, the gate signal degrades to the second
               difference of the frozen F history (discrete curvature of the velocity,
               ``‖f2 − 2 f1 + f0‖ / ‖f2‖``), and a non-refresh step verifies when the accumulated
               curvature since the last refresh exceeds ``spec_threshold``
               (``curv * (i − last_full_i) > τ``, same ``num_full`` budget). Reuse steps commit
               to the pure time extrapolation ``_spec_forecast`` (no fusion — the fusion weights
               are calibrated against the draft, which no longer exists);
               ``spec_feedback`` (EMA rate) applies closed-loop integral control: the draft error
               measured at each verification is fed back to correct subsequent drafts;
               ``spec_ladder`` resolves a triggered gate with a mid-resolution (f=2) draft first
               (~17% of full cost) and only pays the full forward when the mid rung also fails;
               ``spec_autotau`` (EMA rate) self-calibrates the gate: at each verification the ratio
               between the true committed draft error and the gating divergence updates a
               log-space EMA calibration factor, so the gate fires on a bias-corrected error
               estimate and ``spec_threshold`` keeps error units across prompts/schedules;
               ``spec_draft_f2_tail`` upgrades the draft to a mid-resolution (f=2) forward with its
               own difference cache D2 for the last k steps (detail-formation phase); the first
               tail step always verifies (one extra full forward, not charged to ``num_full``) so
               D2 is seeded before any tail draft is trusted, and later tail verifies refresh D2;
               ``spec_drift`` (drift-corrected reuse, state.md §8.37 mechanism B) is an additive
               commit modifier: whatever the accepted-step commit chain produced (the plain
               draft, or the fusion output when combined with spec_fusion/spec_fusion_band)
               gets ``+ (beta - 1) * (G_t - G_ref)``, the coarse-estimated temporal drift since
               the last full/verify step (the lifted coarse drift is block-constant, i.e. purely
               low-band; the commit's high band is untouched). beta (``spec_drift_weight``) = 1.0
               leaves the underlying commit bitwise unchanged — with fusion off that is the plain
               draft (draft = G_t + (F_ref - G_ref)); the gate, the draft and the refresh schedule
               are untouched, so cost and speedup are identical at the same tau. ``spec_drift_cal``
               (mechanism A, verification-as-supervision) fits beta online by closed-form least
               squares against the drift observed at each verify step
               (``beta* = <D, F_t - F_ref> / <D, D>`` with D = G_t - G_ref; two per-prompt
               accumulators, no gradients, no cross-prompt leakage, clamped to [0, 2]); until the
               first verification beta = spec_drift_weight;
               ``spec_gate_sub`` (rank k) replaces the scalar gate with an error-subspace gate:
               residuals measured at past verifications span the directions in which the cheap
               predictors actually err; the gate fires when the projection of the current
               draft--forecast divergence onto that subspace (top-k SVD of a strided <=4096-dim
               subsample, buffer of the last 32 residuals) exceeds ``spec_threshold``, with a
               raw-divergence safety net at 1.5x tau for error modes outside the subspace
               (mutually exclusive with ``spec_hf_gate`` / ``spec_autotau``);
               ``spec_defer_verify`` (SpeCa-style no-rollback acceptance, §8.76 graft): a
               gate-triggered verify does not pay the full forward immediately — the fire step
               commits the accepted-step candidate (draft/fusion) as usual and schedules the
               verify for the NEXT step; there the gate is re-evaluated for free (the draft is
               computed anyway) and the full forward is paid only if the gate still fires
               (persistent drift), otherwise the schedule is cancelled and the budget banked
               (transient-fire filter). Forced verifies (reuse cap, f2-tail D2 seed, mandatory
               refresh steps) are never deferred; a fire on the last step verifies immediately.
               Cost equals the immediate-verify run when the schedule executes and is strictly
               cheaper when it cancels; the deferred fire step commits the draft/fusion instead
               of the exact velocity, so the pilot must show iso-speed quality >= the
               immediate-verify champion or the arm is falsified (10-07 pilot: FALSIFIED, cancel
               rate 0, −12~16dB — immediate correction is the trajectory-pinning mechanism, §8.78 四续);
               ``spec_verify_tok_ratio`` (Krea 2 only; the Qwen-Image-2.1 adapter has no partial_forward):
               a gate-triggered verify is executed as a PARTIAL refresh instead of a full forward —
               the top-ratio patches by per-patch |draft − forecast| disagreement are recomputed
               exactly through ``model.partial_forward`` and merged into the draft commit, so each
               verify costs ~ratio of a full forward instead of 1.0 (immediate correction is kept —
               the defer lesson: never delay it). The correction is COMMIT-ONLY: it persists through
               the latent (the next draft re-reads it via g(x)), and deliberately nothing else
               updates — a merged-output d_cache refresh re-imports this step's g-transients with
               inverted sign onto the selected patches and the gate then burns fulls re-cleaning
               them (falsified on the toy CPU test), so d_cache/d_hist/f_hist/fusion calibration/
               autotau/feedback/R11 all stay untouched and full verifies own the cache refreshes.
               Forced verifies (reuse cap, f2-tail D2 seed) stay full; full forwards in the spec
               flow route through partial_forward's all-true path (bitwise the regular full
               forward, same trick as spec_tok's step 0) to keep its K/V cache fresh. The first
               partial call per prompt is cold (empty cache) and runs a full forward, so the saving
               materializes from the second verify on. Speedup is honest (wall-clock timing);
               counts["verify_tok"] tracks partials and they do NOT consume num_full;
               for free. The ladder is a no-op in tail steps (the draft already is the mid rung)
               and ``spec_draft_order`` applies only outside the tail.
  spec_replay  fixed-schedule replay (E03 control): full forwards exactly at ``refresh`` (a uniform
               schedule when only ``num_full`` is given; per-(prompt, seed) schedules are resolved by
               ``scripts/run_methods.py`` from the ``spec_replay_schedule`` JSON file written by
               ``scripts/extract_refresh_schedule.py``), draft + forecast + fusion on all other steps,
               gate disabled (no verification, no budget). Every replayed full forward also calibrates
               the fusion statistics, so fusion variants remain meaningful under replay.
  spec_tok     token-level partial refresh (architecture-level mechanism, no step skipping, no coarse
               forward, no gate): every step selects a patch subset S -- the top-``spec_tok_ratio``
               fraction of patches ranked by the per-patch L2 of the committed-velocity increment
               ``||v_prev - v_prevprev||`` (block-averaged onto the model's patch grid), plus a
               ``spec_tok_eps`` fraction of uniform-random patches (per-step seed derived from the
               ``seed`` argument and the step index, so selection is reproducible per (prompt, seed))
               -- and recomputes exactly those image tokens at full resolution through
               ``model.partial_forward(x, sigma, mask)``; unselected patches are copied from the
               previous committed velocity. Step 0 is always a full forward (all-true mask through
               the same entry point) that seeds the adapter-side per-layer K/V cache and the velocity
               history; step 1 has no increment history yet and falls back to a uniform-random
               selection at the same ratio. ``spec_tok_ratio_end`` ramps the ratio linearly from the
               sigma=1 end (early steps) to this value at the sigma->0 end (None = constant).
               Krea 2 Raw only for now (``Krea2Adapter.partial_forward``; Qwen-Image raises
               NotImplementedError). ``refresh`` / ``num_full`` do not apply (no budget machinery).
  spec_skip    drift-gated deep-block skipping (architecture-level mechanism R9): every step runs the
               shallow path (``fb_first`` block-0 forward + ``fb_reuse`` norm_out/proj_out on a stale
               residual); the deep stack (``fb_full``) runs only at step 0, during the first
               ``spec_skip_warmup`` steps, over the last ``spec_skip_tail`` steps, or when the gate
               fires. The gate is SeaCache-style on the LATENT drift ``rel = ||x - x_ref|| / ||x_ref||``
               (pilot falsification: the block-0-output drift is not discriminative;
               ``spec_skip_tau_end`` ramps tau linearly over the trajectory), plus a bridge trigger
               ``||beta_vec * (h0 - h0_ref)|| / ||residual_ref|| > tau`` on the predicted
               drift-corrected residual displacement. Unlike frozen-residual caching (fbcache), the
               reused residual is explicitly drift-corrected: ``residual_used = residual_ref +
               beta_vec * (h0 - h0_ref)`` with a DIAGONAL bridge — beta_vec is fitted online per
               channel (the hidden D dim of ``[B, L, D]``; the residual channel dim in general) by
               least squares across deep steps (``num[d] += <d_residual, d_h0>_d``, ``den[d] +=
               <d_h0, d_h0>_d`` between consecutive reference pairs; den == 0 channels fall back
               to 1.0; clamped to [0, 2] per channel; beta = 1.0 before the first fit). A scalar
               bridge under-corrected (pilot death cause 1). Each deep step is a free label for
               the fit. Qwen-Image-2.1 only (the fb hooks); ``refresh`` / ``num_full`` / coarse
               view / gate knobs of the spec family do not apply; tau = 0 degenerates to
               compute-every-step (identity anchor, like freqca_thresh = 0). Timing buckets:
               ``shallow`` (fb_first + fb_reuse) vs ``deep`` (fb_full); counts: ``full`` = deep
               steps, ``coarse`` = shallow steps.
  teacache     TeaCache (2411.19108) output-level reproduction: accumulated polynomial-rescaled rel-L1
               distance of the block-0 modulated input (via the model's ``probe``) gates velocity reuse;
               step 0 and the last step always compute. Qwen-Image coefficients from vLLM-Omni.
  taylor_f     TaylorSeer-lite (2503.06923) on the velocity output: Newton divided-difference
               extrapolation of order ``taylor_order`` from the last refresh steps (uniform schedule).
  easycache    EasyCache (2507.02860) output-level reproduction: reuse the last velocity while the
               accumulated observed relative-change rate stays under ``easy_thresh``.
  fbcache      FirstBlockCache (ParaAttention / diffusers ``FirstBlockCache``): per-step rel-L1 change of
               the block-0 output gates reuse of the cached (last-block − block-0) hidden residual; reuse
               applies it to the current block-0 output before norm_out/proj_out. Step 0 and the last
               step always compute.
  sarcache      SeaCache-core (§8.87, embed-capable adapters): the embed (img_in) probe is the cheap
               drift signal; the gate accumulates the probe rel-L1 (SeaCache semantics,
               ``sarcache_thresh``); compute steps run ``embed_full`` (velocity + fresh hidden
               residual hN−embed), reuse steps commit ``embed_reuse(current embed, residual)``.
               order=1 extrapolates the residual; max_reuse caps consecutive reuses
               (max_consecutive_cached=2); step 0 and the last step always compute.
               sarcache_raw_residual=True (v3, 10-08) commits the UNFILTERED extrapolated residual
               with the extrapolation in step-index space -- the official hook never filters the
               residual (the Wiener lives only in its gate indicator); the filtered commit path
               was v2's death cause ② (mean-norm DC amplification, §8.87 五续).
               forecast_age_window (SARCache §3): the explicit age window a of the linear forecast
               -- a reuse step at age i-j <= a extrapolates r_j + (i-j)/(j-k) * (r_j - r_k),
               older steps hold r_j; {0,1,2,3,4,"unbounded"}; None = the legacy sarcache_order map
               (0 -> a=0 hold, 1 -> unbounded, 2 -> a=2). sarcache_fixed_refresh: a fixed
               zero-based full-position list replayed verbatim (gate/cap/warmup bypassed).
  freqca       FreqCa (arXiv:2510.08669, Sec. 3) faithful reimplementation, output-level: the model output
               plays the role of the paper's Cumulative Residual Feature (CRF). Each computed output is
               split into low/high frequency bands (``freqca_transform``: FFT or DCT over the spatial
               dims, ``freqca_low_ratio`` fraction of the spectrum kept as low). At cache steps the low
               band is reused directly (paper: "cache-then-reuse" for the similar low frequencies) and the
               high band is extrapolated with a second-order Hermite-series predictor fitted by least
               squares on the ``freqca_hermite_k`` most recent computed steps (paper Eq. for
               ``h_i(s_t) = sum_k c_{i,k} He_k(s_t)`` with m = 2 on normalized time s_t in [-1, 1]).
               The schedule is either the paper's fixed interval (``freqca_interval`` = N: full forward
               every N steps) or an online gate (``freqca_thresh``): the accumulated relative change of
               the latent's own low band (input-side similarity probe, output-level analogue of the
               paper's similarity criterion) refreshes the cache when it reaches the threshold.
               ``freqca_thresh=0`` degenerates to step-by-step full compute (identity). Steps 0, 1 and
               the last step always compute (history seeding + detail phase).

The coarse view (``aligned`` / ``naive`` / ``subsample``) and the factor are orthogonal switches.
"""
from __future__ import annotations

import math
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from typing import Protocol, Sequence

import numpy as np
import torch

from .operators import CoarseView, low_high_split, sea_wiener_filter
from .schedules import uniform_refresh, validate_refresh
from .timing import Timer

PREDICTORS = ("exact", "diff", "fcache", "stale_g", "coarse_only", "linear_f", "diff_linear", "spec",
              "spec_replay", "spec_tok", "spec_skip", "teacache", "taylor_f", "easycache", "fbcache",
              "freqca", "sarcache", "seacache")

FUSION_MODES = ("none", "fixed05", "select", "scalar", "band")


class VelocityModel(Protocol):
    """A frozen denoiser in ``dx/dsigma`` units that accepts any supported latent grid.

    ``role`` is ``"full"`` or ``"coarse"``; ``factor`` is the coarse factor (1 for full) so adapters can build
    resolution-specific positional inputs.
    """

    def __call__(self, x: torch.Tensor, sigma: float, role: str = "full", factor: int = 1) -> torch.Tensor: ...


@dataclass
class Method:
    name: str = "full"
    predictor: str = "exact"
    factor: int = 4
    coarse_mode: str = "aligned"
    refresh: list[int] | None = None
    num_full: int | None = None
    num_steps: int | None = None
    coarse_positions: str | None = None
    spec_threshold: float | None = None
    spec_tail_full: int = 0
    spec_hf_gate: float | None = None
    spec_tail_in_budget: bool = False
    spec_tau_end: float | None = None
    teacache_thresh: float | None = None
    fb_thresh: float | None = None
    taylor_order: int = 2
    easy_thresh: float | None = None
    spec_draft_order: int = 0
    spec_ref_order: int = 1
    spec_step_weight: bool = False
    # Controlled error-source manipulation for the independence study (docs/NOVELTY_DESIGN_ZH.md, candidate
    # A). The reuse-step draft evaluates the SAME cheap estimator at a sigma shifted by this amount, while
    # the cross-resolution residual D is still measured at the correct sigma. So the draft becomes "an
    # otherwise-correct estimator with a pure timestep-misalignment error", and sweeping this value varies
    # the ERROR SOURCE while holding the estimator, its cost and the architecture fixed -- which is what an
    # independence experiment needs. 0.0 keeps the standard draft (bitwise unchanged).
    spec_draft_sigma_offset: float = 0.0
    spec_fusion: bool = False
    spec_fusion3: bool = False              # R10-a: three-way fusion (draft / forecast / f_ref)
    spec_feedback: float | None = None
    spec_ladder: bool = False
    spec_autotau: float | None = None
    spec_draft_f2_tail: int = 0
    spec_gate_sub: int | None = None
    spec_fusion_band: bool = False
    spec_fusion_mode: str | None = None
    spec_reuse_cap: int | None = None       # R10-b: max reuse steps since the last verify
    spec_coarse_acc_gate: float | None = None  # R11: accumulated relative coarse-drift gate (OR with the divergence gate)
    spec_shadow_full: bool = False
    # spec_distill: use a distilled draft net (model.draft_net) instead of the CoarseView coarse
    # forward. The draft is a full-grid fp32 velocity student, so acc(g) + d_cache stays a drop-in
    # for everything downstream (gate, drift, fusion, R11).
    spec_distill: bool = False
    spec_nodraft: bool = False
    spec_gate_mean: bool = False
    # spec_gate_predict (predictive firing): fire when sig + alpha*(sig - sig_prev) > tau, i.e.
    # a rising gate signal is predicted to cross the threshold one step ahead and the correction
    # lands before the drift accrues. Same information, better timing — no extra forward. The
    # seed sig_prev is tagged with last_full_i and invalidated by any verify/refresh (slope
    # across a reset is meaningless), giving a one-step cooldown after each correction.
    spec_gate_predict: float | None = None
    spec_drift: bool = False
    spec_drift_weight: float = 1.0
    spec_drift_cal: bool = False
    spec_replay_schedule: str | None = None
    # spec_fixed_refresh (§8.60): fixed refresh-position schedule for the spec predictor — the
    # verify gate is disabled (non-refresh steps never promote) but ALL other spec machinery
    # (distill draft, fusion, band fusion, drift, sigma offset, shadow) stays active, unlike
    # spec_replay which also loses drift. Positions are greedy-oracle-derived (reports/v7_step_weights.json).
    spec_fixed_refresh: list[int] | None = None
    # spec_gate_wprofile (§8.64): JSON path to a per-step sensitivity profile
    # ({"sensitivity": {step: w}}); the verify divergence is multiplied by w[i] (mean-1
    # normalized), so steps whose velocity errors amplify the most downstream (mid-trajectory)
    # get a proportionally tighter gate. The profile's relative structure is what matters.
    spec_gate_wprofile: str | None = None
    # spec_defer_verify (SpeCa no-rollback acceptance): a gate-triggered verify is scheduled
    # for the next step instead of paid immediately; the next step's (free) gate re-check
    # executes it only on persistent drift, otherwise cancels and banks the budget.
    spec_defer_verify: bool = False
    # spec_verify_tok_ratio (partial verify, Krea 2 only): a gate-triggered verify recomputes
    # only the top-ratio disagreement patches exactly (model.partial_forward) merged into the
    # draft commit, instead of paying a full forward. Commit-only correction (persists through
    # the latent); all cache/history state stays with the full verifies. Forced verifies stay
    # full. None = full verifies (default).
    spec_verify_tok_ratio: float | None = None
    # spec_ref_hi_damp (forecast hi-band damping): the free forecast's zero-mean (texture)
    # band is damped toward the last verified value — hi = last + damp*(extrap − last) —
    # because time-polynomial extrapolation overshoots the fast-evolving texture band and
    # pollutes the gate divergence + fusion weighting. 1.0 = undamped (default); 0 = freeze.
    # (FALSIFIED 10-08: damping blinds the gate to texture drift — the hi-band divergence
    # is load-bearing; forecast accuracy upgrades must ADD information, not remove it.)
    spec_ref_hi_damp: float | None = None
    # spec_gate_learned: path to a gate checkpoint from scripts/train_gate.py (tiny MLP on
    # inference-free shadow features predicting the committed-error increment). Replaces
    # the div > tau decision with pred_err > thr at iso-budget (§8.81). None = tau gate.
    spec_gate_learned: str | None = None
    # spec_gate_learned_rate: when set with spec_gate_learned, replaces the fixed checkpoint
    # threshold with a per-trajectory quantile tracker: fire when the prediction exceeds the
    # (1 - rate) quantile of the prediction stream (warm-started with the ckpt thr) — fixing
    # the closed-loop threshold-transfer failure (§8.81 八续: the gate's own trajectory drifts
    # less than the training trajectories, so a fixed thr settles far below the target rate).
    # Side benefit: per-prompt difficulty-adaptive verify allocation (the prompt's own worst
    # steps get its budget), the drift-budget-allocation idea of §8.62 in learned form.
    # (LINE FALSIFIED 10-08 §8.82: the offline error model does not transfer across the
    # closed-loop shift — the machinery stays as the ablation record.)
    spec_gate_learned_rate: float | None = None
    # spec_fusion_sea (Krea 2 only, §8.83): replace the fusion3 f_ref member with a
    # SeaCache-style Wiener-filtered hidden-residual reuse — verify steps capture
    # (velocity, embed, hN-embed) via the adapter's embed_full (same cost as the full it
    # replaces), accepted steps build the member as embed_reuse(current embed, filtered
    # residual). New CORRECT information at the unchanged schedule (the falsification-
    # family test), targeting SeaCache's commit-content advantage on Krea. REQUIRES the
    # staleness gate (spec_sea_max_age) — without it the member is calibration-poison
    # (§8.83 续: −8dB; with it: +1dB, the family's first positive salvage).
    spec_fusion_sea: bool = False
    spec_sea_a: float = 1.0            # Wiener signal level
    spec_sea_b: float = 2.0            # Wiener noise level (cutoff follows a/b)
    # spec_sea_max_age: the sea member only enters the fusion while the cached residual is
    # at most this many steps old (staleness-discount hard gate — the §8.83 salvage for the
    # stale-calibration optimism: the member's error is calibrated at verify-fresh residuals
    # but committed at older ones, so its participation must be capped by age; aged-out
    # steps fall back to the f_ref member).
    spec_sea_max_age: int = 4
    # spec_fref_max_age: the same staleness gate for the plain fusion3 f_ref member (the
    # last exact velocity is ALSO a stale member — §8.83 四续: fusion3 was falsified at
    # 1024 possibly for the same un-gated staleness; aged-out steps degrade to the two-
    # member draft/forecast fusion). None = ungated (legacy).
    spec_fref_max_age: int | None = None
    freqca_thresh: float | None = None
    freqca_interval: int | None = None
    freqca_low_ratio: float = 0.25
    freqca_transform: str = "fft"
    freqca_hermite_k: int = 3
    # sarcache (SeaCache-core v1, §8.87): standalone block-0-gated hidden-residual reuse for the
    # Krea 2 adapter — the embed (img_in) probe is the cheap drift signal, the gate is the
    # accumulated probe rel-L1 (SeaCache semantics), compute steps run embed_full (velocity +
    # fresh residual), reuse steps commit embed_reuse(current embed, Wiener-filtered residual).
    # If it reaches Sea-level quality on Krea mid-band it fills the ours column AT the Sea rows.
    sarcache_thresh: float | None = None
    sarcache_a: float = 1.0
    sarcache_b: float = 2.0
    # SeaCache-official alignment (§8.87 四续, from diffusers hooks/sea_cache.py SeaCacheConfig):
    # residual_order=1 linearly extrapolates the hidden residual from the two most recent full
    # executions (order=0 = raw reuse); max_reuse caps consecutive reuses (the official
    # max_consecutive_cached=2 staleness gate); the gate distance runs on the SEA-Wiener-filtered
    # probe (a=1-sigma, b=sigma) like the official SEA indicator.
    sarcache_order: int = 1  # 2 = official adaptive (10-09): extrapolate only within 2 steps of
    # the freshest residual (max_consecutive_cached semantics), raw reuse beyond -- long-span
    # order-1 extrapolation amplifies staleness (order-0 beat it by +1.15dB at cap 10)
    sarcache_max_reuse: int = 2
    sarcache_filter_gate: bool = True
    # sarcache_raw_residual (§10-08 v3, the §8.87-falsification fix): commit the UNFILTERED
    # extrapolated residual. The official hook never Wiener-filters the residual (the filter
    # exists only in the gate indicator) -- the mean-norm Wiener on the commit path was death
    # cause ② of v2 (DC amplification at real shapes, state.md §8.87 五续). v3 also switches the
    # extrapolation scale to STEP INDEX like the official ((i-i1)/(i1-i0)), not sigma space.
    sarcache_raw_residual: bool = False
    # sarcache_img_indicator (v3.1): gate on the official SEA indicator -- Wiener-filtered raw
    # input latent in image space, reference refreshed EVERY step (hit or compute). The v3
    # token-embedding probe with a last-compute-frozen reference lost 3.8dB at Sea's own speed.
    sarcache_img_indicator: bool = False
    # sarcache_warmup (lever ①, 10-08 night): force full computes for steps < warmup --
    # EC's structural edge in the per-prompt autopsy is its warmup_ratio=0.25 (10 of the
    # first 10 steps recomputed on every prompt), a dense early anchor our reactive gates
    # only approximate. 1 = official retention_steps=1 (no anchor).
    sarcache_warmup: int = 1
    # sarcache_output_cache (10-09): EC (EasyCache) commit semantics -- reuse steps commit the
    # STALE CACHED VELOCITY from the last compute (whole-output cache), no residual
    # recombination / no extrapolation. EC's 2.4-2.9x band strength rides on this exact-content
    # full-spectrum stale output; the residual path only re-carries hN-embed.
    sarcache_output_cache: bool = False
    # sarcache_krate (10-09): EC's propagation-rate gate (the last unaligned official semantic,
    # found by reading the vendored port): gate on k * mean|emb_t - emb_{t-1}| / mean|v_s|
    # with k = mean|v_t - v_s| / mean|emb_t - emb_s| refreshed at computed-step pairs. Uses
    # the RAW unfiltered stack input as the probe. Implies the per-step reference refresh.
    sarcache_krate: bool = False
    # forecast_age_window (SARCache §3, 10-10): the explicit age window of the linear residual
    # forecast. With fresh residuals at k < j and age = i - j: age <= a extrapolates
    # r_hat = r_j + (i-j)/(j-k) * (r_j - r_k), older reuse steps hold r_j. A single fresh
    # residual always holds; a = 0 is pure hold; "unbounded" is the legacy order-1 line; the
    # window itself never triggers a refresh (gate/warmup/cap decide that independently).
    # One of {0, 1, 2, 3, 4, "unbounded"}; None = the legacy sarcache_order compatibility map
    # (0 -> a=0, 1 -> unbounded, 2 -> a=2, bitwise identical). Giving both an explicit window
    # and a non-default order is rejected (they are two spellings of one knob).
    forecast_age_window: int | str | None = None
    # sarcache_fixed_refresh (SARCache §3, 10-10): fixed full-refresh replay for sarcache -- a list
    # of zero-based step indices run at embed_full, everything else reuses with the normal
    # fresh-residual history and forecast/hold commit semantics. The adaptive gate, the
    # staleness cap and warmup are bypassed, so sarcache_thresh must be None (the gate is off)
    # and sarcache_max_reuse / sarcache_warmup must sit at their disabled values (0 / 1);
    # sarcache_krate / sarcache_img_indicator (gate machinery) and sarcache_output_cache (a different
    # commit semantics) are rejected. Step 0 always computes (no fresh residual exists to
    # reuse); the last step is auto-appended to the schedule when the list misses it -- the
    # auto-add is marked in counts["fixed_refresh_auto_tail"] and in that step's record
    # (auto_tail_full=True). Distinct from spec_replay's spec_replay_schedule (another branch).
    sarcache_fixed_refresh: list[int] | None = None
    # spec_kf_commit (v3.1xspec hybrid, 10-08): replace the accepted-step commit with the
    # SeaCache-core residual-reuse velocity (embed_reuse on the raw step-index-extrapolated
    # whole-stack residual) whenever the cached residual is fresh (age <= spec_kf_max_age
    # steps since the last verify); stale steps commit the usual draft/fusion chain. The spec
    # reactive gate (spec_gate_mean) decides verify placement -- v3.1's own accumulated-
    # distance gate is NOT used. Verify steps capture the residual through the same embed_full
    # call fullx already makes (zero extra cost). This marries v3.1's commit content (+3dB in
    # the 1.6-2.05x band) with the spec family's per-prompt adaptive verify placement, and the
    # fusion fallback covers the staleness regime where v3.1 alone falls off its cliff.
    spec_kf_commit: bool = False
    spec_kf_max_age: int = 2
    # spec_kf_band (lever ①, 10-08 night): split the fresh-kf commit by frequency band --
    # the residual's LO band (global layout) stays valid far longer than its HI band (fast
    # texture), which is where v3.1's cliff past ~2.1x comes from. Commit = lo(kf reuse) +
    # hi(the draft/fusion chain commit). Requires spec_kf_commit.
    spec_kf_band: bool = False
    # spec_kf_mean (10-09): ensemble the fresh-kf commit with the chain commit --
    # v = (1-w)*chain + w*sar_reuse; w in (0,1). The last table rows sit 0.2-0.7dB below
    # EC; averaging two near-unbiased predictors with independent errors is the textbook
    # variance-reduction move for exactly that gap size.
    spec_kf_mean: float | None = None
    # seacache (SeaCache faithful, §8.87 三续): TeaCache's output-level cache with the reuse
    # decision on SEA-FILTERED block-0 input features — the Wiener filter takes the flow
    # schedule (a_t = 1 - sigma, b_t = sigma), so early noise-phase steps are distance-blind
    # (aggressive reuse) and late content-phase steps are fully sensitive. Plain accumulated
    # filtered rel-L1 vs seacache_thresh (the paper's delta). Output-level: computed outputs
    # are reused wholesale until the threshold trips.
    seacache_thresh: float | None = None
    seacache_power_exp: float = 2.0
    # Token-level partial refresh (spec_tok): fraction of patches recomputed at full resolution
    # every step, ranked by the committed-velocity increment ||v_prev - v_prevprev|| per patch.
    spec_tok_ratio: float | None = None
    spec_tok_ratio_end: float | None = None   # None = constant ratio; else linear ramp ratio -> this
    spec_tok_eps: float = 0.05                # extra uniform-random fraction (anti-starvation)
    spec_tok_select: str = "delta"            # reserved: only "delta" is implemented
    # Drift-gated deep-block skipping (spec_skip): gate threshold on the relative L2 of the
    # shallow-output drift (0 = always fire, the identity anchor); tau_end ramps tau linearly.
    spec_skip_tau: float | None = None
    spec_skip_tau_end: float | None = None    # None = constant tau; else linear ramp tau -> this
    spec_skip_tail: int = 2                   # last k steps always deep (detail-formation phase)
    spec_skip_warmup: int = 1                 # first k steps forced deep (seeds the bridge fit)

    def __post_init__(self):
        if self.predictor == "krea_fb":
            self.predictor = "sarcache"
        if self.predictor not in PREDICTORS:
            raise ValueError(f"unknown predictor {self.predictor!r}; expected one of {PREDICTORS}")
        if self.predictor == "spec" and self.spec_threshold is None \
                and self.spec_fixed_refresh is None:
            raise ValueError("spec predictor needs `spec_threshold` (or a fixed schedule via "
                             "`spec_fixed_refresh`)")
        if self.spec_hf_gate is not None and self.predictor != "spec":
            raise ValueError("spec_hf_gate only applies to spec")
        if self.spec_tail_full and self.predictor != "spec":
            raise ValueError("spec_tail_full only applies to spec")
        if self.spec_tail_in_budget and not self.spec_tail_full:
            raise ValueError("spec_tail_in_budget needs spec_tail_full")
        if self.spec_tau_end is not None and self.predictor != "spec":
            raise ValueError("spec_tau_end only applies to spec")
        if self.predictor == "teacache" and self.teacache_thresh is None:
            raise ValueError("teacache predictor needs `teacache_thresh`")
        if self.predictor == "fbcache" and self.fb_thresh is None:
            raise ValueError("fbcache predictor needs `fb_thresh`")
        if self.predictor == "freqca":
            if (self.freqca_thresh is None) == (self.freqca_interval is None):
                raise ValueError("freqca needs exactly one of `freqca_thresh` (online similarity gate) "
                                 "or `freqca_interval` (paper's fixed interval N)")
            if self.freqca_thresh is not None and not (self.freqca_thresh >= 0.0):
                raise ValueError("freqca_thresh must be >= 0 (0 = identity: compute every step)")
            if self.freqca_interval is not None and self.freqca_interval < 2:
                raise ValueError("freqca_interval must be >= 2")
            if not (0.0 < self.freqca_low_ratio <= 1.0):
                raise ValueError("freqca_low_ratio must be in (0, 1]")
            if self.freqca_transform not in ("fft", "dct"):
                raise ValueError("freqca_transform must be 'fft' or 'dct'")
            if self.freqca_hermite_k < 1:
                raise ValueError("freqca_hermite_k must be >= 1")
        else:
            if self.freqca_thresh is not None or self.freqca_interval is not None:
                raise ValueError("freqca_thresh / freqca_interval only apply to freqca")
            if self.freqca_low_ratio != 0.25 or self.freqca_transform != "fft" or self.freqca_hermite_k != 3:
                raise ValueError("freqca_low_ratio / freqca_transform / freqca_hermite_k only apply to freqca")
        if self.predictor == "easycache" and self.easy_thresh is None:
            raise ValueError("easycache predictor needs `easy_thresh`")
        if self.predictor == "taylor_f" and not (1 <= self.taylor_order <= 3):
            raise ValueError("taylor_order must be 1..3")
        if self.spec_draft_order and self.predictor != "spec":
            raise ValueError("spec_draft_order only applies to spec")
        if self.spec_ref_order != 1 and self.predictor != "spec":
            raise ValueError("spec_ref_order only applies to spec")
        if self.spec_draft_sigma_offset and self.predictor not in ("spec", "spec_replay"):
            raise ValueError("spec_draft_sigma_offset only applies to spec / spec_replay")
        if self.spec_step_weight and self.predictor != "spec":
            raise ValueError("spec_step_weight only applies to spec")
        if self.spec_fusion and self.predictor not in ("spec", "spec_replay"):
            raise ValueError("spec_fusion only applies to spec / spec_replay")
        if (self.spec_fusion3 or self.spec_reuse_cap is not None) and self.predictor != "spec":
            raise ValueError("spec_fusion3 / spec_reuse_cap only apply to the spec predictor "
                             "(spec_replay has no gate/commits for them)")
        if self.spec_fusion3:
            # R10-a three-way fusion: draft / forecast / f_ref (the last exact velocity).
            # Needs the fusion commit machinery: either the spec_fusion legacy flag or an
            # explicit non-"none" spec_fusion_mode (resolved in the block below).
            if not self.spec_fusion and (self.spec_fusion_mode is None
                                         or self.spec_fusion_mode == "none"):
                raise ValueError("spec_fusion3 extends the fusion commit; set spec_fusion "
                                 "(or an explicit spec_fusion_mode) too")
            if self.spec_nodraft:
                raise ValueError("spec_nodraft commits to the pure forecast; spec_fusion3 has no "
                                 "draft/fusion history to extend")
        if self.spec_reuse_cap is not None and self.spec_reuse_cap <= 0:
            raise ValueError("spec_reuse_cap must be a positive int (max reuse steps since the "
                             "last verify; None = unlimited)")
        if self.spec_coarse_acc_gate is not None:
            # R11 coarse-increment accumulator gate: needs the draft's coarse forward, so the
            # nodraft probe (no coarse at all) and every non-spec predictor are rejected;
            # spec_replay has no gate (fixed schedule) and is rejected via predictor != "spec".
            if self.predictor != "spec":
                raise ValueError("spec_coarse_acc_gate only applies to spec")
            if self.spec_coarse_acc_gate <= 0:
                raise ValueError("spec_coarse_acc_gate must be > 0 (accumulated relative-L2 "
                                 "coarse-drift threshold, same units as spec_threshold)")
            if self.spec_nodraft:
                raise ValueError("spec_nodraft has no coarse forward; spec_coarse_acc_gate "
                                 "accumulates the coarse-output drift")
        if self.spec_feedback is not None and self.predictor != "spec":
            raise ValueError("spec_feedback only applies to spec")
        if self.spec_feedback is not None and not (0.0 < self.spec_feedback <= 1.0):
            raise ValueError("spec_feedback is an EMA rate in (0, 1]")
        if self.spec_ladder and self.predictor != "spec":
            raise ValueError("spec_ladder only applies to spec")
        if self.spec_ladder and self.factor <= 2:
            raise ValueError("spec_ladder needs factor > 2 (the mid rung is factor 2)")
        if self.spec_autotau is not None and self.predictor != "spec":
            raise ValueError("spec_autotau only applies to spec")
        if self.spec_autotau is not None and not (0.0 < self.spec_autotau <= 1.0):
            raise ValueError("spec_autotau is an EMA rate in (0, 1]")
        if self.spec_autotau is not None and self.spec_hf_gate is not None:
            raise ValueError("spec_autotau calibrates the scalar gate; combine with hf_gate is undefined")
        if self.spec_draft_f2_tail and self.predictor != "spec":
            raise ValueError("spec_draft_f2_tail only applies to spec")
        if self.spec_draft_f2_tail and self.factor <= 2:
            raise ValueError("spec_draft_f2_tail needs factor > 2 (the tail draft is factor 2)")
        if self.spec_draft_f2_tail < 0:
            raise ValueError("spec_draft_f2_tail must be >= 0")
        if self.spec_gate_sub is not None and self.predictor != "spec":
            raise ValueError("spec_gate_sub only applies to spec")
        if self.spec_gate_sub is not None and self.spec_gate_sub < 1:
            raise ValueError("spec_gate_sub is the subspace rank, must be >= 1")
        if self.spec_gate_sub is not None and self.spec_hf_gate is not None:
            raise ValueError("spec_gate_sub replaces the scalar gate; combine with hf_gate is undefined")
        if self.spec_gate_sub is not None and self.spec_autotau is not None:
            raise ValueError("spec_gate_sub replaces the scalar gate; combine with autotau is undefined")
        if self.spec_fusion_band and self.predictor not in ("spec", "spec_replay"):
            raise ValueError("spec_fusion_band only applies to spec / spec_replay")
        if self.spec_fusion_band and not self.spec_fusion:
            raise ValueError("spec_fusion_band extends spec_fusion; set spec_fusion=true too")
        if not (0 <= self.spec_draft_order <= 1):
            raise ValueError("spec_draft_order must be 0 or 1")
        if not (1 <= self.spec_ref_order <= 2):
            raise ValueError("spec_ref_order must be 1 or 2")
        # Accepted-step combination rule. Legacy flags are aliases for the mode (defaults:
        # spec_fusion=false, spec_fusion_band=false -> "none"); the resolved mode is what the
        # sampler actually uses, and it is frozen into `spec_fusion_mode` for the record.
        legacy_mode = "band" if (self.spec_fusion and self.spec_fusion_band) else (
            "scalar" if self.spec_fusion else "none")
        if self.spec_fusion_mode is None:
            self.spec_fusion_mode = legacy_mode
        elif self.spec_fusion_mode not in FUSION_MODES:
            raise ValueError(f"spec_fusion_mode must be one of {FUSION_MODES}")
        elif (self.spec_fusion or self.spec_fusion_band) and self.spec_fusion_mode != legacy_mode:
            raise ValueError(f"spec_fusion_mode={self.spec_fusion_mode!r} conflicts with the legacy flags "
                             f"(spec_fusion={self.spec_fusion}, spec_fusion_band={self.spec_fusion_band} imply "
                             f"{legacy_mode!r}); use only one spelling")
        if self.spec_fusion_mode != "none" and self.predictor not in ("spec", "spec_replay"):
            raise ValueError("spec_fusion_mode only applies to spec / spec_replay")
        if self.spec_shadow_full and self.predictor not in ("spec", "spec_replay"):
            raise ValueError("spec_shadow_full only applies to spec / spec_replay")
        if self.spec_replay_schedule is not None and self.predictor != "spec_replay":
            raise ValueError("spec_replay_schedule only applies to spec_replay")
        if self.predictor == "spec_replay":
            # fixed-schedule replay: the gate (and everything that modulates it) is disabled
            if self.spec_threshold is not None:
                raise ValueError("spec_replay disables the gate; spec_threshold does not apply")
            for fld in ("spec_hf_gate", "spec_tau_end", "spec_feedback", "spec_autotau", "spec_gate_sub",
                        "spec_verify_tok_ratio"):
                if getattr(self, fld) is not None:
                    raise ValueError(f"{fld} only applies to spec (spec_replay disables the gate)")
            if self.spec_tail_full or self.spec_tail_in_budget or self.spec_step_weight \
                    or self.spec_ladder or self.spec_draft_f2_tail:
                raise ValueError("tail/ladder/step-weight options only apply to spec "
                                 "(spec_replay disables the gate)")
        if self.spec_fixed_refresh is not None:
            # fixed-schedule spec (§8.60): gate decisions come from the position list, so every
            # knob that modulates the gate decision is meaningless here.
            if self.predictor != "spec":
                raise ValueError("spec_fixed_refresh only applies to spec")
            gate_knobs = {"spec_threshold": None, "spec_hf_gate": None, "spec_tau_end": None,
                          "spec_feedback": None, "spec_autotau": None, "spec_gate_sub": None,
                          "spec_reuse_cap": None, "spec_coarse_acc_gate": None,
                          "spec_gate_mean": False, "spec_step_weight": False,
                          "spec_tail_full": 0, "spec_tail_in_budget": False,
                          "spec_defer_verify": False, "spec_verify_tok_ratio": None}
            for fld, off in gate_knobs.items():
                if getattr(self, fld) != off:
                    raise ValueError(f"{fld} is gate machinery; spec_fixed_refresh disables the gate")
            if self.spec_gate_wprofile is not None:
                raise ValueError("spec_gate_wprofile is gate machinery; spec_fixed_refresh disables the gate")
        if self.spec_gate_wprofile is not None:
            if self.predictor != "spec":
                raise ValueError("spec_gate_wprofile only applies to spec")
            for fld in ("spec_autotau", "spec_gate_sub", "spec_gate_mean", "spec_hf_gate"):
                if getattr(self, fld) is not None and getattr(self, fld) is not False:
                    raise ValueError(f"{fld} composes with the raw divergence; "
                                     "spec_gate_wprofile replaces that scaling")
        if self.spec_defer_verify:
            # SpeCa no-rollback acceptance: only the gated spec branch defers; the ladder
            # resolves a fire with a mid-rung forward at fire time (its resolution cannot be
            # moved), fixed schedules/replay have no gate, and the nodraft probe's curvature
            # gate is frozen-history machinery where deferral changes the history semantics.
            if self.predictor != "spec":
                raise ValueError("spec_defer_verify only applies to spec")
            if self.spec_fixed_refresh is not None:
                raise ValueError("spec_defer_verify needs the gate; spec_fixed_refresh disables it")
            if self.spec_ladder:
                raise ValueError("spec_defer_verify composes with the immediate-verify resolution; "
                                 "the ladder resolves fires at fire time — pick one")
            if self.spec_nodraft:
                raise ValueError("spec_nodraft's frozen-history curvature gate defers differently; "
                                 "combination undefined")
        if self.spec_verify_tok_ratio is not None:
            # partial verify (Krea 2 only): needs the gated spec branch, the partial_forward
            # adapter capability (checked again at sampling time), and no competing verify
            # execution modifier. Deferral is empirically falsified (§8.78) and composes
            # ambiguously — reject.
            if self.predictor != "spec":
                raise ValueError("spec_verify_tok_ratio only applies to spec")
            if not (0.0 < self.spec_verify_tok_ratio <= 1.0):
                raise ValueError("spec_verify_tok_ratio must be in (0, 1] (fraction of patches "
                                 "recomputed exactly at a gate-triggered verify)")
            if self.spec_ladder:
                raise ValueError("spec_verify_tok_ratio replaces the full verify; the ladder "
                                 "resolves fires differently — pick one")
            if self.spec_defer_verify:
                raise ValueError("spec_defer_verify is falsified (§8.78) and composes ambiguously "
                                 "with partial verify — pick one")
            if self.spec_nodraft:
                raise ValueError("spec_nodraft has no draft to merge the partial refresh into")
        if self.spec_ref_hi_damp is not None:
            # forecast hi-band damping: the forecast exists on the spec/replay branch and the
            # nodraft probe (where it IS the commit); the band split needs factor > 1.
            if self.predictor not in ("spec", "spec_replay"):
                raise ValueError("spec_ref_hi_damp only applies to spec / spec_replay")
            if not (0.0 <= self.spec_ref_hi_damp <= 1.0):
                raise ValueError("spec_ref_hi_damp must be in [0, 1] (1 = undamped)")
            if self.factor <= 1:
                raise ValueError("spec_ref_hi_damp needs factor > 1 (the low/high band split)")
        if self.predictor == "sarcache":
            if self.sarcache_thresh is None and self.sarcache_fixed_refresh is None:
                raise ValueError("sarcache needs sarcache_thresh (accumulated probe rel-L1 gate) "
                                 "unless sarcache_fixed_refresh fixes the refresh schedule")
            if self.sarcache_thresh is not None and self.sarcache_thresh < 0:
                raise ValueError("sarcache_thresh must be >= 0 (0 = compute every step)")
            if not (0.0 < self.sarcache_a and 0.0 < self.sarcache_b):
                raise ValueError("sarcache_a / sarcache_b must be positive (Wiener signal/noise)")
            if self.sarcache_order not in (0, 1, 2):
                raise ValueError("sarcache_order must be 0 (raw reuse), 1 (always extrapolate), "
                                 "or 2 (official adaptive: extrapolate within 2 steps of the "
                                 "freshest residual, raw beyond -- 10-09: long-span extrapolation "
                                 "amplifies staleness, order-0 won at cap 10 (+1.15dB))")
            if self.sarcache_max_reuse < 0:
                raise ValueError("sarcache_max_reuse must be >= 0 (0 disables the staleness cap)")
            if self.sarcache_img_indicator and not self.sarcache_raw_residual:
                raise ValueError("sarcache_img_indicator is the official v3.1 gate (image-space SEA "
                                 "indicator, per-step reference); it requires sarcache_raw_residual "
                                 "(the official commit never filters the residual)")
            if self.forecast_age_window is not None:
                # SARCache §3: the explicit age window generalizes sarcache_order=2 (and the
                # order 0/1/2 map onto a=0/unbounded/a=2); the two spellings must not mix.
                _w = self.forecast_age_window
                if isinstance(_w, bool) or (isinstance(_w, int) and not 0 <= _w <= 4) \
                        or (not isinstance(_w, int) and _w != "unbounded"):
                    raise ValueError("forecast_age_window must be one of {0,1,2,3,4,'unbounded'} "
                                     "(None = the legacy sarcache_order map: 0->a=0, 1->unbounded, "
                                     "2->a=2)")
                if self.sarcache_order != 1:
                    raise ValueError("forecast_age_window and an explicit sarcache_order are two "
                                     "spellings of one knob (0->a=0, 1->unbounded, 2->a=2); "
                                     "set only one")
        if self.sarcache_fixed_refresh is not None:
            # SARCache §3 fixed refresh replay: the position list IS the refresh schedule, so
            # every knob that modulates the adaptive gate decision is rejected here (same
            # discipline as spec_fixed_refresh above).
            if self.predictor != "sarcache":
                raise ValueError("sarcache_fixed_refresh only applies to sarcache")
            if self.sarcache_thresh is not None:
                raise ValueError("sarcache_fixed_refresh disables the gate; sarcache_thresh must be None")
            for _fld, _off in (("sarcache_max_reuse", 0), ("sarcache_warmup", 1)):
                if getattr(self, _fld) != _off:
                    raise ValueError(f"{_fld} is gate machinery; sarcache_fixed_refresh bypasses "
                                     f"the gate/cap/warmup -- leave it at its disabled value {_off}")
            for _fld in ("sarcache_krate", "sarcache_img_indicator"):
                if getattr(self, _fld):
                    raise ValueError(f"{_fld} is gate machinery; sarcache_fixed_refresh bypasses "
                                     "the gate")
            if self.sarcache_output_cache:
                raise ValueError("sarcache_output_cache commits the stale cached velocity; "
                                 "sarcache_fixed_refresh replays the residual-reuse schedule -- "
                                 "pick one")
        if self.predictor == "seacache":
            if self.seacache_thresh is None:
                raise ValueError("seacache needs seacache_thresh (accumulated filtered rel-L1, the paper's delta)")
            if self.seacache_thresh < 0:
                raise ValueError("seacache_thresh must be >= 0 (0 = reuse only on exact-zero distance)")
        if self.spec_gate_learned is not None:
            # learned verify gate (§8.81): replaces the scalar div > tau decision with a
            # trained predictor on inference-free features. Reject every knob that shapes
            # or replaces the scalar gate (they address the div signal the learned gate
            # does not use); fusion/drift/feedback/ladder/tail verify-execution all compose.
            if self.predictor != "spec":
                raise ValueError("spec_gate_learned only applies to spec")
            for fld in ("spec_hf_gate", "spec_tau_end", "spec_step_weight", "spec_autotau",
                        "spec_gate_sub", "spec_gate_mean", "spec_gate_wprofile"):
                if getattr(self, fld) is not None and getattr(self, fld) is not False:
                    raise ValueError(f"{fld} shapes or replaces the scalar gate; "
                                     "spec_gate_learned replaces the div > tau decision — pick one")
            if self.spec_fixed_refresh is not None or self.spec_nodraft:
                raise ValueError("spec_gate_learned needs the gated spec branch")
        if self.spec_gate_learned_rate is not None:
            if self.spec_gate_learned is None:
                raise ValueError("spec_gate_learned_rate needs spec_gate_learned (the checkpoint)")
            if not (0.0 < self.spec_gate_learned_rate < 1.0):
                raise ValueError("spec_gate_learned_rate must be in (0, 1) (target verify fraction)")
        if self.spec_fref_max_age is not None:
            # staleness gate on the plain fusion3 f_ref member — standalone (no sea needed)
            if self.predictor != "spec":
                raise ValueError("spec_fref_max_age only applies to spec")
            if not (self.spec_fusion and self.spec_fusion3):
                raise ValueError("spec_fref_max_age gates the fusion3 f_ref member (set spec_fusion "
                                 "and spec_fusion3)")
            if self.spec_fref_max_age < 1:
                raise ValueError("spec_fref_max_age must be >= 1 or None (staleness gate on the f_ref member)")
        if self.spec_fusion_sea:
            # the sea member replaces the fusion3 f_ref slot: the three-way machinery must
            # be on, and the cheap reuse pass is Krea-only (embed_full/embed_reuse, cfg=0).
            if self.predictor != "spec":
                raise ValueError("spec_fusion_sea only applies to spec")
            if not (self.spec_fusion and self.spec_fusion3):
                raise ValueError("spec_fusion_sea rides the three-way fusion (set spec_fusion "
                                 "and spec_fusion3; it replaces the f_ref member)")
            if not (0.0 < self.spec_sea_a and 0.0 < self.spec_sea_b):
                raise ValueError("spec_sea_a / spec_sea_b must be positive (Wiener signal/noise)")
            if self.spec_sea_max_age < 1:
                raise ValueError("spec_sea_max_age must be >= 1 (steps the cached residual stays eligible)")
        if self.spec_nodraft:
            # R1 separation probe (§8.12d): only meaningful on the gated spec branch
            if self.predictor != "spec":
                raise ValueError("spec_nodraft only applies to spec")
            # the gate signal is the frozen-history curvature; it needs the 3-point history
            if self.spec_ref_order != 2:
                raise ValueError("spec_nodraft gates on the 3-point history curvature; "
                                 "set spec_ref_order=2")
            for fld in ("spec_hf_gate", "spec_autotau", "spec_gate_sub", "spec_feedback"):
                if getattr(self, fld) is not None:
                    raise ValueError(f"{fld} calibrates/modulates the draft-vs-forecast gate; "
                                     "spec_nodraft has no draft")
            if self.spec_ladder:
                raise ValueError("spec_ladder resolves the gate with a mid-resolution draft; "
                                 "spec_nodraft has no draft")
            if self.spec_draft_f2_tail:
                raise ValueError("spec_draft_f2_tail upgrades the draft; spec_nodraft has no draft")
            if self.spec_draft_order:
                raise ValueError("spec_draft_order extrapolates the draft; spec_nodraft has no draft")
            if self.spec_draft_sigma_offset:
                raise ValueError("spec_draft_sigma_offset perturbs the draft; spec_nodraft has no draft")
            if self.spec_step_weight:
                raise ValueError("spec_step_weight scales the draft-forecast gate; "
                                 "spec_nodraft gates on history curvature")
            if self.spec_fusion or self.spec_fusion_band or self.spec_fusion_mode != "none":
                raise ValueError("fusion weights are calibrated against the draft; "
                                 "spec_nodraft commits to the pure forecast")
            if self.spec_shadow_full:
                raise ValueError("spec_shadow_full records draft/forecast errors; "
                                 "spec_nodraft has no draft")
            if self.spec_replay_schedule is not None:
                raise ValueError("spec_replay_schedule only applies to spec_replay")
        if self.spec_gate_mean:
            # EC-style accumulated gate: fire when the MEAN divergence since the last full
            # exceeds tau (budget is spent on sustained error, not instantaneous spikes).
            if self.predictor != "spec":
                raise ValueError("spec_gate_mean only applies to spec")
            for fld, attr in (("spec_hf_gate", "spec_hf_gate"), ("spec_autotau", "spec_autotau"),
                              ("spec_gate_sub", "spec_gate_sub")):
                if getattr(self, attr) is not None:
                    raise ValueError(f"{fld} reshapes the gate signal; spec_gate_mean replaces it")
            if self.spec_ladder:
                raise ValueError("spec_ladder resolves the gate trigger; spec_gate_mean replaces it")
            if self.spec_step_weight:
                raise ValueError("spec_step_weight scales the gate threshold; "
                                 "spec_gate_mean replaces the trigger")
            if self.spec_nodraft:
                raise ValueError("spec_nodraft has its own curvature gate; "
                                 "spec_gate_mean applies to the draft-forecast gate")
        if self.spec_gate_predict is not None:
            # predictive firing composes with the raw/gm trigger only — every other gate
            # variant either replaces the signal or the trigger decision
            if self.predictor != "spec":
                raise ValueError("spec_gate_predict only applies to spec")
            if self.spec_gate_predict < 0:
                raise ValueError("spec_gate_predict must be >= 0")
            if self.spec_hf_gate is not None:
                raise ValueError("spec_hf_gate takes the band-split gate path; "
                                 "spec_gate_predict composes with the raw/gm trigger only")
            for attr in ("spec_gate_sub", "spec_autotau", "spec_gate_learned"):
                if getattr(self, attr) is not None:
                    raise ValueError(f"{attr} replaces the gate signal; "
                                     "spec_gate_predict composes with the raw/gm trigger only")
            if self.spec_ladder:
                raise ValueError("spec_ladder resolves the gate trigger; "
                                 "spec_gate_predict composes with the raw/gm trigger only")
            if self.spec_fixed_refresh is not None:
                raise ValueError("spec_fixed_refresh disables the gate; spec_gate_predict needs it")
            if self.spec_defer_verify:
                raise ValueError("spec_defer_verify also retimes gate fires; "
                                 "combining the two timing mechanisms muddies the experiment")
            if self.spec_nodraft:
                raise ValueError("spec_nodraft has its own curvature gate; "
                                 "spec_gate_predict applies to the draft-forecast gate")
        if self.spec_kf_commit:
            # v3.1xspec hybrid: the residual replaces the accepted-step commit, so every knob
            # that adds the SAME residual as a fusion member or removes the gate signal is a
            # conflict.
            if self.predictor != "spec":
                raise ValueError("spec_kf_commit only applies to spec")
            if self.spec_fusion_sea:
                raise ValueError("spec_kf_commit replaces the commit with the residual reuse; "
                                 "spec_fusion_sea adds the residual as a fusion member -- "
                                 "the two residual semantics must not mix")
            if self.spec_nodraft:
                raise ValueError("spec_kf_commit needs the draft-forecast gate signal")
            if self.spec_kf_max_age < 1:
                raise ValueError("spec_kf_max_age must be >= 1 (the official max_consecutive_cached)")
        if self.spec_kf_band and not self.spec_kf_commit:
            # standalone (the sar_commit block above is skipped when the hybrid is off)
            raise ValueError("spec_kf_band splits the fresh-kf commit; it requires spec_kf_commit")
        if self.spec_kf_mean is not None:
            if not self.spec_kf_commit:
                raise ValueError("spec_kf_mean ensembles the fresh-kf commit; it requires spec_kf_commit")
            if not (0.0 < self.spec_kf_mean < 1.0):
                raise ValueError("spec_kf_mean must be in (0,1) (the ensemble weight on the kf member)")
            if self.spec_kf_band:
                raise ValueError("spec_kf_mean and spec_kf_band are two commit compositions -- pick one")
        if self.sarcache_warmup < 1:
            raise ValueError("sarcache_warmup must be >= 1 (1 = official retention_steps=1, no anchor)")
        if self.sarcache_output_cache and not self.sarcache_raw_residual:
            raise ValueError("sarcache_output_cache is EC's raw-output semantics; the Wiener-filtered "
                             "commit path (sarcache_raw_residual=False) must not mix with it")
        if self.sarcache_krate and self.sarcache_img_indicator:
            raise ValueError("sarcache_krate gates on the RAW stack-input change (official raw_input); "
                             "the SEA image indicator is a different domain -- pick one gate")
        if (self.spec_drift_weight != 1.0 or self.spec_drift_cal) and not self.spec_drift:
            raise ValueError("spec_drift_weight / spec_drift_cal require spec_drift=true")
        if self.spec_drift:
            # Drift-corrected reuse (state.md §8.37): an additive commit modifier — the
            # accepted-step commit (plain draft or fusion output) gets + (beta-1)*(G_t-G_ref).
            # Combinable with spec_fusion / spec_fusion_band / spec_fusion_mode.
            if self.predictor != "spec":
                raise ValueError("spec_drift only applies to spec")
            if self.spec_nodraft:
                raise ValueError("spec_nodraft has no coarse forward; "
                                 "spec_drift needs G_t - G_ref")
            if self.spec_draft_order:
                raise ValueError("spec_draft_order extrapolates D inside the draft; "
                                 "the drift commit uses the raw coarse drift")
            if self.spec_draft_f2_tail:
                raise ValueError("spec_draft_f2_tail drafts at f=2 with its own cache; "
                                 "combine with drift is undefined")
            if self.spec_ladder:
                raise ValueError("spec_ladder has its own mid-rung commit; "
                                 "combine with drift is undefined")
            if self.spec_feedback is not None:
                raise ValueError("spec_feedback corrects the draft; the drift commit does not use it")
            # spec_draft_sigma_offset is composable: it only shifts the sigma at which the
            # non-refresh coarse g is evaluated. The drift correction acc(g) - g_acc_ref stores,
            # at both endpoints, acc of the coarse that step actually computed (verify steps:
            # offset sigma; refresh steps: true sigma), so the combination is a direct
            # superposition with no convention conflict.
        if self.spec_distill:
            # Distilled draft net: the student replaces the CoarseView coarse forward, so any
            # knob that replaces/removes the same forward or belongs to another predictor's
            # draft machinery is rejected. The gate, drift, fusion, ref-order, tail, cg15 and
            # cap options around the draft are untouched and stay composable.
            if self.predictor != "spec":
                raise ValueError("spec_distill only applies to spec")
            if self.spec_tok_ratio is not None:
                raise ValueError("spec_tok_ratio only applies to spec_tok; "
                                 "spec_distill replaces the coarse forward")
            if self.spec_skip_tau is not None:
                raise ValueError("spec_skip_tau only applies to spec_skip; "
                                 "spec_distill replaces the coarse forward")
            if self.spec_ladder:
                raise ValueError("spec_ladder resolves the gate with a mid-resolution draft; "
                                 "spec_distill replaces the coarse forward")
            if self.spec_nodraft:
                raise ValueError("spec_nodraft has no coarse forward at all; "
                                 "spec_distill replaces it with the distilled student")
            if self.spec_replay_schedule is not None:
                raise ValueError("spec_replay_schedule only applies to spec_replay")
        if self.predictor == "spec_skip":
            # Drift-gated deep-block skipping: shallow pass every step, deep stack only on
            # step-0/warmup/tail/gate. No coarse view, no spec draft/forecast gate, no fusion,
            # no budget — the spec-family knobs are all rejected here.
            if self.spec_skip_tau is None:
                raise ValueError("spec_skip predictor needs `spec_skip_tau`")
            if self.spec_skip_tau < 0.0:
                raise ValueError("spec_skip_tau must be >= 0 (0 = the gate always fires: "
                                 "every step deep, the identity anchor)")
            if self.spec_skip_tail < 0:
                raise ValueError("spec_skip_tail must be >= 0")
            if self.spec_skip_warmup < 0:
                raise ValueError("spec_skip_warmup must be >= 0")
            if self.refresh is not None:
                raise ValueError("refresh does not apply to spec_skip (step 0 is always a deep "
                                 "forward, the rest is decided online by the gate)")
            if self.num_full is not None:
                raise ValueError("num_full does not apply to spec_skip (no step-skipping budget)")
            if self.spec_threshold is not None:
                raise ValueError("spec_threshold gates the spec draft-forecast divergence; "
                                 "spec_skip gates on the shallow-output drift (spec_skip_tau)")
            for fld in ("spec_hf_gate", "spec_tau_end", "spec_feedback", "spec_autotau", "spec_gate_sub",
                        "spec_replay_schedule", "teacache_thresh", "fb_thresh", "easy_thresh"):
                if getattr(self, fld) is not None:
                    raise ValueError(f"{fld} only applies to its own predictor, not spec_skip")
            for fld in ("spec_tail_full", "spec_tail_in_budget", "spec_step_weight", "spec_fusion",
                        "spec_ladder", "spec_shadow_full", "spec_nodraft", "spec_gate_mean",
                        "spec_drift", "spec_drift_cal", "spec_fusion_band"):
                if getattr(self, fld):
                    raise ValueError(f"{fld} only applies to spec-family predictors, not spec_skip")
            if self.spec_draft_order or self.spec_draft_sigma_offset or self.spec_draft_f2_tail \
                    or self.spec_ref_order != 1 or self.spec_drift_weight != 1.0:
                raise ValueError("draft/gate/drift tuning knobs only apply to spec-family "
                                 "predictors, not spec_skip")
            if self.spec_fusion_mode != "none":
                raise ValueError("spec_fusion_mode only applies to spec / spec_replay")
            if self.taylor_order != 2:
                raise ValueError("taylor_order only applies to taylor_f")
            if (self.spec_tok_ratio is not None or self.spec_tok_ratio_end is not None
                    or self.spec_tok_eps != 0.05 or self.spec_tok_select != "delta"):
                raise ValueError("spec_tok_* fields only apply to spec_tok")
            if (self.freqca_thresh is not None or self.freqca_interval is not None
                    or self.freqca_low_ratio != 0.25 or self.freqca_transform != "fft"
                    or self.freqca_hermite_k != 3):
                raise ValueError("freqca_* fields only apply to freqca")
        if self.predictor == "spec_tok":
            # Token-level partial refresh: no step skipping, no coarse forward, no gate, no budget.
            if self.spec_tok_ratio is None:
                raise ValueError("spec_tok predictor needs `spec_tok_ratio`")
            if not (0.0 < self.spec_tok_ratio <= 1.0):
                raise ValueError("spec_tok_ratio must be in (0, 1]")
            if self.spec_tok_ratio_end is not None and not (0.0 < self.spec_tok_ratio_end <= 1.0):
                raise ValueError("spec_tok_ratio_end must be in (0, 1]")
            if not (0.0 <= self.spec_tok_eps < 1.0):
                raise ValueError("spec_tok_eps must be in [0, 1)")
            if self.spec_tok_select != "delta":
                raise ValueError("spec_tok_select must be 'delta' ('drift' is reserved, not implemented)")
            if self.refresh is not None:
                raise ValueError("refresh does not apply to spec_tok (step 0 is always a full forward)")
            if self.num_full is not None:
                raise ValueError("num_full does not apply to spec_tok (no step-skipping budget)")
            # every knob that modulates the draft/gate/fusion/step-skipping machinery is meaningless here
            if self.spec_threshold is not None:
                raise ValueError("spec_threshold gates step-skipping verification; spec_tok never skips")
            for fld in ("spec_hf_gate", "spec_tau_end", "spec_feedback", "spec_autotau", "spec_gate_sub",
                        "spec_replay_schedule", "teacache_thresh", "fb_thresh", "easy_thresh",
                        "spec_skip_tau", "spec_skip_tau_end"):
                if getattr(self, fld) is not None:
                    raise ValueError(f"{fld} only applies to its own predictor, not spec_tok")
            for fld in ("spec_tail_full", "spec_tail_in_budget", "spec_step_weight", "spec_fusion",
                        "spec_ladder", "spec_shadow_full", "spec_nodraft", "spec_gate_mean",
                        "spec_drift", "spec_drift_cal", "spec_fusion_band"):
                if getattr(self, fld):
                    raise ValueError(f"{fld} only applies to spec-family predictors, not spec_tok")
            if self.spec_skip_tail != 2 or self.spec_skip_warmup != 1:
                raise ValueError("spec_skip_tail / spec_skip_warmup only apply to spec_skip, not spec_tok")
            if self.spec_draft_order or self.spec_draft_sigma_offset or self.spec_draft_f2_tail \
                    or self.spec_ref_order != 1 or self.spec_drift_weight != 1.0:
                raise ValueError("draft/gate/drift tuning knobs only apply to spec-family predictors, "
                                 "not spec_tok")
            if self.spec_fusion_mode != "none":
                raise ValueError("spec_fusion_mode only applies to spec / spec_replay")
            if self.taylor_order != 2:
                raise ValueError("taylor_order only applies to taylor_f")
        else:
            if (self.spec_tok_ratio is not None or self.spec_tok_ratio_end is not None
                    or self.spec_tok_eps != 0.05 or self.spec_tok_select != "delta"):
                raise ValueError("spec_tok_ratio / spec_tok_ratio_end / spec_tok_eps / spec_tok_select "
                                 "only apply to spec_tok")
            if (self.spec_skip_tau is not None or self.spec_skip_tau_end is not None
                    or self.spec_skip_tail != 2 or self.spec_skip_warmup != 1) \
                    and self.predictor != "spec_skip":
                raise ValueError("spec_skip_tau / spec_skip_tau_end / spec_skip_tail / spec_skip_warmup "
                                 "only apply to spec_skip")


    def refresh_steps(self, num_steps: int) -> list[int]:
        if self.predictor == "exact":
            return list(range(num_steps))
        if self.predictor == "spec_tok":
            # step 0 is the only mandatory full forward (it seeds the adapter-side K/V cache and
            # the velocity history through partial_forward's all-true path); every later step is
            # a partial token refresh
            return [0]
        if self.predictor in ("teacache", "easycache", "fbcache", "freqca", "sarcache", "seacache"):
            # fully online: step 0 and the last step are forced inside the branch, no fixed refresh
            # list. (sarcache's sarcache_fixed_refresh is also replayed inside the branch -- its
            # full steps must update the fresh-residual state, which the refresh_set path below
            # does not do -- so it does NOT migrate into this list either.)
            return []
        if self.predictor == "spec_skip":
            # fully online: step 0 / warmup / tail / gate decide the deep steps inside the branch,
            # no fixed refresh list
            if self.spec_skip_tail >= num_steps:
                raise ValueError(f"spec_skip_tail ({self.spec_skip_tail}) must be < num_steps "
                                 f"({num_steps})")
            return []
        if self.predictor == "spec":
            if self.spec_fixed_refresh is not None:
                # fixed schedule: the list IS the refresh set (validated, deduped, step 0 required)
                return validate_refresh(self.spec_fixed_refresh, num_steps)
            # mandatory initial full steps; the rest is decided online by the verify gate
            init = list(self.refresh) if self.refresh is not None else [0, 1]
            if self.num_full is None:
                raise ValueError("spec needs `num_full` as the total full-forward budget")
            if self.spec_tail_full:
                # tail refinement: the last k steps are always full (detail formation phase)
                init += list(range(num_steps - self.spec_tail_full, num_steps))
            return validate_refresh(init, num_steps)
        if self.predictor == "spec_replay":
            # fixed replayed schedule; the gate is disabled, so no budget is needed. A
            # `spec_replay_schedule` file must first be resolved into `refresh` per (prompt, seed)
            # by scripts/run_methods.py -- the sampler only ever sees the resolved list.
            if self.refresh is not None:
                return validate_refresh(self.refresh, num_steps)
            if self.num_full is not None:
                return uniform_refresh(num_steps, self.num_full)
            raise ValueError("spec_replay needs `refresh` (resolved from `spec_replay_schedule` "
                             "by the runner) or `num_full` (uniform fixed schedule)")
        if self.refresh is not None:
            return validate_refresh(self.refresh, num_steps)
        if self.num_full is not None:
            return uniform_refresh(num_steps, self.num_full)
        raise ValueError(f"method {self.name!r} needs `refresh` or `num_full`")

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Method":
        normalized = {}
        for key, value in d.items():
            new_key = f"sarcache_{key[7:]}" if key.startswith("kreafb_") else key
            if new_key in normalized:
                raise ValueError(f"duplicate Method field after legacy normalization: {new_key}")
            normalized[new_key] = value
        unknown = sorted(set(normalized) - set(cls.__dataclass_fields__))
        if unknown:
            raise ValueError(f"unknown Method field(s) {unknown}; allowed fields: "
                             f"{sorted(cls.__dataclass_fields__)}")
        return cls(**normalized)


@dataclass
class SampleResult:
    latents: torch.Tensor
    refresh: list[int]
    counts: dict = field(default_factory=dict)
    timing: dict = field(default_factory=dict)
    steps: list = field(default_factory=list)
    shadow: list = field(default_factory=list)


def _begin(model):
    begin = getattr(model, "begin", None)
    if callable(begin):
        begin()


@contextmanager
def _shadow_isolated(model):
    """Run a shadow forward without leaking adapter state into the sampled trajectory.

    Adapters with a mutable prefix-KV cache expose ``_caches`` / ``_filled`` (see
    ``adapters/qwenimage21.py``): the shadow call runs with fresh cache containers and the
    originals are restored afterwards, so the real trajectory's cache-mode transitions
    (extract vs cached) are untouched. Stateless models (oracle/toy adapters) need nothing.
    """
    caches = getattr(model, "_caches", None)
    filled = getattr(model, "_filled", None)
    if caches is None or filled is None:
        yield
        return
    saved_caches, saved_filled = model._caches, model._filled
    model._caches = {k: (type(c)(len(c.layer_caches)) if c is not None else None)
                     for k, c in saved_caches.items()}
    model._filled = {k: False for k in saved_filled}
    try:
        yield
    finally:
        model._caches, model._filled = saved_caches, saved_filled


def acc(t: torch.Tensor) -> torch.Tensor:
    """Accumulation dtype: half precisions go to fp32, fp32/fp64 are kept (never downcast)."""
    return t if t.dtype in (torch.float32, torch.float64) else t.float()


# Learned verify gate (spec_gate_learned, §8.81): the feature vector is defined ONCE here
# and imported by scripts/train_gate.py — training and inference must see identical features.
# NOTE (10-08): div_lo/div_hi were dropped — the shadow dump only carries them when
# spec_hf_gate was on in the data-collection run, so a gate trained on standard runs sees
# them as the CONSTANT 0; at runtime they are nonzero, the near-zero training std explodes
# them through normalization, and the MLP outputs garbage (found by a debug probe).
GATE_FEATURES = (
    "sigma", "g", "history_age", "dsigma",
    "w_lo", "w_hi", "drift_beta", "budget_remaining_frac",
    "g_times_age",          # interaction: divergence x steps-since-verify (drift compounds)
    "sigma_times_g",        # interaction: high-noise divergence costs more trajectory
)

# raw (un-engineered) inference quantities the sampler has at the gate decision; the
# checkpoint stores feature NAMES and the vector is built by name — a trained gate only
# ever sees features that existed in its training data.
GATE_RAW_QUANTITIES = (
    "sigma", "g", "div_lo", "div_hi", "history_age", "dsigma",
    "w_lo", "w_hi", "drift_beta", "budget_remaining_frac",
)


def gate_feature_dict(sigma: float, g: float, div_lo: float, div_hi: float,
                      history_age: int, dsigma: float, w_lo: float, w_hi: float,
                      drift_beta: float, budget_remaining_frac: float) -> dict:
    """All inference-available gate quantities + engineered terms, BY NAME. The sampler
    selects the checkpoint's features from this dict; train_gate imports the same dict."""
    return {
        "sigma": sigma, "g": g, "div_lo": div_lo, "div_hi": div_hi,
        "history_age": history_age, "dsigma": dsigma,
        "w_lo": w_lo, "w_hi": w_hi, "drift_beta": drift_beta,
        "budget_remaining_frac": budget_remaining_frac,
        "g_times_age": g * history_age,
        "sigma_times_g": sigma * g,
    }


def gate_feature_vector(names, fd: dict) -> torch.Tensor:
    """Feature vector in the checkpoint's name order; any missing name is a hard error."""
    missing = [n for n in names if n not in fd]
    if missing:
        raise ValueError(f"gate checkpoint asks for features not in the dict: {missing}")
    return torch.tensor([fd[n] for n in names], dtype=torch.float32)


# Qwen-Image TeaCache rescaling polynomial (community-calibrated, via vLLM-Omni / ComfyUI-TeaCache):
# maps the block-0 modulated-input rel-L1 distance to an output-distance proxy; x^4 first.
_TEACACHE_POLY_QWEN = (-4.5e2, 2.8e2, -4.5e1, 3.2e0, -2.0e-2)


def _teacache_poly(rel_l1: float) -> float:
    a, b, c, d, e = _TEACACHE_POLY_QWEN
    return ((((a * rel_l1) + b) * rel_l1 + c) * rel_l1 + d) * rel_l1 + e


# ---------------------------------------------------------------------- FreqCa (arXiv:2510.08669)
# Probabilists' Hermite polynomials He_0..He_2 for the high-band predictor (Sec. 3.2, m = 2):
# He_0(s) = 1, He_1(s) = s, He_2(s) = s^2 - 1, evaluated on normalized time s in [-1, 1].
def _he_basis(s: float, order: int) -> list[float]:
    basis = [1.0]
    if order >= 1:
        basis.append(s)
    if order >= 2:
        basis.append(s * s - 1.0)
    return basis[: order + 1]


_DCT_MAT: dict = {}


def _dct_matrix(n: int, device, dtype) -> torch.Tensor:
    """Orthonormal DCT-II matrix C (C C^T = I): forward X -> C X C^T, inverse X -> C^T X C."""
    key = (n, str(device), dtype)
    mat = _DCT_MAT.get(key)
    if mat is None:
        x = torch.arange(n, dtype=torch.float64)
        k = torch.arange(n, dtype=torch.float64)
        mat = torch.cos(math.pi / n * (x[:, None] + 0.5) * k[None, :]) * math.sqrt(2.0 / n)
        mat[:, 0] *= math.sqrt(0.5)
        mat = mat.T.contiguous().to(device=device, dtype=dtype)  # [freq k, space x]
        _DCT_MAT[key] = mat
    return mat


def _freqca_split(x: torch.Tensor, low_ratio: float, transform: str):
    """Split ``x`` over the last two (spatial) dims into complementary low/high bands.

    Returns ``(low, high)`` with ``high = x - low`` by construction, so the round trip is exact.
    FFT: keep the centered rectangle |f| <= 0.5*low_ratio of the ortho-normalized 2-D spectrum
    (Qwen-Image configuration in the paper, App. B.3). DCT: keep the first
    ``round(n * low_ratio)`` DCT-II coefficients per dim (FLUX configuration, App. B.3).
    """
    h, w = x.shape[-2:]
    if transform == "fft":
        fh = torch.fft.fftfreq(h, device=x.device).abs()
        fw = torch.fft.fftfreq(w, device=x.device).abs()
        keep = (fh[:, None] <= 0.5 * low_ratio) & (fw[None, :] <= 0.5 * low_ratio)
        spec = torch.fft.fft2(x, dim=(-2, -1), norm="ortho")
        low = torch.fft.ifft2(spec * keep, dim=(-2, -1), norm="ortho").real.to(x.dtype)
    else:
        ch = _dct_matrix(h, x.device, x.dtype)
        cw = _dct_matrix(w, x.device, x.dtype)
        spec = torch.einsum("kh,...hw,lw->...kl", ch, x, cw)
        keep = (torch.arange(h, device=x.device)[:, None] < max(1, round(h * low_ratio))) & \
               (torch.arange(w, device=x.device)[None, :] < max(1, round(w * low_ratio)))
        low = torch.einsum("kh,...kl,lw->...hw", ch, spec * keep, cw)
    return low, x - low


def _freqca_hermite_predict(hist: list, s_t: float, order: int = 2) -> torch.Tensor:
    """Second-order Hermite-series extrapolation of the high band (Sec. 3.2 Eq. for h_i(s_t)):
    per-coefficient least-squares fit of ``sum_k c_k He_k(s)`` over the K most recent computed
    steps, evaluated at ``s_t``. The effective order degrades to ``len(hist) - 1`` when fewer
    than ``order + 1`` points exist (one point = plain reuse of the high band)."""
    if len(hist) == 1:
        return hist[0][1]
    m = min(order, len(hist) - 1)
    # The design matrices are built from Python floats, so they default to CPU while the stacked bands
    # live on the model's device -- build them on the history's device, or lstsq raises a device mismatch
    # (invisible on the CPU toy tests, immediate at 2048px on CUDA).
    dev = hist[0][1].device
    a = torch.tensor([_he_basis(s, m) for s, _ in hist], dtype=torch.float64, device=dev)  # [K, m+1]
    y = torch.stack([h.reshape(-1).to(torch.float64) for _, h in hist])                    # [K, E]
    # Closed-form least squares. ``a`` is at most 3x3 (K <= 3 history points, m+1 <= 3 basis terms), so
    # the pseudo-inverse of the SMALL factor is the whole solve: coef = pinv(a) @ y. Calling
    # torch.linalg.lstsq here instead was a ~400x cost bug on CUDA -- it runs an SVD/QR over the full
    # [K, E] right-hand side (E = 262144 at 2048px) on EVERY reuse step, which measured 0.6-4.0 s per
    # step versus 0.9 s for a whole full forward. That made FreqCa run 2-3x SLOWER than the exact
    # sampler instead of N x faster, i.e. an unusable baseline rather than a weak one.
    coef = torch.linalg.pinv(a) @ y                                                        # [m+1, E]
    b = torch.tensor(_he_basis(s_t, m), dtype=torch.float64, device=dev)                   # [m+1]
    return (b @ coef).reshape(hist[0][1].shape).to(hist[0][1].dtype)


def euler_update(x: torch.Tensor, v: torch.Tensor, sigma: torch.Tensor, sigma_next: torch.Tensor) -> torch.Tensor:
    """Same arithmetic as ``FlowMatchEulerDiscreteScheduler.step``: the 0-dim fp32 ``dt`` lives on ``v``'s device
    (a CPU scalar would skip the cast to ``v``'s dtype on CUDA), ``dt * v`` stays in ``v``'s dtype, the sum is fp32
    (or fp64), and the result is cast back to the latent dtype."""
    dt = (sigma_next - sigma).to(v.device)
    return (acc(x) + dt * v).to(x.dtype)


def _spec_tok_step_seed(seed: int, step: int) -> int:
    """Deterministic per-step seed from (prompt seed, step index) -- boost::hash_combine style, so a
    rerun of the same (prompt, seed, method) replays the identical selection stream."""
    return (int(seed) + 0x9E3779B9 + ((step + 1) << 6) + ((step + 1) >> 2)) & 0x7FFFFFFF


def _verify_tok_mask(draft, pred_f, patch: int, gh: int, gw: int, ratio: float) -> torch.Tensor:
    """Patch selection for spec_verify_tok_ratio: bool ``[gh, gw]`` on the model's patch grid,
    True = recompute this patch exactly at this partial verify.

    The top ``ratio`` patches by the per-patch mean-squared draft--forecast disagreement
    (the same signal the scalar gate thresholds, block-averaged onto the patch grid) --
    the patches where the cheap predictors disagree most are where the exact refresh buys
    the most. Deterministic: plain topk on the score field, no random fraction (a verify
    is a rare event; starvation of a genuinely-drifting patch shows up as disagreement
    next step and gets selected then).
    """
    d = acc(draft) - acc(pred_f)
    s = (d.double() ** 2).mean(dim=(0, 1))                 # [H, W]
    if patch > 1:
        s = s.reshape(gh, patch, gw, patch).mean(dim=(1, 3))   # [gh, gw]
    n = gh * gw
    k = max(1, int(round(ratio * n)))
    topk = torch.topk(s.reshape(-1), k=k, largest=True, sorted=False).indices
    mask = torch.zeros(n, dtype=torch.bool, device=d.device)
    mask[topk] = True
    return mask.reshape(gh, gw)


def _spec_tok_mask(method, v_prev, v_prevprev, patch: int, gh: int, gw: int,
                   step: int, num_steps: int, seed: int | None, device) -> torch.Tensor:
    """Patch selection for spec_tok: bool ``[gh, gw]`` on the model's patch grid, True = recompute this
    patch at full resolution this step.

    Top ``rho * (1 - eps)`` patches by the per-patch L2 of the committed-velocity increment
    ``||v_prev - v_prevprev||`` (squared, channel-meaned, block-averaged onto the patch grid --
    ranking-equivalent to the L2), plus ``rho * eps`` uniformly random patches against systematic
    starvation (generator seeded from (seed, step)). With no increment history yet (step 1) the
    delta scores are undefined and the selection degrades to uniform at the full ratio. ``rho``
    ramps linearly from ``spec_tok_ratio`` (early, sigma=1 end) to ``spec_tok_ratio_end`` (late,
    sigma->0 end) when the latter is given.
    """
    n = gh * gw
    rho = float(method.spec_tok_ratio)
    if method.spec_tok_ratio_end is not None and num_steps > 1:
        rho += (method.spec_tok_ratio_end - rho) * (step / (num_steps - 1))
    sel = torch.zeros(n, dtype=torch.bool, device=device)
    gen = torch.Generator(device="cpu").manual_seed(_spec_tok_step_seed(0 if seed is None else seed, step))
    perm = torch.randperm(n, generator=gen).to(device)
    if v_prevprev is None:
        sel[perm[: int(round(rho * n))]] = True
        return sel.reshape(gh, gw)
    d = acc(v_prev) - acc(v_prevprev)                       # [B, C, H, W] fp32
    b, c, h, w = d.shape
    d = (d * d).mean(dim=(0, 1))                            # [H, W]
    if patch > 1:
        d = d.reshape(gh, patch, gw, patch).mean(dim=(1, 3))  # [gh, gw]
    flat = d.reshape(-1)
    k_top = int(round(rho * (1.0 - method.spec_tok_eps) * n))
    if k_top > 0:
        sel[flat.topk(min(k_top, n)).indices] = True
    k_rand = int(round(rho * method.spec_tok_eps * n))
    if k_rand > 0:
        sel[perm[:k_rand]] = True
    return sel.reshape(gh, gw)





def sample(
    model: VelocityModel,
    x_init: torch.Tensor,
    sigmas: Sequence[float] | torch.Tensor,
    method: Method,
    timer: Timer | None = None,
    record: bool = False,
    seed: int | None = None,
) -> SampleResult:
    """``seed`` is the per-(prompt, seed) selection seed: spec_tok derives every step's uniform-random
    patch pick from (seed, step index), so reruns of the same job replay the identical selection
    stream. None falls back to 0 (deterministic, but not seed-diverse). Other predictors ignore it."""
    if method.coarse_positions is None or not hasattr(model, "coarse_positions"):
        return _sample(model, x_init, sigmas, method, timer, record, seed)
    previous = model.coarse_positions
    model.coarse_positions = method.coarse_positions
    try:
        return _sample(model, x_init, sigmas, method, timer, record, seed)
    finally:
        model.coarse_positions = previous


@torch.no_grad()
def _sample(model, x_init, sigmas, method, timer, record, seed=None) -> SampleResult:
    sig = torch.as_tensor(sigmas, dtype=torch.float32).cpu()
    num_steps = len(sig) - 1
    refresh = method.refresh_steps(num_steps)
    refresh_set = set(refresh)
    # sarcache fixed refresh replay (SARCache §3): resolve the position list into the effective
    # schedule here. Step 0 always computes (the branch forces it while no fresh residual
    # exists); the last step is auto-appended when the list misses it (the plan's末步必须
    # full rule) -- the auto-add is marked in counts and in that step's record.
    sar_fixed = None
    sar_fixed_auto_tail = False
    if method.predictor == "sarcache" and method.sarcache_fixed_refresh is not None:
        _pts = sorted({int(j) for j in method.sarcache_fixed_refresh})
        _bad = [j for j in _pts if j < 0 or j >= num_steps]
        if _bad:
            raise ValueError(f"sarcache_fixed_refresh positions {_bad} outside [0, {num_steps})")
        sar_fixed_auto_tail = (num_steps - 1) not in _pts
        sar_fixed = set(_pts) | {0, num_steps - 1}
    view = CoarseView(method.factor, method.coarse_mode)
    timer = timer or Timer(enabled=False)
    pred = method.predictor
    nodraft = method.spec_nodraft and pred == "spec"  # R1 separation probe (§8.12d)
    if pred == "spec_tok" and not callable(getattr(model, "partial_forward", None)):
        raise ValueError("spec_tok predictor needs a model with a `partial_forward(x, sigma, mask)` method")
    if method.spec_verify_tok_ratio is not None \
            and not callable(getattr(model, "partial_forward", None)):
        raise NotImplementedError("spec_verify_tok_ratio needs a model with a `partial_forward(x, sigma, mask)` "
                                  "method (Krea 2 adapter only; Qwen-Image-2.1's block-causal layout has none)")
    if pred == "spec_skip":
        for attr in ("fb_first", "fb_full", "fb_reuse"):
            if getattr(model, attr, None) is None:
                raise NotImplementedError(
                    f"spec_skip predictor needs a model with a `{attr}` method "
                    "(Qwen-Image-2.1 adapter only; the fb hooks are not available on other adapters)")
    patch = max(1, int(getattr(model, "patch_size", 1) or 1))
    gh, gw = x_init.shape[-2] // patch, x_init.shape[-1] // patch
    # partial verify (spec_verify_tok_ratio): full forwards in the spec flow route through
    # partial_forward's all-true path — bitwise the regular full forward (same trick as
    # spec_tok's step 0) — so the partial K/V cache stays fresh across mixed full/partial steps.
    _pf = getattr(model, "partial_forward", None)
    _use_pf_full = method.spec_verify_tok_ratio is not None and callable(_pf)

    def fullx(x, s):
        if _use_pf_full:
            with timer("tok"):
                return _pf(x, s, torch.ones(gh, gw, dtype=torch.bool, device=x.device))
        return full(x, s)

    def full(x, s):
        with timer("full"):
            return model(x, s, "full", 1)

    # spec_fusion_sea: residual box refreshed by every full forward (verify/refresh), read
    # as the STALE member before this step's possible refresh — the same stale-member
    # discipline as f_ref in the three-way fusion calibration.
    sea_box = [None]
    if method.spec_fusion_sea:
        if not (callable(getattr(model, "embed_full", None))
                and callable(getattr(model, "embed_reuse", None))):
            raise NotImplementedError("spec_fusion_sea needs a model with embed_full/embed_reuse "
                                      "(Krea 2 adapter, guidance_scale 0)")
    if method.spec_kf_commit and not (callable(getattr(model, "embed_full", None))
                                      and callable(getattr(model, "embed_reuse", None))):
        raise NotImplementedError("spec_kf_commit needs a model with embed_full/embed_reuse "
                                  "(embed-capable adapter)")
    # spec_kf_commit: whole-stack residual history [(step, residual)] capped at 2 (order-1
    # step-index extrapolation, the v3.1 semantics), refreshed by every fullx capture.
    sar_hist: list[tuple[int, torch.Tensor]] = []

    def fullx(x, s):
        """Sea-aware / kf-aware full forward: same cost, additionally captures the hidden residual."""
        if method.spec_fusion_sea or method.spec_kf_commit:
            with timer("full"):
                v, _emb, resid = model.embed_full(x, s)
            if method.spec_fusion_sea:
                sea_box[0] = resid
            if method.spec_kf_commit:
                sar_hist.append((i, resid))
                del sar_hist[:-2]
            return v
        return full(x, s)

    if method.spec_distill:
        # Distilled draft: the student outputs a full-grid velocity, consumed exactly like the
        # CoarseView-lifted coarse output (draft = acc(g) + d_cache), so only the closure changes.
        draft_net = getattr(model, "draft_net", None)
        if draft_net is None:
            raise ValueError("spec_distill requires model.draft_net — set DISTILL_DRAFT_PATH "
                             "when running")

        def coarse(x, s):
            with timer("coarse"):
                return draft_net(x, s)
    else:
        def coarse(x, s):
            with timer("coarse"):
                return view(lambda y, t: model(y, t, "coarse", method.factor), x, s)

    _begin(model)
    x = x_init
    d_cache = g_ref = f_ref = None
    f_hist: list[tuple[float, torch.Tensor]] = []
    d_hist: list[tuple[float, torch.Tensor]] = []
    counts = {"full": 0, "coarse": 0}
    steps = []
    shadow = []
    shadow_on = method.spec_shadow_full and pred in ("spec", "spec_replay")
    fmode = method.spec_fusion_mode  # resolved in __post_init__ (legacy flags are aliases)
    mean_abs_dsig = float((sig[1:] - sig[:-1]).abs().mean())
    fusion_ed = fusion_ef = 0.0   # fusion statistics: running MSE of draft / forecast vs full truth
    fusion_er = 0.0               # spec_fusion3: running MSE of f_ref (last exact velocity) vs full truth
    fusion_n = 0
    # per-band fusion statistics: (ed_lo, ed_hi, ef_lo, ef_hi, er_lo, er_hi); the er_* pair is the
    # f_ref member's and only accumulates with spec_fusion3
    fband = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    fb_c = None                   # spec_feedback: EMA of the draft error (closed-loop correction)
    cal_log = None                # spec_autotau: log-space EMA of true-error / gate-divergence ratio
    sub_res: list[torch.Tensor] = []   # spec_gate_sub: subsampled residuals from verify steps
    sub_idx = None                # spec_gate_sub: strided subsample indices (lazy)
    d2_cache = None               # spec_ladder: difference cache for the mid-resolution (f=2) rung
    last_full_i = 0               # step index of the most recent full forward (shadow: history_age)
    g_sum = 0.0                   # spec_gate_mean: divergence accumulated since the last full
    sig_prev = None               # spec_gate_predict: (gate signal, last_full_i) of the previous
                                  # gated step — the tag invalidates the seed after any verify
    sched_verify = False          # spec_defer_verify: a full forward is scheduled for this step
                                  # (a gate fire was deferred from the previous step); the free
                                  # gate re-check at this step executes it on persistent drift
                                  # or cancels it (transient fire -> budget banked)
    drift_on = method.spec_drift and pred == "spec"
    gate_w = None
    if method.spec_gate_wprofile is not None:
        import json as _json
        _prof = _json.load(open(method.spec_gate_wprofile))["sensitivity"]
        _w = np.ones(num_steps, dtype=np.float64)
        for _k, _v in _prof.items():
            if int(_k) < num_steps:
                _w[int(_k)] = float(_v)
        gate_w = (_w / _w.mean()).tolist()  # mean-1: keeps tau units comparable to unweighted
    g_acc_ref = None              # drift: acc(G) at the last full/verify step (the drift origin)
    drift_num = drift_den = 0.0   # spec_drift_cal: online least-squares accumulators for beta
    # spec_gate_learned: lazy-loaded gate model + feature normalization and threshold
    # (scripts/train_gate.py checkpoint); the w_lo/w_hi/drift_beta features are the PREVIOUS
    # step's commit values (the gate decides before this step's commit is computed).
    gate_model = gate_mu = gate_sd = gate_thr = None
    glw = ghw = 0.5               # previous commit's fusion draft weights (None-fill of train_gate)
    gdb = 1.0                     # previous commit's drift beta
    if method.spec_gate_learned is not None:
        import torch.nn as _nn
        _ck = torch.load(method.spec_gate_learned, map_location="cpu", weights_only=False)
        _ck_features = list(_ck["features"])
        _nfeat = len(_ck_features)
        _unknown = [f for f in _ck_features
                    if f not in GATE_RAW_QUANTITIES
                    and f not in ("g_times_age", "sigma_times_g")]
        if _unknown:
            raise ValueError(f"gate checkpoint asks for unknown features {_unknown}; "
                             f"available: {GATE_RAW_QUANTITIES} + engineered")

        def _build_gate():
            _m = _nn.Sequential(_nn.Linear(_nfeat, 32), _nn.ReLU(),
                                _nn.Linear(32, 32), _nn.ReLU(), _nn.Linear(32, 1))
            _m.eval()
            return _m

        if "states" in _ck:       # seed-ensemble checkpoint (member-mean prediction)
            _members = []
            for _sd in _ck["states"]:
                _m = _build_gate()
                _m.load_state_dict(_sd)
                _members.append(_m)

            def gate_model(_x):   # noqa: F811 — mean over members
                with torch.no_grad():
                    return torch.stack([_m(_x).squeeze(-1) for _m in _members]).mean(0)
        else:                     # legacy single-model checkpoint
            _m = _build_gate()
            _m.load_state_dict(_ck["state"])

            def gate_model(_x):   # noqa: F811
                with torch.no_grad():
                    return _m(_x).squeeze(-1)
        gate_mu, gate_sd = _ck["mu"], _ck["sd"]
        gate_thr = float(_ck["thr"])
        del _ck
    gate_rate_buf = [gate_thr] * 3 if method.spec_gate_learned_rate is not None else None

    def _spec_draft(gv, sf):
        """Cross-resolution draft ``G + D_r`` (+ optional first-order D extrapolation and feedback)."""
        d = acc(gv) + d_cache
        if method.spec_draft_order and len(d_hist) >= 2:
            # first-order extrapolation of the cached difference itself
            (sd1, d1), (sd2, d2) = d_hist
            d = acc(gv) + d2 + (d2 - d1) * ((sf - sd2) / (sd2 - sd1))
        if method.spec_feedback is not None and fb_c is not None:
            # closed-loop error feedback: EMA of the draft error measured at verify steps
            d = d + fb_c
        return d

    def _spec_forecast(sf):
        """Free reference: forecast of F from the last verified/refreshed steps.

        With ``spec_ref_hi_damp`` in [0, 1] the forecast's zero-mean (texture) band is
        damped toward the last verified value: hi_pred = last_hi + damp * (extrap_hi −
        last_hi). The texture band of F evolves fast, so time-polynomial extrapolation
        overshoots there and pollutes BOTH the gate divergence (draft--forecast
        disagreement no longer isolates the draft error) and the fusion weighting.
        damp = 1 recovers the undamped forecast bitwise; damp = 0 freezes the hi band at
        the last verify. The block-constant (layout) band is never damped.
        """
        if len(f_hist) < 2:
            return f_hist[-1][1]
        if method.spec_ref_order == 2 and len(f_hist) >= 3:
            (sr0, fr0), (sr1, fr1), (sr2, fr2) = f_hist[-3:]
            c1 = (fr2 - fr1) / (sr2 - sr1)
            c2 = (c1 - (fr1 - fr0) / (sr1 - sr0)) / (sr2 - sr0)
            pred = fr2 + c1 * (sf - sr2) + c2 * (sf - sr2) * (sf - sr1)
        else:
            (s1, f1), (s2, f2) = f_hist
            pred = f2 + (f2 - f1) * ((sf - s2) / (s2 - s1))
        if method.spec_ref_hi_damp is None or method.spec_ref_hi_damp == 1.0:
            return pred
        damp = method.spec_ref_hi_damp
        pred_lo, pred_hi = low_high_split(pred.double(), method.factor)
        last_hi = low_high_split(acc(f_hist[-1][1]).double(), method.factor)[1]
        out = pred_lo + (last_hi + damp * (pred_hi - last_hi))
        return out.to(pred.dtype)

    def _fusion_update(draft, pred_f, fa, fr_override=None, er_on=True):
        """Online inverse-error fusion statistics: the cheap predictors vs the full truth.

        Members: draft (cross-resolution, current state), forecast (F-history extrapolation),
        and — with spec_fusion3 — f_ref, the last exact velocity (stale but exact content).
        f_ref is read from the enclosing scope BEFORE the verify step updates it, so its error
        is measured against the same stale member a reuse step would have committed. With
        spec_fusion_sea the third member is the Wiener-filtered residual reuse instead —
        pass it as fr_override (built from the STALE residual before this step's refresh).
        er_on=False skips the third-member accumulation for staleness-gated steps (the
        member is not committed when aged out — §8.83 四续 — so its error must not enter
        the shared weights)."""
        nonlocal fusion_ed, fusion_ef, fusion_er, fusion_n
        if fmode not in ("select", "scalar", "band"):
            return
        fusion_ed += float(((draft.double() - fa.double()) ** 2).mean())
        fusion_ef += float(((pred_f.double() - fa.double()) ** 2).mean())
        if method.spec_fusion3 and er_on:
            _fr = fr_override if fr_override is not None else acc(f_ref)
            fusion_er += float(((_fr.double() - fa.double()) ** 2).mean())
        fusion_n += 1
        if fmode == "band":
            # per-band statistics (block-constant vs zero-mean parts)
            ed_lo, ed_hi = low_high_split(draft.double() - fa.double(), method.factor)
            ef_lo, ef_hi = low_high_split(pred_f.double() - fa.double(), method.factor)
            fband[0] += float((ed_lo ** 2).mean()); fband[1] += float((ed_hi ** 2).mean())
            fband[2] += float((ef_lo ** 2).mean()); fband[3] += float((ef_hi ** 2).mean())
            if method.spec_fusion3 and er_on:
                er_lo, er_hi = low_high_split(_fr.double() - fa.double(), method.factor)
                fband[4] += float((er_lo ** 2).mean()); fband[5] += float((er_hi ** 2).mean())
    tea_probe_prev = None   # teacache: previous step's block-0 modulated input
    tea_acc = 0.0           # teacache: accumulated rescaled rel-L1 distance
    easy_v = None           # easycache: last computed velocity (output-level variant)
    easy_rate = 0.0         # easycache: last observed relative change of v between computed steps
    easy_acc = 0.0          # easycache: accumulated predicted deviation
    fb_h0_prev = None       # fbcache: previous step's block-0 target-token output
    sc_probe_prev = None    # seacache: previous step's SEA-filtered block-0 input feature
    sc_acc = 0.0            # seacache: accumulated filtered rel-L1 (the paper's delta)
    sc_v = None             # seacache: last computed velocity (the output-level cache)
    sar_resid = None         # sarcache: newest cached hidden residual (raw; Wiener-filtered at reuse)
    sar_resid_prev = None    # sarcache: previous residual + sigma (order-1 extrapolation)
    sar_resid_sig = None     # sarcache: sigma of the newest cached residual
    sar_resid_i = None       # sarcache: step index of the newest cached residual (v3 step-index scale)
    sar_resid_prev_i = None  # sarcache: step index of the previous residual (v3)
    sar_reuse_n = 0          # sarcache: consecutive reuses since the last compute (staleness cap)
    sar_v_cache = None       # sarcache_output_cache: the velocity captured at the last compute
    sar_k = None             # sarcache_krate: output/input rate between the last two computes
    sar_v_prev = None        # sarcache_krate: velocity at the previous compute (k numerator)
    sar_emb_prev = None      # sarcache_krate: stack input at the previous compute (k denominator)
    sar_v_mean = 0.0         # sarcache_krate: mean|v| of the freshest computed velocity
    sar_probe_prev = None    # sarcache: probe at the last compute step (the drift reference)
    sar_acc = 0.0            # sarcache: accumulated (filtered) probe rel-L1 (the SeaCache gate)
    # sar_fixed / sar_fixed_auto_tail (the fixed-refresh schedule) are resolved from the method
    # at the top of _sample -- they are method-level, not loop state.
    fb_residual = None      # fbcache: cached hidden-space residual (last block - block 0)
    skip_x_ref = None          # spec_skip: latent at the last deep step (latent-gate reference)
    skip_h0_ref = None         # spec_skip: block-0 output at the last deep step (bridge reference)
    skip_residual_ref = None   # spec_skip: hidden residual at the last deep step (drift-corrected on reuse)
    skip_num = skip_den = None  # spec_skip: per-channel online LSQ accumulators of the diagonal bridge beta
    prev_acc_g = None         # R11 spec_coarse_acc_gate: previous step's acc(g) (the drift reference)
    C = 0.0                   # R11 spec_coarse_acc_gate: accumulated relative coarse-output drift
    fc_low = None           # freqca: cached low band of the last computed output (reused band)
    fc_hist: list = []      # freqca: (s_norm, high band) of the last freqca_hermite_k computed steps
    fc_xlow = None          # freqca: low band of the previous latent (input-side similarity probe)
    fc_acc = 0.0            # freqca: accumulated relative change of the latent low band
    v_prev = v_prevprev = None   # spec_tok: committed velocity history (the patch-selection signal)
    for i in range(num_steps):
        s, s_next = sig[i], sig[i + 1]
        sf = float(s)
        f_step = None                 # full forward computed at this step, if any (shadow reuses it)
        step_draft = step_pred = None  # candidate predictions measurable at this step (spec family)
        gate = None                    # per-step gate info (spec non-refresh steps, for shadow records)
        drift_beta_used = None         # beta committed at this step (drift reuse only)
        w_lo = w_hi = None             # this step's fusion draft weights (learned-gate features)
        deferred_flag = False          # spec_defer_verify: this step's gate fire was deferred
        gate_diag = None               # learned gate: (prediction, effective threshold)
        auto_tail_full = False         # sarcache: this step's full is the auto-appended last-step full
        if i in refresh_set:
            sched_verify = False   # a mandatory refresh full supersedes a pending deferred verify
            if pred == "spec_tok":
                # step 0 mandatory full forward, executed through partial_forward's all-true path:
                # bitwise the regular full forward, and it seeds the per-layer K/V cache plus the
                # committed velocity through the same entry point the later partial steps use.
                # Counted in both buckets: one full-resolution forward, one partial_forward call.
                with timer("tok"):
                    f = model.partial_forward(x, sf, torch.ones(gh, gw, dtype=torch.bool, device=x.device))
                counts["tok"] = counts.get("tok", 0) + 1
            else:
                f = fullx(x, sf)
            counts["full"] += 1
            if pred in ("diff", "stale_g", "diff_linear", "spec", "spec_replay") and not nodraft:
                g = coarse(x, sf)
                counts["coarse"] += 1
                prev_acc_g = acc(g)   # R11: the drift reference resets at every full step
                with timer("ops"):
                    fa = acc(f)
                    if (pred == "spec_replay" or method.spec_fixed_refresh is not None) \
                            and d_cache is not None and f_hist:
                        # replay / fixed-schedule (§8.60): every fixed full forward also calibrates
                        # the fusion statistics (gated spec only calibrates at verify steps, and
                        # a fixed schedule never verifies) — without this the cached-step fusion
                        # stays degenerate and the run commits the raw draft (falsified 10-06:
                        # 2048 fixed-greedy v1 arms lost ~15dB to uncalibrated fusion)
                        step_draft, step_pred = _spec_draft(g, sf), _spec_forecast(sf)
                        _fusion_update(step_draft, step_pred, fa)
                    elif pred == "spec" and shadow_on and d_cache is not None and f_hist:
                        # record-only draft/forecast error at refresh steps (no state updates)
                        step_draft, step_pred = _spec_draft(g, sf), _spec_forecast(sf)
                    d_cache = fa - acc(g)
                g_ref = g
                g_acc_ref = acc(g)
                d_hist = (d_hist + [(sf, d_cache)])[-2:]
            f_ref = f
            f_step, last_full_i = f, i
            if pred in ("linear_f", "spec", "spec_replay"):
                cap = 2 if pred == "linear_f" else 1 + method.spec_ref_order
                f_hist = (f_hist + [(sf, acc(f))])[-cap:]
            elif pred == "taylor_f":
                f_hist = (f_hist + [(sf, acc(f))])[-(method.taylor_order + 1):]
            v, used = f, "F"
        else:
            if pred == "diff":
                g = coarse(x, sf)
                counts["coarse"] += 1
                with timer("ops"):
                    v = acc(g) + d_cache
                used = "G+D"
            elif pred == "diff_linear":
                g = coarse(x, sf)
                counts["coarse"] += 1
                with timer("ops"):
                    if len(d_hist) < 2:
                        v, used = acc(g) + d_cache, "G+D"
                    else:
                        (s1, d1), (s2, d2) = d_hist
                        v, used = acc(g) + d2 + (d2 - d1) * ((sf - s2) / (s2 - s1)), "G+lin(D)"
            elif pred == "coarse_only":
                v = coarse(x, sf)
                counts["coarse"] += 1
                used = "G"
            elif pred == "fcache":
                v, used = f_ref, "F_r"
            elif pred == "stale_g":
                with timer("ops"):
                    v = acc(g_ref) + d_cache
                used = "G_r+D"
            elif pred == "linear_f":
                if len(f_hist) < 2:
                    v, used = f_hist[-1][1], "F_r"
                else:
                    (s1, f1), (s2, f2) = f_hist
                    with timer("ops"):
                        v = acc(f2) + (acc(f2) - acc(f1)) * ((sf - s2) / (s2 - s1))
                    used = "lin(F)"
            elif pred == "spec" and nodraft:
                # R1 separation probe (§8.12d): no coarse forward, no draft, no D cache. The gate
                # signal degrades to the second difference of the frozen F history — the discrete
                # curvature of the velocity measured at refresh steps — accumulated over the steps
                # since the last refresh. Reuse steps commit to the pure time extrapolation; the
                # bookkeeping (f_hist, last_full_i, budget) mirrors the spec branch exactly.
                with timer("ops"):
                    # time-varying gate: linear ramp from spec_threshold (step 0) to spec_tau_end
                    # (last step), same convention as the spec branch
                    tau = method.spec_threshold
                    if method.spec_tau_end is not None:
                        tau = tau + (method.spec_tau_end - tau) * (i / (num_steps - 1))
                    pred_f = _spec_forecast(sf)
                    hist_age = i - last_full_i
                    curv = 0.0
                    if len(f_hist) >= 3:
                        # discrete curvature ‖f2 − 2 f1 + f0‖ / ‖f2‖ of the last three
                        # verified velocities (frozen since the last refresh)
                        (_, fr0), (_, fr1), (_, fr2) = f_hist[-3:]
                        d2f = acc(fr2) - 2 * acc(fr1) + acc(fr0)
                        curv = float(d2f.double().norm()
                                     / (acc(fr2).double().norm() + 1e-8))
                    # Without a computable signal the only safe action is to verify -- this also
                    # seeds the 3-point history (refresh=[0,1] alone leaves f_hist at 2 points,
                    # which would otherwise deadlock the gate at curv=0 forever; caught on the
                    # first MECH-R run where every arm collapsed to exactly 2 fulls).
                    verify = len(f_hist) < 3 or curv * hist_age > tau
                    gate_fired = bool(verify)
                if method.spec_tail_in_budget:
                    remaining_mandatory = sum(1 for j in refresh_set if j > i)
                    budget_ok = counts["full"] + remaining_mandatory < method.num_full
                else:
                    budget_ok = counts["full"] < method.num_full
                # R10-b reuse-span cap (same rule as the draft branch): force a verify past the
                # budget when the reuse span exceeds the cap
                cap_forced = method.spec_reuse_cap is not None \
                    and (i - last_full_i) > method.spec_reuse_cap
                if verify and (budget_ok or cap_forced):
                    f = fullx(x, sf)
                    counts["full"] += 1
                    counts["verify"] = counts.get("verify", 0) + 1
                    with timer("ops"):
                        fa = acc(f)
                    f_hist = (f_hist + [(sf, fa)])[-(1 + method.spec_ref_order):]
                    v, used = f, "verify_F"
                    f_ref = f
                    f_step, last_full_i = f, i
                else:
                    with timer("ops"):
                        v = _spec_forecast(sf)
                    used = "forecast"
            elif pred in ("spec", "spec_replay"):
                replay = pred == "spec_replay"  # E03 fixed-schedule replay: the gate is disabled
                # sigma-offset probe: the cheap estimator runs one (fractional) step off the true timestep.
                # Clamped to the valid range; 0.0 leaves the call bitwise identical to before.
                sf_draft = sf
                if method.spec_draft_sigma_offset:
                    sf_draft = min(1.0, max(1e-6, sf + method.spec_draft_sigma_offset))
                g = coarse(x, sf_draft)
                counts["coarse"] += 1
                hist_age = i - last_full_i
                # mixed-resolution schedule: tail drafts run at f=2 with their own difference cache
                in_f2_tail = bool(method.spec_draft_f2_tail) and i >= num_steps - method.spec_draft_f2_tail
                if in_f2_tail:
                    view2t = CoarseView(2, method.coarse_mode)
                    g2t = view2t(lambda y, t: model(y, t, "coarse", 2), x, sf)
                    counts["coarse2"] = counts.get("coarse2", 0) + 1
                with timer("ops"):
                    # time-varying gate: linear ramp from spec_threshold (step 0) to spec_tau_end (last step)
                    tau = method.spec_threshold
                    if method.spec_tau_end is not None:
                        tau = tau + (method.spec_tau_end - tau) * (i / (num_steps - 1))
                    if method.spec_step_weight:
                        # gate on the committed error estimate (div x step size): big steps are stricter
                        tau = tau * mean_abs_dsig / float(abs(s_next - s))
                    if in_f2_tail:
                        draft = acc(g2t) + d2_cache if d2_cache is not None else acc(g2t)
                        if method.spec_feedback is not None and fb_c is not None:
                            # closed-loop error feedback: EMA of the draft error measured at verify steps
                            draft = draft + fb_c
                    else:
                        draft = _spec_draft(g, sf)
                    pred_f = _spec_forecast(sf)
                    # spec_fusion_sea: build the Wiener-filtered residual-reuse member from
                    # the STALE residual (this step's possible verify refreshes sea_box only
                    # later, inside fullx) — the same stale-member discipline as f_ref.
                    sea_member = None
                    if method.spec_fusion_sea and sea_box[0] is not None:
                        with timer("ops"):
                            sea_filt = sea_wiener_filter(sea_box[0], method.spec_sea_a,
                                                         method.spec_sea_b, dims=(1,))
                        sea_member = acc(model.embed_reuse(x, sf, sea_filt))
                    div = div_lo = div_hi = None
                    if method.spec_hf_gate is None:
                        div_raw = float((draft - pred_f).double().norm() / (pred_f.double().norm() + 1e-8))
                        div = div_raw * gate_w[i] if gate_w is not None else div_raw
                        if method.spec_autotau is not None and cal_log is not None:
                            # self-calibrated gate: divergence scaled by the observed bias factor
                            div = div * math.exp(cal_log)
                        if gate_model is not None:
                            # learned gate (§8.81): fire on the predicted committed-error
                            # increment (same feature vector as scripts/train_gate.py, with
                            # w_lo/w_hi/drift_beta from the PREVIOUS commit — the gate decides
                            # before this step's commit exists). div carries the prediction
                            # into the shadow record.
                            _e = (draft - pred_f).double()
                            _plo, _phi = low_high_split(pred_f.double(), method.factor)
                            _elo, _ehi = low_high_split(_e, method.factor)
                            _blo = float(_elo.norm() / (_plo.norm() + 1e-8))
                            _bhi = float(_ehi.norm() / (_phi.norm() + 1e-8))
                            _bfrac = ((method.num_full - counts["full"]) / method.num_full) \
                                if method.num_full is not None else 1.0
                            _fd = gate_feature_dict(
                                sf, div_raw, _blo, _bhi, hist_age, float(abs(s_next - s)),
                                glw, ghw, gdb, _bfrac)
                            _feats = gate_feature_vector(_ck_features, _fd).unsqueeze(0)
                            with torch.no_grad():
                                gate_pred = float(gate_model((_feats - gate_mu) / gate_sd)[0])
                            # a predicted error increment is never negative — clamp the
                            # extrapolation floor (the closed-loop feature shift drives raw
                            # MLP outputs below the training label range, §8.81 十二续)
                            gate_pred = max(gate_pred, 0.0)
                            # threshold: fixed ckpt thr, or the per-trajectory quantile
                            # tracker (fires at the target rate of THIS prompt's prediction
                            # stream). The ckpt thr warm-seeds only the first few steps —
                            # it must not dominate the quantile (seed-dominance bug: 8 seeds
                            # pinned the 0.55-quantile all trajectory when most preds sit
                            # below the seed value).
                            thr_eff = gate_thr
                            if gate_rate_buf is not None:
                                _q = torch.quantile(torch.tensor(gate_rate_buf, dtype=torch.float32),
                                                    1.0 - method.spec_gate_learned_rate)
                                thr_eff = float(_q)
                                if math.isnan(thr_eff):        # NaN buffer (a NaN pred below)
                                    thr_eff = gate_thr          # —fall back to the ckpt thr
                            verify = False if (replay or method.spec_fixed_refresh is not None) \
                                else gate_pred > thr_eff
                            if gate_rate_buf is not None and not math.isnan(gate_pred):
                                gate_rate_buf.append(gate_pred)
                                if len(gate_rate_buf) > 24:   # cap: seeds wash out, tracker
                                    del gate_rate_buf[:-24]   # reflects the recent stream
                            gate_diag = (gate_pred, thr_eff)
                            div = gate_pred
                        else:
                            sig_eff = div
                            if method.spec_gate_predict is not None and sig_prev is not None \
                                    and sig_prev[1] == last_full_i:
                                sig_eff = div + method.spec_gate_predict * (div - sig_prev[0])
                            verify = False if (replay or method.spec_fixed_refresh is not None) \
                                else sig_eff > tau
                        if method.spec_gate_mean and not replay:
                            # accumulated-mean gate: fire when the MEAN divergence since the last
                            # full exceeds tau. hist_age == 1 means this is the first step after a
                            # refresh/verify -- restart the accumulator (resets without touching
                            # the four last_full_i assignment sites).
                            if hist_age <= 1:
                                g_sum = 0.0
                            g_sum += div_raw
                            mean_eff = g_sum / hist_age
                            if method.spec_gate_predict is not None and sig_prev is not None \
                                    and sig_prev[1] == last_full_i:
                                mean_eff = mean_eff + method.spec_gate_predict * (mean_eff - sig_prev[0])
                            verify = mean_eff > tau
                        if method.spec_gate_sub is not None:
                            # error-subspace gate: past verify residuals span the directions in
                            # which cheap predictors actually err. Project the current divergence
                            # onto that subspace (top-k right singular vectors of the residual
                            # buffer, on a strided subsample of <=4096 dims) and fire on the
                            # projected magnitude alone; a raw-divergence safety net at 1.5x tau
                            # catches error modes outside the historical subspace.
                            e_vec = (draft - pred_f).double()
                            if sub_idx is None:
                                n_el = e_vec.numel()
                                sub_idx = torch.arange(0, n_el, max(1, n_el // 4096),
                                                       device=e_vec.device)
                            if len(sub_res) >= max(4, method.spec_gate_sub):
                                R = torch.stack(sub_res[-32:]).float()
                                _, _, Vh = torch.linalg.svd(R, full_matrices=False)
                                P = Vh[: method.spec_gate_sub].T
                                es = e_vec.flatten()[sub_idx].float()
                                ps = pred_f.double().flatten()[sub_idx].float()
                                div_sub = float((es @ P).norm() / (ps.norm() + 1e-8))
                                verify = (div_sub > tau) or (div_raw > 1.5 * tau)
                    else:
                        # band-split gate: low-frequency error uses tau, high-frequency error uses
                        # tau * spec_hf_gate (tighter, since drafts lose texture detail there)
                        e = (draft - pred_f).double()
                        lo_e, hi_e = low_high_split(e, method.factor)
                        lo_p, hi_p = low_high_split(pred_f.double(), method.factor)
                        div_lo = float(lo_e.norm() / (lo_p.norm() + 1e-8))
                        div_hi = float(hi_e.norm() / (hi_p.norm() + 1e-8))
                        verify = (div_lo > tau) or (div_hi > tau * method.spec_hf_gate)
                    gate_fired = bool(verify)
                    if method.spec_gate_predict is not None and div is not None:
                        # seed the predictive gate with this step's signal (gm mean when the
                        # accumulated gate is on, raw divergence otherwise), tagged by
                        # last_full_i so a verify since the seed forces a one-step cooldown
                        _sig_now = (g_sum / hist_age) if method.spec_gate_mean else div
                        sig_prev = (_sig_now, last_full_i)
                    w_lo = w_hi = None
                # R11 coarse-increment accumulator gate, ORed with the divergence gate: the cheap
                # coarse output g is computed every step anyway; the relative step-to-step drift
                # of acc(g) accumulates into C, and exceeding tau_c forces a verify and resets C
                # (verify steps reset C too; refresh steps reset the reference via prev_acc_g).
                # The tau ramp above touches only the divergence gate — this one stays constant.
                if method.spec_coarse_acc_gate is not None:
                    with timer("ops"):
                        ga = acc(g)
                        if prev_acc_g is not None:
                            C += float((ga - prev_acc_g).double().norm()
                                       / (ga.double().norm() + 1e-8))
                        prev_acc_g = ga
                        if C > method.spec_coarse_acc_gate:
                            verify = True
                            C = 0.0
                    gate_fired = gate_fired or bool(verify)
                # tail-in-budget: mandatory tail refresh steps reserve their slots, so total full <= num_full
                if replay:
                    budget_ok = False  # replay never verifies; full steps come from the fixed schedule
                elif method.spec_tail_in_budget:
                    remaining_mandatory = sum(1 for j in refresh_set if j > i)
                    budget_ok = counts["full"] + remaining_mandatory < method.num_full
                else:
                    budget_ok = counts["full"] < method.num_full
                # D2 seeding: the first f=2-tail step always verifies, even past the budget
                # (one extra full forward; without it the tail draft would be a bare g2)
                force_verify = in_f2_tail and d2_cache is None
                if force_verify:
                    verify = True
                # R10-b reuse-span cap: more than `spec_reuse_cap` steps since the last full
                # forward force a verify — a hard correctness bound that bypasses the budget,
                # same spirit as the D2 seeding (it never blocks on budget_ok)
                cap_forced = method.spec_reuse_cap is not None \
                    and (i - last_full_i) > method.spec_reuse_cap
                if cap_forced:
                    verify = True
                # spec_defer_verify (SpeCa no-rollback acceptance): a FRESH gate-triggered fire
                # is not paid immediately — this step commits the accepted-step candidate and
                # the verify is scheduled for the next step (forced verifies — reuse cap, D2
                # seed — and the last step are never deferred). At the scheduled step the gate
                # has been re-evaluated for free above: still fired = persistent drift, pay the
                # full now; silent = transient fire, cancel and bank the budget. A step that
                # consumed a schedule and still fires verifies immediately (no deferral chains).
                was_scheduled = sched_verify and not cap_forced and not force_verify
                if was_scheduled:
                    if verify:
                        counts["verify_scheduled"] = counts.get("verify_scheduled", 0) + 1
                    else:
                        counts["verify_cancelled"] = counts.get("verify_cancelled", 0) + 1
                    sched_verify = False
                if verify and not was_scheduled and not cap_forced and not force_verify \
                        and method.spec_defer_verify and i < num_steps - 1:
                    sched_verify = True
                    verify = False
                    deferred_flag = True
                    counts["verify_deferred"] = counts.get("verify_deferred", 0) + 1
                # resolution-ladder verification: a triggered gate first tries the mid-resolution
                # (f=2) draft, which costs ~17% of a full forward; only if it also fails the gate
                # do we pay the full forward. D2 is refreshed whenever a full verify follows a
                # mid-rung evaluation (the mid forward is then reused, not wasted).
                if verify and method.spec_ladder and budget_ok and not in_f2_tail:
                    view2 = CoarseView(2, method.coarse_mode)
                    g2 = view2(lambda y, t: model(y, t, "coarse", 2), x, sf)
                    counts["coarse2"] = counts.get("coarse2", 0) + 1
                    with timer("ops"):
                        if d2_cache is not None:
                            draft2 = acc(g2) + d2_cache
                            div2 = float((draft2 - pred_f).double().norm()
                                         / (pred_f.double().norm() + 1e-8))
                            ladder_ok = div2 <= tau
                        else:
                            draft2, ladder_ok = None, False
                    if ladder_ok:
                        v, used = draft2, "draft_f2"
                        verify = False  # resolved at the mid rung; no full forward
                    else:
                        f = fullx(x, sf)
                        counts["full"] += 1
                        counts["verify"] = counts.get("verify", 0) + 1
                        with timer("ops"):
                            fa = acc(f)
                            d2_cache = fa - acc(g2)
                            if method.spec_autotau is not None:
                                # calibration: true committed error vs the raw gate divergence
                                true_rel = float((fa - draft).double().norm() / (fa.double().norm() + 1e-8))
                                ratio = min(max(true_rel / max(div_raw, 1e-8), 0.05), 20.0)
                                cal_log = math.log(ratio) if cal_log is None else (
                                    method.spec_autotau * cal_log + (1 - method.spec_autotau) * math.log(ratio))
                            if method.spec_feedback is not None:
                                e = fa - draft
                                fb_c = e if fb_c is None else (
                                    method.spec_feedback * fb_c + (1 - method.spec_feedback) * e)
                            _fusion_update(draft, pred_f, fa,
                                             fr_override=(sea_member if (sea_member is not None and i - last_full_i <= method.spec_sea_max_age) else None),
                                             er_on=((sea_member is not None and i - last_full_i <= method.spec_sea_max_age)
                                                    or method.spec_fref_max_age is None
                                                    or i - last_full_i <= method.spec_fref_max_age))
                            if method.spec_gate_sub is not None and sub_idx is not None:
                                sub_res.append((fa - draft).flatten()[sub_idx].detach())
                                del sub_res[:-64]
                            d_cache = fa - acc(g)
                        d_hist = (d_hist + [(sf, d_cache)])[-2:]
                        f_hist = (f_hist + [(sf, acc(f))])[-(1 + method.spec_ref_order):]
                        v, used = f, "verify_F"
                        f_ref = f          # R10-a: the f_ref fusion member tracks the last exact velocity
                        C = 0.0            # R11: verify steps reset the coarse-drift accumulator
                        f_step, last_full_i = f, i
                elif verify and method.spec_verify_tok_ratio is not None and budget_ok \
                        and not force_verify and not cap_forced:
                    # partial verify (Krea 2 only): recompute exactly the top-ratio
                    # disagreement patches through partial_forward and merge them into the
                    # draft commit. Immediate correction is kept (the defer lesson, §8.78);
                    # the saving is per-verify cost, not timing. Gate-triggered fires only —
                    # forced verifies (reuse cap, D2 seed) stay full above.
                    counts["verify_tok"] = counts.get("verify_tok", 0) + 1
                    with timer("ops"):
                        vmask = _verify_tok_mask(draft, pred_f, patch, gh, gw,
                                                 method.spec_verify_tok_ratio)
                    with timer("tok"):
                        v_part = model.partial_forward(x, sf, vmask)
                    with timer("ops"):
                        mb = (vmask.repeat_interleave(patch, dim=0).repeat_interleave(patch, dim=1)
                              if patch > 1 else vmask)
                        v = torch.where(mb.unsqueeze(0).unsqueeze(0), v_part, draft)
                        # Commit-only correction: the exact patches persist through the latent
                        # (the next draft re-reads them via g(x)), and NOT refreshing d_cache
                        # here is deliberate — the merged-output update d_cache = v - acc(g)
                        # re-imports this step's g-transients with inverted sign onto the
                        # selected patches and the gate then spends fulls re-cleaning them
                        # (falsified on the toy CPU test, 10-07). All cache/history state
                        # (d_cache, d_hist, f_hist, fusion calibration, autotau, feedback,
                        # gate_sub, R11, f_ref) stays untouched: full verifies own refreshes.
                    v, used = v, "verify_tok"
                elif verify and (budget_ok or force_verify or cap_forced):
                    f = fullx(x, sf)
                    counts["full"] += 1
                    counts["verify"] = counts.get("verify", 0) + 1
                    with timer("ops"):
                        fa = acc(f)
                        if in_f2_tail:
                            # free D2 refresh: the tail g2 forward is reused
                            d2_cache = fa - acc(g2t)
                        if method.spec_autotau is not None:
                            # calibration: true committed error vs the raw gate divergence
                            true_rel = float((fa - draft).double().norm() / (fa.double().norm() + 1e-8))
                            ratio = min(max(true_rel / max(div_raw, 1e-8), 0.05), 20.0)
                            cal_log = math.log(ratio) if cal_log is None else (
                                method.spec_autotau * cal_log + (1 - method.spec_autotau) * math.log(ratio))
                        if method.spec_feedback is not None:
                            # update the EMA of the (corrected) draft error measured against the truth
                            e = fa - draft
                            fb_c = e if fb_c is None else (
                                method.spec_feedback * fb_c + (1 - method.spec_feedback) * e
                            )
                        _fusion_update(draft, pred_f, fa,
                                             fr_override=(sea_member if (sea_member is not None and i - last_full_i <= method.spec_sea_max_age) else None),
                                             er_on=((sea_member is not None and i - last_full_i <= method.spec_sea_max_age)
                                                    or method.spec_fref_max_age is None
                                                    or i - last_full_i <= method.spec_fref_max_age))
                        if method.spec_drift_cal and g_acc_ref is not None and f_hist:
                            # verification-as-supervision (mechanism A): this full forward is a
                            # free label for the drift the reuse candidate would have committed;
                            # accumulate the closed-form least squares beta* = <D, F-F_ref>/<D, D>
                            delta_c = acc(g) - g_acc_ref
                            drift_num += float((delta_c.double()
                                                * (fa - f_hist[-1][1]).double()).sum())
                            drift_den += float(delta_c.double().pow(2).sum())
                            counts["drift_cal"] = counts.get("drift_cal", 0) + 1
                        if method.spec_gate_sub is not None and sub_idx is not None:
                            sub_res.append((fa - draft).flatten()[sub_idx].detach())
                            del sub_res[:-64]
                        d_cache = fa - acc(g)
                        g_acc_ref = acc(g)
                    d_hist = (d_hist + [(sf, d_cache)])[-2:]
                    f_hist = (f_hist + [(sf, acc(f))])[-(1 + method.spec_ref_order):]
                    v, used = f, "verify_F"
                    f_ref = f              # R10-a: the f_ref fusion member tracks the last exact velocity
                    C = 0.0                # R11: verify steps reset the coarse-drift accumulator
                    f_step, last_full_i = f, i
                elif fmode == "fixed05":
                    with timer("ops"):
                        v = 0.5 * draft + 0.5 * pred_f
                    w_lo = w_hi = 0.5
                    used = "fuse05"
                elif fmode in ("select", "scalar", "band") and fusion_n > 0:
                    with timer("ops"):
                        if method.spec_fusion3:
                            # R10-a three-way fusion. Members: draft (cross-resolution, current
                            # state), forecast (F-history extrapolation) and f_ref (the last exact
                            # velocity — stale but exact content). Per-band verify errors of all
                            # three accumulate in fband[0:6]; weights are inverse-error
                            # normalized (1/(MSE+eps)). Band mode: the lo band blends all three
                            # by weight, the hi band commits to the member with the smallest
                            # accumulated hi-band error. w_lo / w_hi keep their existing meaning:
                            # the draft member's share in each band.
                            eps = 1e-30
                            # staleness gates (§8.83 四续): the sea member first (its own cap,
                            # else fall through to f_ref), then f_ref's own cap; a member aged
                            # out degrades the fusion to its remaining two members.
                            _age = i - last_full_i
                            if sea_member is not None and _age <= method.spec_sea_max_age:
                                fr = sea_member
                            elif method.spec_fref_max_age is None or _age <= method.spec_fref_max_age:
                                fr = acc(f_ref)
                            else:
                                fr = None
                            if fmode == "select":
                                if fr is None:
                                    errs2 = (fusion_ed, fusion_ef)
                                    k = min(range(2), key=lambda j: errs2[j])
                                    v = (draft, pred_f)[k]
                                    w_lo = w_hi = (1.0 if k == 0 else 0.0)
                                else:
                                    # commit to whichever of the three shows the lower accumulated error
                                    errs3 = (fusion_ed, fusion_ef, fusion_er)
                                    k = min(range(3), key=lambda j: errs3[j])
                                    v = (draft, pred_f, fr)[k]
                                    w_lo = w_hi = (1.0 if k == 0 else 0.0)
                            elif fmode == "band" and fband[0] > 0:
                                d_lo, d_hi = low_high_split(draft, method.factor)
                                p_lo, p_hi = low_high_split(pred_f, method.factor)
                                if fr is None:
                                    wl = [1.0 / (fband[0] + eps), 1.0 / (fband[2] + eps)]
                                    sw = sum(wl)
                                    w_lo = wl[0] / sw
                                    errs_hi = (fband[1], fband[3])
                                    k = min(range(2), key=lambda j: errs_hi[j])
                                    w_hi = 1.0 if k == 0 else 0.0
                                    v = (wl[0] * d_lo + wl[1] * p_lo) / sw \
                                        + (d_hi, p_hi)[k]
                                else:
                                    wl = [1.0 / (fband[0] + eps), 1.0 / (fband[2] + eps),
                                          1.0 / (fband[4] + eps)]
                                    sw = sum(wl)
                                    w_lo = wl[0] / sw
                                    r_lo, r_hi = low_high_split(fr, method.factor)
                                    errs_hi = (fband[1], fband[3], fband[5])
                                    k = min(range(3), key=lambda j: errs_hi[j])
                                    w_hi = 1.0 if k == 0 else 0.0
                                    v = (wl[0] * d_lo + wl[1] * p_lo + wl[2] * r_lo) / sw \
                                        + (d_hi, p_hi, r_hi)[k]
                            else:
                                if fr is None:
                                    w = fusion_ef / (fusion_ed + fusion_ef + 1e-30)
                                    v = w * draft + (1.0 - w) * pred_f
                                    w_lo = w_hi = w
                                else:
                                    # scalar three-way inverse-error fusion
                                    w3 = [1.0 / (fusion_ed + eps), 1.0 / (fusion_ef + eps),
                                          1.0 / (fusion_er + eps)]
                                    sw = sum(w3)
                                    v = (w3[0] * draft + w3[1] * pred_f + w3[2] * fr) / sw
                                    w_lo = w_hi = w3[0] / sw
                        elif fmode == "select":
                            # commit to whichever predictor shows the lower accumulated error
                            if fusion_ed <= fusion_ef:
                                v, w_lo, w_hi = draft, 1.0, 1.0
                            else:
                                v, w_lo, w_hi = pred_f, 0.0, 0.0
                        elif fmode == "band" and fband[0] > 0:
                            # per-band inverse-error fusion: the draft usually wins the
                            # block-constant band (it sees the current state) while the forecast
                            # competes in the zero-mean band; each band gets its own weight
                            w_lo = fband[2] / (fband[0] + fband[2] + 1e-30)
                            w_hi = fband[3] / (fband[1] + fband[3] + 1e-30)
                            d_lo, d_hi = low_high_split(draft, method.factor)
                            p_lo, p_hi = low_high_split(pred_f, method.factor)
                            v = (w_lo * d_lo + (1.0 - w_lo) * p_lo) + (w_hi * d_hi + (1.0 - w_hi) * p_hi)
                        else:
                            # scalar inverse-error fusion: weight each cheap predictor by the
                            # other's observed MSE
                            w = fusion_ef / (fusion_ed + fusion_ef + 1e-30)
                            v = w * draft + (1.0 - w) * pred_f
                            w_lo = w_hi = w
                    used = "fuse_sel" if fmode == "select" else "fuse"
                else:
                    v, used = draft, "draft"
                if method.spec_kf_commit and used in ("draft", "fuse", "fuse_sel", "fuse05") \
                        and sar_hist and (i - last_full_i) <= method.spec_kf_max_age:
                    # v3.1xspec hybrid: fresh residual -> commit the SeaCache-core reuse
                    # velocity instead of the draft/fusion chain (stale steps keep the chain).
                    with timer("ops"):
                        if len(sar_hist) >= 2:
                            (i0, r0), (i1, r1) = sar_hist[-2], sar_hist[-1]
                            _scale = (i - i1) / max(i1 - i0, 1)
                            _resid = r1 + (r1 - r0) * _scale
                        else:
                            _resid = sar_hist[-1][1]
                        v_kf = model.embed_reuse(x, sf, _resid)
                        if method.spec_kf_band:
                            # lever ①: the residual's LO band (layout) outlives its HI band
                            # (texture) -- commit lo from the reuse, hi from the chain
                            k_lo, _k_hi = low_high_split(v_kf, method.factor)
                            _c_lo, c_hi = low_high_split(v, method.factor)
                            v = k_lo + c_hi
                        elif method.spec_kf_mean is not None:
                            # ensemble commit: average the residual-reuse velocity with the
                            # draft/fusion chain commit -- two near-unbiased predictors with
                            # independent errors; the mean typically gains +0.2-0.3dB, which
                            # is exactly the residual gap on the last table rows
                            v = (1.0 - method.spec_kf_mean) * v + method.spec_kf_mean * v_kf
                        else:
                            v = v_kf
                    used = ("sar_reuse_band" if method.spec_kf_band
                            else "sar_reuse_mean" if method.spec_kf_mean is not None
                            else "sar_reuse")
                if drift_on and g_acc_ref is not None and used in ("draft", "fuse05", "fuse_sel", "fuse"):
                    with timer("ops"):
                        # drift-corrected reuse (mechanism B, commit modifier): additive
                        # coarse-drift correction on top of whatever the commit chain produced
                        # (plain draft or fusion output). beta = 1 leaves the underlying commit
                        # bitwise untouched; with fusion off, beta = 1 recovers the plain draft.
                        drift_beta_used = (min(max(drift_num / drift_den, 0.0), 2.0)
                                           if method.spec_drift_cal and drift_den > 0.0
                                           else method.spec_drift_weight)
                        v = v + (drift_beta_used - 1.0) * (acc(g) - g_acc_ref)
                    if used == "draft":
                        used = "drift_cal" if method.spec_drift_cal else "drift"
                    else:
                        used = used + ("_drift_cal" if method.spec_drift_cal else "_drift")
                if shadow_on:
                    step_draft, step_pred = draft, pred_f
                    gate = {"tau": None if replay else float(tau), "g": div,
                            "div_lo": div_lo, "div_hi": div_hi, "gate_fired": gate_fired,
                            "deferred": deferred_flag,
                            "w_lo": w_lo, "w_hi": w_hi, "history_age": hist_age,
                            "drift_beta": drift_beta_used}
            elif pred == "spec_tok":
                # Token-level partial refresh: select the top-delta patches (+ an eps fraction of
                # uniform-random ones) and recompute exactly those image tokens at full resolution;
                # the rest are copied from the committed velocity inside partial_forward. No step
                # skipping, no coarse forward, no gate -- one partial call per step.
                with timer("ops"):
                    mask = _spec_tok_mask(method, v_prev, v_prevprev, patch, gh, gw,
                                          i, num_steps, seed, x.device)
                with timer("tok"):
                    v = model.partial_forward(x, sf, mask)
                counts["tok"] = counts.get("tok", 0) + 1
                used = "tok"
            elif pred == "spec_skip":
                # Drift-gated deep-block skipping (R9): the shallow path (fb_first + fb_reuse) runs
                # every step; the deep stack (fb_full) runs at step 0 / warmup / tail / gate. The
                # gate is SeaCache-style on the LATENT drift rel = ||x - x_ref|| / ||x_ref|| (the
                # shallow-output drift turned out to be non-discriminative), plus a bridge trigger
                # on the predicted drift-corrected residual displacement
                # ||beta_vec * (h0 - h0_ref)|| / ||residual_ref||. On a deep step the references
                # refresh and contribute one least-squares pair PER CHANNEL to the diagonal bridge
                # beta_vec[d] = num[d]/den[d] (den == 0 channels fall back to 1.0, clamp [0, 2]);
                # on a reuse step the cached residual is drift-corrected,
                # residual_used = residual_ref + beta_vec * (h0 - h0_ref), before norm_out/proj_out.
                with timer("shallow"):
                    h0 = model.fb_first(x, sf)
                with timer("ops"):
                    tau = method.spec_skip_tau
                    if method.spec_skip_tau_end is not None and num_steps > 1:
                        # linear ramp spec_skip_tau (step 0) -> spec_skip_tau_end (last step),
                        # same convention as the spec branch's spec_tau_end
                        tau = tau + (method.spec_skip_tau_end - tau) * (i / (num_steps - 1))
                    # diagonal bridge beta, viewed to broadcast against the hidden layout:
                    # [B, L, D] tokens -> [1, 1, D]; [B, C, H, W] spatial -> [1, C, 1, 1]
                    if skip_den is None:
                        skip_beta = 1.0   # no fit yet: the unit bridge
                    else:
                        beta_vec = torch.where(skip_den > 0,
                                               (skip_num / skip_den.clamp_min(1e-30)).clamp(0.0, 2.0),
                                               torch.ones_like(skip_den))
                        ch = 1 if acc(h0).dim() == 4 else acc(h0).dim() - 1
                        view = [1] * acc(h0).dim()
                        view[ch] = -1
                        skip_beta = beta_vec.view(view)
                    if skip_x_ref is None:
                        gate_fired = True   # no reference to gate against: seed it with a deep step
                    else:
                        rel_lat = float((acc(x) - skip_x_ref).double().norm()
                                        / (skip_x_ref.double().norm() + 1e-8))
                        bridge = float((skip_beta * (acc(h0) - skip_h0_ref)).double().norm()
                                       / (skip_residual_ref.double().norm() + 1e-8))
                        gate_fired = (rel_lat > tau) or (bridge > tau)
                if i < method.spec_skip_warmup or i >= num_steps - method.spec_skip_tail \
                        or gate_fired:
                    with timer("deep"):
                        v, h0_new, residual_new = model.fb_full(x, sf)
                    counts["full"] += 1
                    with timer("ops"):
                        h0_acc, res_acc = acc(h0_new), acc(residual_new)
                        if skip_h0_ref is not None:
                            # this deep step is a free label for the residual drift vs the shallow
                            # drift since the last reference, accumulated per channel:
                            # num[d] += <d_res, d_h0>_d, den[d] += <d_h0, d_h0>_d (the diagonal
                            # bridge; under-correction by a scalar beta was death cause 1)
                            d_h0 = h0_acc - skip_h0_ref
                            d_res = res_acc - skip_residual_ref
                            ch = 1 if d_h0.dim() == 4 else d_h0.dim() - 1
                            red = tuple(k for k in range(d_h0.dim()) if k != ch)
                            num_c = (d_res * d_h0).sum(dim=red)
                            den_c = (d_h0 * d_h0).sum(dim=red)
                            skip_num = num_c if skip_num is None else skip_num + num_c
                            skip_den = den_c if skip_den is None else skip_den + den_c
                        skip_x_ref = acc(x)
                        skip_h0_ref, skip_residual_ref = h0_acc, res_acc
                    used = "F"
                else:
                    with timer("ops"):
                        residual_used = skip_residual_ref + skip_beta * (acc(h0) - skip_h0_ref)
                        # references are kept in float32 (accumulator precision) but the reuse
                        # path feeds a bf16 linear: cast back to the activation dtype
                        residual_used = residual_used.to(h0.dtype)
                    with timer("shallow"):
                        v = model.fb_reuse(x, sf, h0, residual_used)
                    counts["coarse"] += 1
                    used = "S"
            elif pred == "teacache":
                # TeaCache (output-level variant): cheap probe of block-0 AdaLN-modulated input, accumulated
                # polynomial-rescaled rel-L1 distance gates reuse of the last computed velocity.
                # Qwen-Image coefficients from vLLM-Omni / ComfyUI-TeaCache (community-calibrated).
                probe = getattr(model, "probe", None)
                if probe is None:
                    raise ValueError("teacache predictor needs a model with a `probe(x, sigma)` method")
                with timer("ops"):
                    m_t = probe(x, sf)
                    if tea_probe_prev is None:
                        compute = True
                    else:
                        rel_l1 = float((m_t - tea_probe_prev).abs().mean()
                                       / (tea_probe_prev.abs().mean() + 1e-8))
                        tea_acc += _teacache_poly(rel_l1)
                        compute = tea_acc > method.teacache_thresh
                    tea_probe_prev = m_t
                    if i == num_steps - 1:
                        compute = True  # TeaCache always computes the last step
                if compute:
                    tea_acc = 0.0
                    f = fullx(x, sf)
                    counts["full"] += 1
                    f_ref = f
                    v, used = f, "tea_F"
                else:
                    v, used = f_ref, "tea_reuse"
            elif pred == "taylor_f":
                # TaylorSeer-lite on the velocity output: Newton divided-difference extrapolation from the
                # last `taylor_order + 1` full evaluations (refresh schedule = uniform, like linear_f).
                order = min(method.taylor_order, len(f_hist) - 1)
                if order < 1:
                    v, used = f_hist[-1][1], "F_r"
                else:
                    with timer("ops"):
                        pts = f_hist[-(order + 1):][::-1]  # newest first: (s0, F0), (s1, F1), ...
                        v = pts[0][1].clone()
                        prod = None
                        # Newton coefficients from newest node outward
                        coefs = [p[1] for p in pts]
                        ss = [p[0] for p in pts]
                        dd = list(coefs)
                        for k in range(1, order + 1):
                            dd = [(dd[j] - dd[j + 1]) / (ss[j] - ss[j + k]) for j in range(len(dd) - 1)]
                            prod = (sf - ss[0]) if prod is None else prod * (sf - ss[k - 1])
                            v = v + dd[0] * prod
                    used = f"taylor{order}(F)"
            elif pred == "easycache":
                # EasyCache (output-level variant): reuse the last velocity while the accumulated
                # relative-change estimate stays under the threshold; the observed rate persists.
                # easy_rate == 0 means no estimate yet (only one compute so far) -> compute again.
                compute = easy_v is None or easy_rate == 0.0 or (easy_acc + easy_rate) > method.easy_thresh
                if i == num_steps - 1:
                    compute = True
                if compute:
                    f = fullx(x, sf)
                    counts["full"] += 1
                    with timer("ops"):
                        fa = acc(f)
                        if easy_v is not None:
                            easy_rate = float((fa - easy_v).double().norm() / (easy_v.double().norm() + 1e-8))
                        easy_acc = 0.0
                        easy_v = fa
                    v, used = f, "easy_F"
                else:
                    with timer("ops"):
                        easy_acc += easy_rate
                    v, used = easy_v, "easy_reuse"
            elif pred == "fbcache":
                # FBCache (FirstBlockCache, as in diffusers/ParaAttention): per-step rel-L1 change of the
                # block-0 *output* gates reuse of the cached (last-block - block-0) hidden residual; the
                # reuse pass adds it to the current block-0 output and applies norm_out/proj_out only.
                for attr in ("fb_first", "fb_full", "fb_reuse"):
                    if getattr(model, attr, None) is None:
                        raise ValueError(f"fbcache predictor needs a model with a `{attr}` method")
                with timer("ops"):
                    h0 = model.fb_first(x, sf)
                    if fb_h0_prev is None:
                        compute = True
                    else:
                        rel_l1 = float((h0 - fb_h0_prev).abs().mean()
                                       / (fb_h0_prev.abs().mean() + 1e-8))
                        compute = rel_l1 > method.fb_thresh
                if i == num_steps - 1:
                    compute = True
                if compute:
                    v, h0, fb_residual = model.fb_full(x, sf)
                    counts["full"] += 1
                    used = "fb_F"
                else:
                    with timer("ops"):
                        v = model.fb_reuse(x, sf, h0, fb_residual)
                    used = "fb_reuse"
                fb_h0_prev = h0
            elif pred == "seacache":
                # SeaCache (CVPR 2026) faithful: TeaCache's output-level cache, but the reuse
                # distance is computed on SEA-Wiener-filtered block-0 input features with the
                # flow-schedule filter (a_t = 1 - sigma, b_t = sigma) — noise-phase steps are
                # distance-blind, content-phase steps fully sensitive (§8.87 三续).
                probe = getattr(model, "probe", None)
                if not callable(probe):
                    raise ValueError("seacache predictor needs a model with a `probe(x, sigma)` method")
                with timer("ops"):
                    m_raw = probe(x, sf)
                    _nd = m_raw.dim()
                    _dims = tuple(range(2, _nd)) if _nd >= 4 else ((1,) if _nd == 3 else tuple(range(_nd)))
                    m_t = sea_wiener_filter(m_raw, 1.0 - sf, sf,
                                            power_exp=method.seacache_power_exp, dims=_dims)
                    if sc_probe_prev is None:
                        compute = True
                    else:
                        rel_l1 = float((m_t - sc_probe_prev).abs().mean()
                                       / (sc_probe_prev.abs().mean() + 1e-8))
                        sc_acc += rel_l1
                        compute = sc_acc > method.seacache_thresh
                    sc_probe_prev = m_t
                    if i == num_steps - 1:
                        compute = True  # SeaCache always computes the last step
                if compute:
                    sc_acc = 0.0
                    f = full(x, sf)
                    counts["full"] += 1
                    sc_v = acc(f)
                    v, used = f, "sea_F"
                else:
                    v, used = sc_v, "sea_reuse"
            elif pred == "sarcache":
                # SeaCache-core: hidden-residual reuse with order-1 extrapolation, a
                # consecutive-reuse staleness cap, and an accumulated rel-L1 gate (v3: raw
                # residual commit, step-index scale; v3.1: official image-space SEA indicator).
                if not (callable(getattr(model, "embed", None))
                        and callable(getattr(model, "embed_full", None))
                        and callable(getattr(model, "embed_reuse", None))):
                    raise NotImplementedError("sarcache needs embed/embed_full/embed_reuse "
                                              "(embed-capable adapter, single-branch guidance)")
                if sar_fixed is None:
                    # fixed refresh replay: the gate is off, the probe (embed / image
                    # indicator) is dead work -- skip it entirely.
                    with timer("ops"):
                        if method.sarcache_img_indicator and not method.sarcache_krate:
                            # official SEA indicator: the Wiener runs on the raw INPUT LATENT in
                            # image space (2D FFT over H,W; a=1-sigma, b=sigma), NOT on the block-0
                            # token embedding -- the v3 pilot lost 3.8dB at Sea's own speed with
                            # the token-axis filter (10-08), the gate domain was the mismatch.
                            _xd = x.dim()
                            ind = sea_wiener_filter(x.float(), 1.0 - float(sf), float(sf),
                                                    dims=tuple(range(2, _xd)) if _xd >= 3 else (-1,))
                            probe_g = ind.to(x.dtype)
                        else:
                            # krate mode uses the RAW unfiltered stack input (official raw_input);
                            # the plain embed gate optionally Wiener-filters it
                            probe = model.embed(x)
                            if method.sarcache_filter_gate and not method.sarcache_krate:
                                _nd = probe.dim()
                                _dims = tuple(range(2, _nd)) if _nd >= 4 else ((1,) if _nd == 3 else tuple(range(_nd)))
                                probe_g = sea_wiener_filter(probe, 1.0 - sf, sf, dims=_dims)
                            else:
                                probe_g = probe
                if sar_resid is None:
                    compute = True
                elif sar_fixed is not None:
                    # fixed refresh replay (SARCache §3): the position list IS the schedule --
                    # the adaptive gate, the staleness cap and warmup are all bypassed (the
                    # combining knobs are rejected in __post_init__). Step 0 landed in sar_fixed
                    # at resolve time; the last step was auto-appended when the list missed it.
                    compute = i in sar_fixed
                    if compute and sar_fixed_auto_tail and i == num_steps - 1:
                        auto_tail_full = True
                else:
                    with timer("ops"):
                        if method.sarcache_krate:
                            # EC's propagation-rate gate (official_sampling.py:141-143): the
                            # per-step INPUT change times the observed output/input rate k,
                            # velocity-normalized. k refreshes at computed-step pairs. This is
                            # the last unaligned official semantic -- the residual-recombine
                            # commit is already identical to EC's (the ecoc output-FREEZE probe
                            # lost 3.5-4.5dB, 10-09).
                            _din = float((probe_g.double() - sar_probe_prev.double()).abs().mean())
                            rel = (sar_k * _din / (sar_v_mean + 1e-8)) if sar_k is not None else 0.0
                        else:
                            rel = float((probe_g.double() - sar_probe_prev.double()).abs().mean()
                                        / (sar_probe_prev.double().abs().mean() + 1e-8))
                    sar_acc += rel
                    compute = (sar_acc > method.sarcache_thresh or i == num_steps - 1
                               or (method.sarcache_max_reuse > 0
                                   and sar_reuse_n >= method.sarcache_max_reuse)
                               or (method.sarcache_warmup > 1 and i < method.sarcache_warmup))
                    if method.sarcache_img_indicator:
                        # official semantics: the indicator reference refreshes EVERY step
                        # (hit or compute) -- distance is step-to-step drift, not drift-since-
                        # last-compute. The accumulation alone carries the staleness budget.
                        sar_probe_prev = probe_g
                    if method.sarcache_krate:
                        # krate: the raw-input reference refreshes EVERY step (official
                        # previous_raw_input is per-step), only the gate signal uses it
                        sar_probe_prev = probe_g
                if compute:
                    with timer("full"):
                        v, emb, resid = model.embed_full(x, sf)
                    counts["full"] += 1
                    if method.sarcache_krate:
                        if sar_v_prev is not None:
                            _kn = float((v.double() - sar_v_prev.double()).abs().mean())
                            _kd = float((emb.double() - sar_emb_prev.double()).abs().mean())
                            sar_k = _kn / max(_kd, 1e-8)
                        sar_v_prev = v
                        sar_emb_prev = emb
                        sar_v_mean = float(v.double().abs().mean())
                    sar_resid_prev = (sar_resid_sig, sar_resid) if sar_resid is not None else None
                    sar_resid_prev_i = sar_resid_i
                    sar_resid = resid
                    sar_resid_sig = sf
                    sar_resid_i = i
                    sar_v_cache = v
                    if sar_fixed is None:
                        sar_probe_prev = probe_g
                    sar_acc = 0.0
                    sar_reuse_n = 0
                    if auto_tail_full:
                        # the plan's末步必须-full rule: the user list missed the last step, so
                        # the sampler appended it -- marked here and in this step's record.
                        counts["fixed_refresh_auto_tail"] = counts.get("fixed_refresh_auto_tail", 0) + 1
                    used = "sar_F"
                else:
                    with timer("ops"):
                        # SARCache §3 age window: resolve a -- the explicit
                        # forecast_age_window, else the legacy sarcache_order compatibility map
                        # (0 -> a=0 pure hold, 1 -> unbounded linear, 2 -> a=2; bitwise the
                        # pre-window adaptive rule). age = i - j <= a extrapolates
                        # r_j + (i-j)/(j-k) * (r_j - r_k), older reuse steps hold r_j; a single
                        # fresh residual always holds; the window never triggers a refresh.
                        _win = method.forecast_age_window
                        if _win is None:
                            _win = 0 if method.sarcache_order == 0 else (
                                "unbounded" if method.sarcache_order == 1 else 2)
                        _extrap = sar_resid_prev is not None and (
                            _win == "unbounded" or (i - sar_resid_i) <= _win)
                        # window activation record: of the ELIGIBLE reuse steps (two fresh
                        # residuals, so a linear forecast existed to fall back from), the ones
                        # where age > a degraded the commit from linear to hold. Offline,
                        # win_fallback / win_eligible is the realised window-activation rate
                        # -- 0 under "unbounded", and 0 whenever the cap keeps age <= a (the
                        # q<=a finite==unbounded equivalence the calibration records must
                        # flag, not attribute to the window). Not counted under
                        # sarcache_output_cache: the forecast never reaches the commit there.
                        if sar_resid_prev is not None and not method.sarcache_output_cache:
                            counts["win_eligible"] = counts.get("win_eligible", 0) + 1
                            if _win != "unbounded" and (i - sar_resid_i) > _win:
                                counts["win_fallback"] = counts.get("win_fallback", 0) + 1
                        if _extrap:
                            s0, r0 = sar_resid_prev
                            s1, r1 = sar_resid_sig, sar_resid
                            if method.sarcache_raw_residual:
                                # official scale: step-index space (sea_cache.py), unit spacing
                                # gives 2*latest - previous
                                scale = (i - sar_resid_i) / max(sar_resid_i - sar_resid_prev_i, 1)
                            else:
                                # NB (10-08 double bug): (1) sigmas arrive as 0-dim tensors on
                                # real schedules — Python max(tensor, eps) returns eps whenever
                                # the comparison tensor>float is False; (2) FAR worse, the clamp
                                # itself is sign-blind: s1-s0 is NEGATIVE on any decreasing
                                # schedule, so max(s1-s0, 1e-8) == 1e-8 and the scale explodes
                                # to ~1e8 — v2's pilot committed 1e6-magnitude garbage residuals
                                # (its real death cause, misattributed to extrapolation noise in
                                # §8.87). Guard |denom| instead; the ratio keeps its natural sign.
                                _den = float(s1) - float(s0)
                                scale = (float(sf) - float(s1)) / (_den if abs(_den) > 1e-8 else 1e-8)
                            resid_used = r1 + (r1 - r0) * scale
                        else:
                            resid_used = sar_resid
                        if method.sarcache_output_cache:
                            # EC (EasyCache) commit semantics: reuse the STALE CACHED VELOCITY
                            # itself -- the whole-output cache, no residual recombination and
                            # no extrapolation. The residual path re-derives the head from the
                            # current embed; EC's premise is that the cached output stays the
                            # best estimate until the gate fires (its 2.4-2.9x band strength).
                            v = sar_v_cache
                        elif method.sarcache_raw_residual:
                            v = model.embed_reuse(x, sf, resid_used)
                        else:
                            v = model.embed_reuse(x, sf, sea_wiener_filter(
                                resid_used, method.sarcache_a, method.sarcache_b, dims=(1,)))
                    sar_reuse_n += 1
                    counts["coarse"] += 1
                    used = "sar_ocache" if method.sarcache_output_cache else "sar_reuse"
            elif pred == "seacache":
                # SeaCache (CVPR 2026) faithful: TeaCache's output-level cache, but the reuse
                # distance is computed on SEA-Wiener-filtered block-0 input features with the
                # flow-schedule filter (a_t = 1 - sigma, b_t = sigma) — noise-phase steps are
                # distance-blind, content-phase steps fully sensitive (§8.87 三续).
                probe = getattr(model, "probe", None)
                if not callable(probe):
                    raise ValueError("seacache predictor needs a model with a `probe(x, sigma)` method")
                with timer("ops"):
                    m_raw = probe(x, sf)
                    _nd = m_raw.dim()
                    _dims = tuple(range(2, _nd)) if _nd >= 4 else ((1,) if _nd == 3 else tuple(range(_nd)))
                    m_t = sea_wiener_filter(m_raw, 1.0 - sf, sf,
                                            power_exp=method.seacache_power_exp, dims=_dims)
                    if sc_probe_prev is None:
                        compute = True
                    else:
                        rel_l1 = float((m_t - sc_probe_prev).abs().mean()
                                       / (sc_probe_prev.abs().mean() + 1e-8))
                        sc_acc += rel_l1
                        compute = sc_acc > method.seacache_thresh
                    sc_probe_prev = m_t
                    if i == num_steps - 1:
                        compute = True  # SeaCache always computes the last step
                if compute:
                    sc_acc = 0.0
                    f = full(x, sf)
                    counts["full"] += 1
                    sc_v = acc(f)
                    v, used = f, "sea_F"
                else:
                    v, used = sc_v, "sea_reuse"
            elif pred == "sarcache":
                # SeaCache-core v1 (§8.87, Krea 2 only): the embed (img_in) probe is the cheap
                # drift signal; the gate accumulates the probe rel-L1 (SeaCache semantics);
                # compute steps run embed_full (velocity + fresh hidden residual), reuse steps
                # commit embed_reuse(current embed, Wiener-filtered cached residual).
                if not (callable(getattr(model, "embed", None))
                        and callable(getattr(model, "embed_full", None))
                        and callable(getattr(model, "embed_reuse", None))):
                    raise NotImplementedError("sarcache needs embed/embed_full/embed_reuse "
                                              "(Krea 2 adapter, guidance_scale 0)")
                with timer("ops"):
                    probe = model.embed(x)
                if sar_resid is None:
                    compute = True
                else:
                    with timer("ops"):
                        rel = float((probe.double() - sar_probe_prev.double()).abs().mean()
                                    / (sar_probe_prev.double().abs().mean() + 1e-8))
                    sar_acc += rel
                    compute = sar_acc > method.sarcache_thresh or i == num_steps - 1
                if compute:
                    with timer("full"):
                        v, emb, resid = model.embed_full(x, sf)
                    counts["full"] += 1
                    sar_resid = resid
                    sar_probe_prev = emb
                    sar_acc = 0.0
                    used = "sar_F"
                else:
                    with timer("ops"):
                        v = model.embed_reuse(x, sf, sea_wiener_filter(
                            sar_resid, method.sarcache_a, method.sarcache_b, dims=(1,)))
                    counts["coarse"] += 1
                    used = "sar_reuse"
            elif pred == "freqca":
                # FreqCa (arXiv:2510.08669, Sec. 3) faithful reimplementation, output-level:
                # the model output plays the role of the paper's CRF. Cache steps recombine the
                # reused low band with a second-order Hermite extrapolation of the high band;
                # compute steps refresh both. The schedule is the paper's fixed interval N
                # (freqca_interval) or an online gate on the accumulated relative change of the
                # latent's low band (freqca_thresh; 0 = identity). Steps 0, 1 and the last step
                # always compute (history seeding + detail phase).
                s_t = 2.0 * i / (num_steps - 1) - 1.0 if num_steps > 1 else 0.0
                with timer("ops"):
                    lo_x = _freqca_split(acc(x), method.freqca_low_ratio, method.freqca_transform)[0]
                    if fc_xlow is not None:
                        fc_acc += float((lo_x - fc_xlow).double().norm()
                                        / (fc_xlow.double().norm() + 1e-8))
                    fc_xlow = lo_x
                    forced = i < 2 or i == num_steps - 1
                    if method.freqca_interval is not None:
                        compute = forced or i % method.freqca_interval == 0
                    else:
                        compute = forced or fc_acc >= method.freqca_thresh
                if compute:
                    f = fullx(x, sf)
                    counts["full"] += 1
                    with timer("ops"):
                        fc_low, fc_hi = _freqca_split(acc(f), method.freqca_low_ratio,
                                                      method.freqca_transform)
                        fc_hist = (fc_hist + [(s_t, fc_hi)])[-method.freqca_hermite_k:]
                    fc_acc = 0.0
                    v, used = f, "fc_F"
                else:
                    with timer("ops"):
                        v = fc_low + _freqca_hermite_predict(fc_hist, s_t)
                    used = "fc_reuse"
            else:
                raise AssertionError(pred)
        if pred == "spec_tok":
            # committed-velocity history roll (the delta signal selects next step's patches)
            v_prevprev, v_prev = v_prev, v
        if shadow_on:
            # E1/E04 shadow-full: evaluate the exact full forward on the *current accelerated
            # latent*, record-only. It never updates x, the D/F histories, the fusion statistics,
            # the gate or the budget; adapter cache state is isolated and restored around the call.
            # A full forward already computed at this step (refresh / verify) is reused for free.
            with timer("shadow"):
                if f_step is not None:
                    fs = acc(f_step)
                else:
                    with _shadow_isolated(model):
                        fs = acc(model(x, sf, "full", 1))
                    counts["shadow_full"] = counts.get("shadow_full", 0) + 1
                den = fs.double().norm() + 1e-8

                def _errs(a):
                    if a is None:
                        return None, None, None
                    e = a.double() - fs.double()
                    e_lo, e_hi = low_high_split(e, method.factor)
                    return (float(e.norm() / den), float(e_lo.norm() / den), float(e_hi.norm() / den))

                e_draft = _errs(step_draft)
                e_pred = _errs(step_pred)
                e_fused = _errs(acc(v))
                verified = f_step is not None and i not in refresh_set
                budget_forced = bool(gate and gate["gate_fired"] and not verified)
                state = ("refresh" if i in refresh_set else
                         "verified" if verified else
                         "budget_forced" if budget_forced else "accepted")
                shadow.append({
                    "step": i, "sigma": sf, "state": state, "used": used,
                    "tau": gate["tau"] if gate else None,
                    "g": gate["g"] if gate else None,
                    "div_lo": gate["div_lo"] if gate else None,
                    "div_hi": gate["div_hi"] if gate else None,
                    "gate_fired": gate["gate_fired"] if gate else None,
                    "deferred": gate["deferred"] if gate else None,
                    "verified": verified, "budget_forced": budget_forced,
                    "budget_remaining": (method.num_full - counts["full"])
                                        if method.num_full is not None else None,
                    "history_age": gate["history_age"] if gate else 0,
                    "fusion_mode": fmode,
                    "w_lo": gate["w_lo"] if gate else None,
                    "w_hi": gate["w_hi"] if gate else None,
                    "drift_beta": gate["drift_beta"] if gate else None,
                    "E_draft": e_draft[0], "E_draft_lo": e_draft[1], "E_draft_hi": e_draft[2],
                    "E_forecast": e_pred[0], "E_forecast_lo": e_pred[1], "E_forecast_hi": e_pred[2],
                    "E_fused": e_fused[0], "E_fused_lo": e_fused[1], "E_fused_hi": e_fused[2],
                    "dsigma": float(abs(s_next - s)),
                })
        with timer("ops"):
            x = euler_update(x, v, s, s_next)
        if record:
            _sr = {"step": i, "sigma": sf, "used": used}
            if gate_diag is not None:
                _sr["gate_pred"], _sr["gate_thr_eff"] = gate_diag
            if auto_tail_full:
                # sarcache fixed refresh: this step's full was auto-appended (the user list
                # missed the last step; the plan requires a full at the末步)
                _sr["auto_tail_full"] = True
            steps.append(_sr)
        if gate_model is not None:
            # learned-gate feature carriers: this step's commit-side values become next
            # step's w_lo/w_hi/drift_beta features (the gate decides before the commit)
            glw = float(w_lo) if w_lo is not None else 0.5
            ghw = float(w_hi) if w_hi is not None else 0.5
            gdb = float(drift_beta_used) if drift_beta_used is not None else 1.0
    return SampleResult(latents=x, refresh=refresh, counts=counts, timing=timer.summary(),
                        steps=steps, shadow=shadow)
