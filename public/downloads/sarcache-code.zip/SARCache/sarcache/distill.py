"""Distilled f4 draft student for the spec predictor (replaces the untrained coarse forward).

The student distills the teacher's FULL-grid velocity into a cheap network that only ever runs at the
f4 grid: the first-``K`` frozen blocks of the Qwen-Image-2.1 transformer, executed as a joint
[text, image] forward at the pooled 32x32 grid, plus a small trainable conv decoder head per depth
that upsamples the block-``K`` hidden state to the full 128x128 velocity. Heads exist at several
depths (default ``(8, 12, 16)``); the active one is selected with ``set_depth``.

Parameterization (verified against the sampler, 2026-10-04):
  * the package convention is the flow-matching form ``x_sigma = (1 - sigma) * x0 + sigma * eps`` with
    velocity ``dx/dsigma = eps - x0`` (sarcache/operators.py:5);
  * the Euler integrator commits ``x <- x + (sigma_next - sigma) * v`` (sarcache/sampler.py:770-775,
    ``euler_update``), looping over ``sig[i], sig[i+1]`` of the fp32 sigma grid
    (sarcache/sampler.py:849-850, 970-972) starting from ``x = x_init`` (sarcache/sampler.py:877),
    where ``x_init`` is unit noise from the pipeline's own ``prepare_latents`` and the grid is
    ``scheduler_sigmas(pipe.scheduler, 40, image_seq_len=...)`` with Qwen's dynamic shift
    (sarcache/pipelines.py:118-123);
  * the training target is therefore the teacher's role="full" output at ``(x_t, sigma)`` with
    ``x_t = sigma * eps + (1 - sigma) * x0`` — the teacher output IS ``eps - x0`` under this
    convention, which is exactly what the sampler integrates;
  * data generation saves ``SampleResult.latents`` after the last Euler step: the terminal sigma is
    0, so the committed latent equals the x0 estimate (sarcache/sampler.py:1660-1663);
  * eval and training sample sigma uniformly over the same 40-point grid BY STEP INDEX
    (indices 0..39; the 41st grid entry sigma=0 is the terminal and is never queried).

Grid / position convention: the trunk replicates the adapter's coarse-call setup with
``coarse_positions="native"`` (the sota_final config value) — no ``aligned_rope`` override
(sarcache/adapters/qwenimage21.py:312-313), so the pooled grid gets the model's own centred
integer RoPE grid (QwenImage21Rope lays the target block out on ``range(-(n - n//2), n//2)`` per
axis). The joint sequence, the 2x2-slot ``img_mask`` (``h * w // 4`` target slots), the t=0
modulation row for text tokens under ``causal_condition``, and the block-causal mask are built
exactly as the diffusers ``QwenImage21Transformer2DModel.forward`` prefill does (vendored body
below, trimmed to the no-KV-cache prefill); the mask helpers are imported from diffusers so the
semantics cannot drift. Unlike the eval-time coarse call, the student is queried at the SAME sigma
as the full model and regresses the full-grid velocity directly — it internalises both the
noise-alignment of ``CoarseView("aligned")`` and the nearest-neighbour lift.

Checkpointing: the trunk is deep-copied from the teacher at build time and frozen, so checkpoints
only store the heads (plus optional trunk-LoRA adapters) and a small meta dict; the trunk is
re-copied from whatever teacher is passed to ``from_checkpoint``.

``make_toy_transformer`` provides a tiny randomly-initialised stand-in with the same attribute
surface (used by the CPU test and by ``scripts/distill_draft.py --smoke``); it never loads real
weights.
"""
from __future__ import annotations

import copy
import math
import os
from types import SimpleNamespace

import torch
import torch.nn as nn
import torch.nn.functional as F

from .adapters.qwenimage21 import pack, pipeline_timestep

CKPT_FORMAT = "sarcache-draft-student/v1"

# Each vision-language image slot stands for 2x2 latent tokens (diffusers
# ``transformer_qwenimage21._IMG_TOKENS_PER_SLOT``); vendored here so the toy stand-in needs no
# diffusers import.
_IMG_TOKENS_PER_SLOT = 4


def _build_token_metadata(image_pad_mask: torch.Tensor,
                          img_shapes: list[tuple[int, int, int]]) -> tuple[torch.Tensor, torch.Tensor]:
    """Label every joint-sequence token with its image block id (-1 = text); target mask = last block.

    Vendored logic of ``QwenImage21Transformer2DModel.build_token_metadata`` (static method) so the
    trunk does not depend on the parent model object.
    """
    image_positions = image_pad_mask.nonzero(as_tuple=True)[0]
    block_lengths = [math.prod(shape) for shape in img_shapes]
    if sum(block_lengths) != image_positions.numel():
        raise ValueError(f"img_shapes accounts for {sum(block_lengths)} image tokens but image_pad_mask "
                         f"marks {image_positions.numel()}.")
    image_ids = torch.full_like(image_pad_mask, -1, dtype=torch.long)
    block_ids = torch.repeat_interleave(
        torch.arange(len(block_lengths), device=image_pad_mask.device),
        torch.tensor(block_lengths, device=image_pad_mask.device),
    )
    image_ids[image_positions] = block_ids
    target_token_mask = torch.zeros_like(image_pad_mask)
    target_token_mask[image_positions[-block_lengths[-1]:]] = True
    return image_ids, target_token_mask


def _is_flex_processor(processor) -> bool:
    """Duck-typed ``isinstance(p, QwenImage21FlexAttnProcessor)`` (avoids a hard diffusers import)."""
    return type(processor).__name__ == "QwenImage21FlexAttnProcessor"


class _QwenTrunk(nn.Module):
    """Frozen first-K teacher blocks plus the shared front, replicating the diffusers prefill body.

    Holds (deep) copies of the teacher's ``img_in`` / ``txt_in`` / ``time_text_embed`` /
    ``modulation`` / ``pos_embed`` and the first ``num_blocks`` transformer blocks.
    ``forward_taps`` runs the joint [text, image] sequence at the given latent grid and returns the
    target-token hidden state (``B, h*w, D``) after each requested depth.
    """

    #: text conditioning is a single embedding per token (``(B, L, D)``); Krea 2's trunk
    #: overrides this with a per-token stack of tapped text-encoder layers (``(B, L, n_layers, D)``).
    tapped_text = False

    def __init__(self, img_in: nn.Module, txt_in: nn.Module, time_text_embed: nn.Module,
                 modulation: nn.Module, pos_embed: nn.Module, blocks: list[nn.Module],
                 causal_condition: bool, in_channels: int, freeze: bool = True):
        super().__init__()
        self.img_in = img_in
        self.txt_in = txt_in
        self.time_text_embed = time_text_embed
        self.modulation = modulation
        self.pos_embed = pos_embed
        self.blocks = nn.ModuleList(blocks)
        self.causal_condition = bool(causal_condition)
        self.in_channels = int(in_channels)
        self.dim = int(self.img_in.out_features)
        if freeze:
            for p in self.parameters():
                p.requires_grad_(False)

    @classmethod
    def from_transformer(cls, tf, num_blocks: int) -> "_QwenTrunk":
        blocks = [copy.deepcopy(b) for b in tf.transformer_blocks[:num_blocks]]
        return cls(copy.deepcopy(tf.img_in), copy.deepcopy(tf.txt_in),
                   copy.deepcopy(tf.time_text_embed), copy.deepcopy(tf.modulation),
                   copy.deepcopy(tf.pos_embed), blocks,
                   bool(getattr(tf.config, "causal_condition", False)),
                   int(getattr(tf.config, "in_channels", 64)))

    # -- DraftStudent generic interface (model-kind agnostic)
    def pack_input(self, y: torch.Tensor) -> torch.Tensor:
        """Spatial latent (B, C, h, w) -> model input tokens; Qwen: one token per position."""
        return pack(y)

    def token_grid(self, h: int, w: int) -> tuple[int, int]:
        """Token-grid dims of a (h, w) latent grid (the head reshapes by this)."""
        return h, w

    def head_upscale(self, factor: int) -> int:
        """Token grid -> full latent grid ratio (Qwen: one token per latent position)."""
        return factor

    def forward_taps(self, hs: torch.Tensor, embeds: torch.Tensor, mask: torch.Tensor | None,
                     pad: torch.Tensor, h: int, w: int, sigma: float,
                     taps: tuple[int, ...]) -> dict[int, torch.Tensor]:
        """Joint prefill of the pooled grid; returns ``{depth: target hidden (B, h*w, D)}``.

        ``hs`` is the packed latent (``B, h*w, in_channels``) in the trunk dtype; ``embeds`` the text
        embeddings (``B, L, D_text``); ``mask`` the right-padding mask (``B, L``) or None when every
        text token is valid; ``pad`` the VLM image-slot mask (``B, L``, all-False for text-to-image).
        Mirrors the diffusers ``QwenImage21Transformer2DModel.forward`` prefill branch
        (kv_cache=None) up to the block loop, truncated after the deepest tap.
        """
        b = hs.shape[0]
        device = hs.device
        taps = tuple(sorted(taps))
        max_tap = taps[-1]
        if max_tap > len(self.blocks):
            raise ValueError(f"depth {max_tap} exceeds the trunk's {len(self.blocks)} blocks")

        hidden = self.img_in(hs)
        enc = self.txt_in(embeds)
        # One img_mask slot per 2x2 target tokens, exactly as the adapter builds it
        # (sarcache/adapters/qwenimage21.py:126).
        img_mask = torch.cat([pad, pad.new_ones(pad.shape[0], h * w // _IMG_TOKENS_PER_SLOT)], dim=1)
        repeats = torch.where(img_mask, _IMG_TOKENS_PER_SLOT, 1)[0]
        image_pad_mask = torch.repeat_interleave(img_mask[0], repeats)
        target_tokens = h * w
        joint = torch.cat([enc, enc.new_zeros(b, target_tokens // _IMG_TOKENS_PER_SLOT, enc.shape[2])],
                          dim=1)
        joint = joint.repeat_interleave(repeats, dim=1)
        joint[:, image_pad_mask] = hidden

        img_shapes = [(1, h, w)]
        rotary_emb = self.pos_embed(img_shapes, image_pad_mask, device)
        image_ids, target_token_mask = _build_token_metadata(image_pad_mask, img_shapes)

        timestep = pipeline_timestep(sigma, b, hidden.dtype, device)
        if self.causal_condition:
            timestep = torch.cat([timestep, timestep.new_zeros(1)], dim=0)
            modulation_mask: torch.Tensor | None = target_token_mask
        else:
            modulation_mask = None
        temb = self.time_text_embed(timestep, hidden)
        modulation = self.modulation(temb)

        # Right-padded prompt positions are excluded as keys (diffusers forward body, verbatim).
        joint_key_valid = None
        if mask is not None:
            joint_key_valid = torch.ones(b, image_pad_mask.shape[0], dtype=torch.bool, device=device)
            text_positions = (~image_pad_mask).nonzero(as_tuple=True)[0]
            vlm_text_positions = ~img_mask[0][: mask.shape[1]]
            joint_key_valid[:, text_positions] = mask.bool()[:, vlm_text_positions]

        prefix_len = int((~target_token_mask).sum())
        processors = [blk.attn.processor for blk in self.blocks]
        needs_block_mask = any(_is_flex_processor(p) for p in processors)
        attention_mask = None
        if needs_block_mask:
            from diffusers.models.transformers.transformer_qwenimage21 import (
                build_qwenimage21_block_causal_mask,
            )
            attention_mask = build_qwenimage21_block_causal_mask(image_ids, joint_key_valid, b, device)
        if all(_is_flex_processor(p) for p in processors):
            segments = None
        else:
            from diffusers.models.transformers.transformer_qwenimage21 import (
                _qwenimage21_prefix_segments,
            )
            segments = _qwenimage21_prefix_segments(image_ids, prefix_len)

        out: dict[int, torch.Tensor] = {}
        for index, block in enumerate(self.blocks):
            joint = block(
                hidden_states=joint,
                modulation=modulation,
                rotary_emb=rotary_emb,
                attention_mask=attention_mask,
                target_token_mask=modulation_mask,
                layer_cache=None,
                kv_cache_mode=None,
                cache_write_slice=None,
                segments=segments,
                key_valid=joint_key_valid,
            )
            depth = index + 1
            if depth in taps:
                out[depth] = joint[:, -target_tokens:]
            if depth >= max_tap:
                break
        return out


class _KreaTrunk(nn.Module):
    """Frozen first-K Krea-2 teacher blocks plus the shared front (krea2 counterpart of _QwenTrunk).

    Krea 2 differs from Qwen-Image-2.1 in the input contract: the latent is patchified 2x2 before
    ``img_in`` (one token per 2x2 latent cells, ``Krea2Pipeline._pack_latents``), text enters as a
    STACK of tapped text-encoder layers fused per token (``text_fusion`` -> ``txt_in``) and crosses
    into every block via self-attention on the joint sequence (no separate cross-attention and no
    text-prefix KV cache in the plain path). ``forward_taps`` replicates the diffusers
    ``Krea2Transformer2DModel.forward`` body up to the block loop, truncated after the deepest tap:
    same ``krea_timestep`` arithmetic order, same text key-padding mask, same RoPE ids built on the
    POOLED grid with native (integer) positions — the student is queried at the same sigma as the
    full model and regresses the full-grid velocity directly.
    """

    tapped_text = True

    def __init__(self, img_in: nn.Module, txt_in: nn.Module, time_embed: nn.Module,
                 time_mod_proj: nn.Module, text_fusion: nn.Module, rotary_emb: nn.Module,
                 blocks: list[nn.Module], latent_channels: int, freeze: bool = True):
        super().__init__()
        self.img_in = img_in
        self.txt_in = txt_in
        self.time_embed = time_embed
        self.time_mod_proj = time_mod_proj
        self.text_fusion = text_fusion
        self.rotary_emb = rotary_emb
        self.blocks = nn.ModuleList(blocks)
        self.causal_condition = False
        self.in_channels = int(latent_channels)
        self.dim = int(self.img_in.out_features)
        if freeze:
            for p in self.parameters():
                p.requires_grad_(False)

    @classmethod
    def from_transformer(cls, tf, num_blocks: int, shared: bool = False) -> "_KreaTrunk":
        take = lambda m: m if shared else copy.deepcopy(m)
        return cls(take(tf.img_in), take(tf.txt_in), take(tf.time_embed), take(tf.time_mod_proj),
                   take(tf.text_fusion), take(tf.rotary_emb),
                   [take(b) for b in tf.transformer_blocks[:num_blocks]],
                   int(getattr(tf.config, "in_channels", 64)) // 4, freeze=True)

    # -- DraftStudent generic interface (see _QwenTrunk)
    def pack_input(self, y: torch.Tensor) -> torch.Tensor:
        from .adapters.krea2 import pack as krea_pack
        return krea_pack(y)

    def token_grid(self, h: int, w: int) -> tuple[int, int]:
        if h % 2 or w % 2:
            raise ValueError(f"Krea 2 patchifies 2x2; grid {h}x{w} must be even")
        return h // 2, w // 2

    def head_upscale(self, factor: int) -> int:
        """Token grid -> full latent grid ratio = pool factor x patch size (2)."""
        return factor * 2

    def forward_taps(self, hs: torch.Tensor, embeds: torch.Tensor, mask: torch.Tensor | None,
                     pad: torch.Tensor, h: int, w: int, sigma: float,
                     taps: tuple[int, ...]) -> dict[int, torch.Tensor]:
        """Joint prefill of the pooled grid; returns ``{depth: image-token hidden}``.

        ``hs`` is the PACKED latent (``B, (h/2)(w/2), C*4``) in the trunk dtype; ``embeds`` the
        stacked text hidden states (``B, L, n_layers, D_text``); ``mask`` the valid-token mask
        (``B, L``) or None when every text token is valid; ``pad`` is unused (Krea has no VLM
        image slots). Mirrors the diffusers forward body up to the block loop.
        """
        from .adapters.krea2 import krea_timestep, position_ids

        taps = tuple(sorted(taps))
        max_tap = taps[-1]
        if max_tap > len(self.blocks):
            raise ValueError(f"depth {max_tap} exceeds the trunk's {len(self.blocks)} blocks")
        b = hs.shape[0]
        device = hs.device
        dtype = self.img_in.weight.dtype
        text_len = embeds.shape[1]
        th, tw = self.token_grid(h, w)

        text_mask = None
        if mask is not None:
            text_mask = mask[:, None, None, :]          # key-padding mask, True = valid
        text = self.text_fusion(embeds, attention_mask=text_mask)
        text = self.txt_in(text)
        hidden = self.img_in(hs)
        joint = torch.cat([text, hidden], dim=1)

        timestep = krea_timestep(sigma, b, dtype, device)
        temb = self.time_embed(timestep, dtype=dtype)
        temb_mod = self.time_mod_proj(F.gelu(temb, approximate="tanh"))
        pos_ids = position_ids(text_len, th, tw, device=device, dtype=torch.float32)
        rope = self.rotary_emb(pos_ids)
        attention_mask = None
        if mask is not None:
            img_ones = mask.new_ones(b, th * tw)
            attention_mask = torch.cat([mask, img_ones], dim=1)[:, None, None, :]

        out: dict[int, torch.Tensor] = {}
        for index, block in enumerate(self.blocks):
            joint = block(joint, temb_mod, rope, attention_mask)
            depth = index + 1
            if depth in taps:
                out[depth] = joint[:, text_len:]
            if depth >= max_tap:
                break
        return out


class _DraftHead(nn.Module):
    """Conv decoder from a block-K hidden state (``B, h*w, D``) to the full-grid velocity.

    LayerNorm (trainable affine) over the channel dim, then a 1x1 contraction and
    ``log2(factor)`` PixelShuffle(2) stages with 3x3 convs between. Output is FP32.
    """

    def __init__(self, dim: int, channels: int, factor: int, width: int = 64):
        super().__init__()
        if factor < 1 or factor & (factor - 1):
            raise ValueError(f"factor must be a power of two, got {factor}")
        self.factor = int(factor)
        if factor == 1:
            stages: list[nn.Module] = [nn.LayerNorm(dim), nn.Conv2d(dim, width, 1), nn.SiLU()]
        else:
            stages = [nn.LayerNorm(dim), nn.Conv2d(dim, width * 4, 1), nn.SiLU(), nn.PixelShuffle(2)]
            for _ in range(int(math.log2(factor)) - 1):
                stages += [nn.Conv2d(width, width * 4, 3, padding=1), nn.SiLU(), nn.PixelShuffle(2)]
        stages += [nn.Conv2d(width, channels, 3, padding=1)]
        self.net = nn.Sequential(*stages)

    def forward(self, tokens: torch.Tensor, h: int, w: int) -> torch.Tensor:
        b, l, d = tokens.shape
        if l != h * w:
            raise ValueError(f"head got {l} tokens for a {h}x{w} grid")
        # fp32 head regardless of trunk dtype: bf16 activations in, fp32 conv stack out (the trunk
        # runs bf16 on the real teacher; casting here keeps the contract dtype-robust).
        x = self.net[0](tokens.float()).transpose(1, 2).reshape(b, d, h, w)
        return self.net[1:](x).float()


def _as_transformer(teacher):
    """Accept the pipeline VelocityModel wrapper (an adapter with ``.transformer``) or the raw
    diffusers transformer."""
    inner = getattr(teacher, "transformer", None)
    if inner is not None and hasattr(inner, "transformer_blocks"):
        return inner
    if hasattr(teacher, "transformer_blocks"):
        return teacher
    raise TypeError("teacher must be a QwenImage21Adapter-like wrapper (with .transformer) or a "
                    "diffusers QwenImage21Transformer2DModel-like module (with .transformer_blocks)")


def _build_trunk(tf, num_blocks: int, shared: bool = False):
    """Frozen first-K trunk for the transformer at hand (Qwen-Image-2.1 or Krea 2).

    Model kinds are duck-typed on the Krea-specific ``text_fusion`` front (present on the real
    ``Krea2Transformer2DModel`` and the toy stand-in alike). ``shared=True`` references the
    teacher's own modules (no deepcopy) — only valid when the trunk cannot be mutated (no LoRA;
    the sampler runs under no_grad).
    """
    if hasattr(tf, "text_fusion"):
        return _KreaTrunk.from_transformer(tf, num_blocks, shared=shared)
    if shared:
        return _QwenTrunk(tf.img_in, tf.txt_in, tf.time_text_embed, tf.modulation,
                          tf.pos_embed, list(tf.transformer_blocks[:num_blocks]),
                          bool(getattr(tf.config, "causal_condition", False)),
                          int(getattr(tf.config, "in_channels", 64)), freeze=True)
    return _QwenTrunk.from_transformer(tf, num_blocks)


def build_student(teacher, depths: tuple[int, ...] = (8, 12, 16), factor: int = 4) -> "DraftStudent":
    """Constructor used by both training and ``from_checkpoint`` (see class docstring)."""
    tf = _as_transformer(teacher)
    depths = tuple(int(d) for d in depths)
    if not depths:
        raise ValueError("depths must be a non-empty tuple")
    return DraftStudent(_build_trunk(tf, max(depths)), depths=depths, factor=factor)


class DraftStudent(nn.Module):
    """Frozen first-K teacher trunk at the f4 grid + one trainable conv head per depth.

    Public contract (frozen — the sampler-side integration codes against this):
      * ``factor``, ``depths`` — pooling factor and the supervised depth tuple;
      * ``set_conditioning(text_embeds, mask=None, pad=None)`` — cache the text embeddings
        (``(L, D)`` or ``(1, L, D)``) from the adapter; ``mask`` (right-padding, ``(L,)``/``(1, L)``)
        and ``pad`` (VLM image slots) are optional, defaulting to all-valid / none;
      * ``set_depth(k)`` — select the active head; ``k`` must be in ``self.depths``;
      * ``forward(x_full, sigma)`` — ``(B, 64, H, W)`` full-grid latent -> ``(B, 64, H, W)`` FP32
        velocity estimate. Internally pools by ``factor``, runs the trunk at the ``H/factor`` grid
        with the native RoPE grid, decodes with the active depth's head. Cheap under ``no_grad()``.
      * ``save_checkpoint(path, meta)`` / ``DraftStudent.from_checkpoint(path, teacher)``.

    Training-only helpers (not part of the frozen surface): ``forward_pooled`` (pooled input),
    ``forward_all`` / ``forward_all_pooled`` (every depth's prediction in one trunk pass).
    """

    def __init__(self, trunk: _QwenTrunk, depths: tuple[int, ...] = (8, 12, 16), factor: int = 4,
                 channels: int | None = None):
        super().__init__()
        depths = tuple(int(d) for d in depths)
        if not depths or any(d < 1 or d > len(trunk.blocks) for d in depths):
            raise ValueError(f"depths {depths} must be positive and <= the trunk's "
                             f"{len(trunk.blocks)} blocks")
        self.factor = int(factor)
        self.depths = depths
        self.trunk = trunk
        channels = int(channels or trunk.in_channels)
        self.heads = nn.ModuleDict({str(d): _DraftHead(trunk.dim, channels,
                                                       trunk.head_upscale(self.factor))
                                    for d in depths})
        self._cond: torch.Tensor | None = None
        self._mask: torch.Tensor | None = None
        self._pad: torch.Tensor | None = None
        self._active_depth = depths[-1]

    # ------------------------------------------------------------------ conditioning / depth
    @staticmethod
    def _prepare_mask(m: torch.Tensor | None, shape: tuple[int, int]) -> torch.Tensor | None:
        if m is None:
            return None
        if m.dim() == 1:
            m = m.unsqueeze(0)
        if tuple(m.shape) != shape:
            raise ValueError(f"mask {tuple(m.shape)} != embeds {shape}")
        return m

    def set_conditioning(self, text_embeds: torch.Tensor, mask: torch.Tensor | None = None,
                         pad: torch.Tensor | None = None) -> None:
        """Cache text embeddings plus optional valid-token / image-slot masks.

        ``text_embeds`` is ``(L, D)`` (Qwen) or ``(L, n_layers, D)`` (Krea 2's tapped text stack),
        optionally with a leading batch-1 dim. ``mask`` marks valid text tokens (all-True is
        normalised to None); ``pad`` (VLM image slots) is Qwen-only and ignored by the Krea trunk.
        """
        if text_embeds.dim() == 2:
            text_embeds = text_embeds.unsqueeze(0)
        elif text_embeds.dim() == 3 and self.trunk.tapped_text:
            text_embeds = text_embeds.unsqueeze(0)  # (L, n_layers, D) -> (1, L, n_layers, D)
        if text_embeds.dim() not in (3, 4) or text_embeds.shape[0] != 1:
            raise ValueError(f"text_embeds must be (L, D)/(L, n_layers, D) with optional leading "
                             f"batch-1 dim, got {tuple(text_embeds.shape)}")
        self._cond = text_embeds
        # mirror adapter._condition: an all-valid mask is stored as None
        mask = self._prepare_mask(mask, text_embeds.shape[:2])
        self._mask = None if mask is None or bool(mask.all()) else mask
        pad = self._prepare_mask(pad, text_embeds.shape[:2])
        self._pad = pad if pad is not None else torch.zeros(
            text_embeds.shape[:2], dtype=torch.bool, device=text_embeds.device)

    def set_depth(self, k: int) -> None:
        """Select which head ``forward`` uses; ``k`` must be in ``self.depths``."""
        if k not in self.depths:
            raise ValueError(f"depth {k} not in student depths {self.depths}")
        self._active_depth = int(k)

    @property
    def active_depth(self) -> int:
        return self._active_depth

    # ------------------------------------------------------------------ forward
    def _pooled_grid(self, x_full: torch.Tensor) -> torch.Tensor:
        h, w = x_full.shape[-2:]
        if h % self.factor or w % self.factor:
            raise ValueError(f"latent grid {h}x{w} is not divisible by factor {self.factor}")
        return F.avg_pool2d(x_full, kernel_size=self.factor, stride=self.factor)

    def _check_cond(self, like: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor | None, torch.Tensor]:
        if self._cond is None:
            raise RuntimeError("set_conditioning() must be called before forward()")
        if self._cond.device != like.device:
            raise RuntimeError(f"conditioning lives on {self._cond.device} but the latent is on "
                               f"{like.device}; re-run set_conditioning on the latent device")
        pad = self._pad if self._pad.device == like.device else self._pad.to(like.device)
        return self._cond, self._mask, pad

    def forward_pooled(self, y: torch.Tensor, sigma: float) -> torch.Tensor:
        """Pooled-latent variant of the contract forward: ``(B, C, h, w)`` -> full-grid velocity."""
        b, c, h, w = y.shape
        dtype = self.trunk.img_in.weight.dtype
        cond, mask, pad = self._check_cond(y)
        hs = self.trunk.pack_input(y.to(dtype))
        taps = self.trunk.forward_taps(hs, cond, mask, pad, h, w, sigma, (self._active_depth,))
        return self.heads[str(self._active_depth)](taps[self._active_depth],
                                                   *self.trunk.token_grid(h, w))

    def forward(self, x_full: torch.Tensor, sigma: float) -> torch.Tensor:
        """Contract forward: full-grid latent (B, 64, H, W) -> FP32 velocity on the same grid."""
        return self.forward_pooled(self._pooled_grid(x_full), sigma)

    def forward_all_pooled(self, y: torch.Tensor, sigma: float) -> dict[int, torch.Tensor]:
        """Every depth's prediction from a single trunk pass (training supervision)."""
        b, c, h, w = y.shape
        dtype = self.trunk.img_in.weight.dtype
        cond, mask, pad = self._check_cond(y)
        hs = self.trunk.pack_input(y.to(dtype))
        taps = self.trunk.forward_taps(hs, cond, mask, pad, h, w, sigma, self.depths)
        grid = self.trunk.token_grid(h, w)
        return {d: self.heads[str(d)](taps[d], *grid) for d in self.depths}

    def forward_all(self, x_full: torch.Tensor, sigma: float) -> dict[int, torch.Tensor]:
        return self.forward_all_pooled(self._pooled_grid(x_full), sigma)

    # ------------------------------------------------------------------ checkpointing
    def _trainable_state_dict(self) -> dict[str, torch.Tensor]:
        """Trainable params only: the heads (+ trunk-LoRA matrices when applied). The frozen trunk
        base is never stored — it is re-copied from the teacher in ``from_checkpoint``."""
        return {k: v for k, v in self.state_dict().items()
                if k.startswith("heads.") or ".lora_a." in k or ".lora_b." in k}

    def save_checkpoint(self, path: str, meta: dict, extras: dict | None = None) -> None:
        """Save heads (+ optional LoRA adapters) + meta (atomic: tmp file then rename). The trunk
        is NOT stored — it is re-copied from the teacher in ``from_checkpoint``. ``extras`` (e.g.
        optimizer state) rides along under the ``"extras"`` key for the trainer's --resume;
        ``from_checkpoint`` ignores it."""
        merged = dict(meta)
        merged.update({"depths": list(self.depths), "factor": self.factor,
                       "hidden_dim": self.trunk.dim, "in_channels": self.trunk.in_channels,
                       "causal_condition": self.trunk.causal_condition, "format": CKPT_FORMAT})
        ckpt = {"format": CKPT_FORMAT, "meta": merged, "state_dict": self._trainable_state_dict()}
        if extras:
            ckpt["extras"] = extras
        tmp = f"{path}.tmp{os.getpid()}"
        torch.save(ckpt, tmp)
        os.replace(tmp, path)

    @classmethod
    def from_checkpoint(cls, path: str, teacher, shared: bool = False) -> "DraftStudent":
        """Rebuild from ``save_checkpoint``; trunk weights are COPIED from the given teacher (the
        pipeline VelocityModel wrapper or its inner diffusers transformer — both accepted).

        ``shared=True`` builds the trunk as a frozen VIEW over the teacher's own modules (no
        deepcopy) — the eval-time choice: zero extra memory, and the sampler runs under no_grad so
        the shared weights cannot be mutated. ``shared=False`` (default, training-side) deep-copies.
        """
        ckpt = torch.load(path, map_location="cpu", weights_only=False)
        if ckpt.get("format") != CKPT_FORMAT:
            raise ValueError(f"{path} is not a {CKPT_FORMAT} checkpoint")
        meta = ckpt["meta"]
        depths = tuple(meta["depths"])
        sd = ckpt["state_dict"]
        lora_key = next((k for k in sd if k.endswith(".lora_a.weight")), None)
        lora_rank = int(sd[lora_key].shape[0]) if lora_key is not None else 0
        # LoRA mutates the trunk modules in place, so a shared view would corrupt the teacher —
        # the LoRA student ALWAYS gets its own deep-copied trunk (train and eval alike).
        if shared and not lora_rank:
            trunk = _build_trunk(_as_transformer(teacher), max(depths), shared=True)
            student = cls(trunk, depths=depths, factor=int(meta["factor"]))
        else:
            student = build_student(teacher, depths=depths, factor=int(meta["factor"]))
        if lora_rank:
            apply_trunk_lora(student, lora_rank)
        full = student.state_dict()
        unexpected = sorted(k for k in sd if k not in full)
        if unexpected:
            raise ValueError(f"checkpoint has keys outside the student: {unexpected}")
        # strict=False: the frozen-trunk keys are intentionally absent from the checkpoint.
        student.load_state_dict(sd, strict=False)
        return student


# -------------------------------------------------------------------------------------- trunk LoRA
class LoRALinear(nn.Module):
    """LoRA wrapper around a frozen ``nn.Linear``: ``base(x) + (alpha / r) * b(a(x))``."""

    def __init__(self, base: nn.Linear, rank: int, alpha: float = 1.0):
        super().__init__()
        self.base = base
        for p in self.base.parameters():
            p.requires_grad_(False)
        # lora branches live on the base's device/dtype (they add into the base output)
        self.lora_a = nn.Linear(base.in_features, rank, bias=False,
                                device=base.weight.device, dtype=base.weight.dtype)
        self.lora_b = nn.Linear(rank, base.out_features, bias=False,
                                device=base.weight.device, dtype=base.weight.dtype)
        nn.init.kaiming_uniform_(self.lora_a.weight, a=math.sqrt(5))
        nn.init.zeros_(self.lora_b.weight)
        self.scale = alpha / rank

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.base(x) + self.scale * self.lora_b(self.lora_a(x))


def _loraize(module: nn.Module, rank: int, alpha: float) -> None:
    """Replace every ``nn.Linear`` under ``module`` (in place) with a ``LoRALinear``."""
    if not isinstance(module, nn.Module):
        return                                    # toy stand-ins expose non-module placeholders
    for name, child in list(module.named_children()):
        if isinstance(child, LoRALinear):
            continue
        if isinstance(child, nn.Linear):
            setattr(module, name, LoRALinear(child, rank, alpha))
        else:
            _loraize(child, rank, alpha)


def apply_trunk_lora(student: DraftStudent, rank: int, alpha: float = 1.0) -> None:
    """Wrap the frozen trunk's attention/MLP projections with trainable LoRA adapters (default OFF).

    Must be called right after ``build_student`` (before optimizer construction and DDP wrapping).
    """
    if rank < 1:
        raise ValueError("lora rank must be >= 1")
    for block in student.trunk.blocks:
        for attr in ("attn", "img_mlp", "ff"):   # qwen blocks: attn/img_mlp; krea blocks: attn/ff
            mod = getattr(block, attr, None)
            if mod is not None:
                _loraize(mod, rank, alpha)


def trainable_parameters(student: DraftStudent) -> list[nn.Parameter]:
    """Heads (+ trunk-LoRA when applied); the frozen trunk contributes nothing."""
    return [p for p in student.parameters() if p.requires_grad]


# -------------------------------------------------------------------------------------- toy stand-in
class _ToyBlock(nn.Module):
    """Random-init block speaking the diffusers ``QwenImage21TransformerBlock`` call signature.

    Per-token MLP with the real modulation-row selection (text rows read the t=0 row under
    ``causal_condition``); ``rotary_emb`` / ``attention_mask`` / cache kwargs are accepted and
    ignored, so the block is a pure token mixer like the real single-stream block.
    """

    def __init__(self, dim: int, mlp_ratio: int = 3):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim, elementwise_affine=False)
        self.norm2 = nn.LayerNorm(dim, elementwise_affine=False)
        self.fc1 = nn.Linear(dim, dim * mlp_ratio)
        self.fc2 = nn.Linear(dim * mlp_ratio, dim)
        self.fc3 = nn.Linear(dim, dim * mlp_ratio)
        self.fc4 = nn.Linear(dim * mlp_ratio, dim)
        self.act = nn.SiLU()
        self.attn = SimpleNamespace(processor=object())  # not a flex processor, like the real default

    @staticmethod
    def _rows(params: torch.Tensor, target_token_mask: torch.Tensor | None) -> torch.Tensor:
        if target_token_mask is None:
            return params.unsqueeze(1)
        real, zero = params[:-1].unsqueeze(1), params[-1:].unsqueeze(0)
        return torch.where(target_token_mask.view(1, -1, 1), real, zero)

    def forward(self, hidden_states: torch.Tensor, modulation: torch.Tensor,
                rotary_emb: torch.Tensor | None = None, attention_mask=None,
                target_token_mask: torch.Tensor | None = None, **kwargs) -> torch.Tensor:
        mod1, mod2 = modulation.chunk(2, dim=-1)
        scale1, gate1 = mod1.chunk(2, dim=-1)
        x = self.norm1(hidden_states) * (1 + self._rows(scale1, target_token_mask))
        h = hidden_states + self._rows(gate1, target_token_mask).tanh() * self.fc2(self.act(self.fc1(x)))
        scale2, gate2 = mod2.chunk(2, dim=-1)
        x = self.norm2(h) * (1 + self._rows(scale2, target_token_mask))
        return h + self._rows(gate2, target_token_mask).tanh() * self.fc4(self.act(self.fc3(x)))


class _ToyTimeEmbed(nn.Module):
    """``forward(timestep, hidden_states) -> (len(timestep), dim)``, like QwenImage21TimestepProjEmbeddings."""

    def __init__(self, dim: int):
        super().__init__()
        self.freqs = nn.Parameter(torch.randn(16) * 0.1, requires_grad=False)
        self.proj = nn.Sequential(nn.Linear(32, dim), nn.SiLU(), nn.Linear(dim, dim))

    def forward(self, timestep: torch.Tensor, hidden_states: torch.Tensor) -> torch.Tensor:
        ang = timestep.float()[:, None] * self.freqs[None] * 1000.0
        emb = torch.cat([torch.cos(ang), torch.sin(ang)], dim=-1)
        return self.proj(emb.to(hidden_states.dtype))


class _ToyRope(nn.Module):
    """Returns a deterministic real tensor of rotary shape; the toy blocks ignore its values."""

    def __init__(self, dim: int = 8):
        super().__init__()
        self.dim = dim

    def forward(self, img_shapes, image_pad_mask: torch.Tensor, device) -> torch.Tensor:
        n = image_pad_mask.shape[-1]
        pos = torch.arange(n, dtype=torch.float32, device=device)
        out = torch.stack([pos, pos * 0.5], dim=-1)
        return out.repeat_interleave(self.dim // 2, dim=-1)


class ToyTransformer(nn.Module):
    """Tiny randomly-initialised stand-in with the teacher's attribute surface (CPU tests / smoke).

    ``forward`` mirrors the joint prefill (via a shared ``_QwenTrunk`` view over its own modules)
    and finishes with ``norm_out`` + ``proj_out``, returning ``(target_velocity,)`` in packed
    ``(B, h*w, 64)`` form like the diffusers transformer.
    """

    def __init__(self, num_layers: int = 8, dim: int = 64, in_channels: int = 64,
                 context_dim: int = 48, mlp_ratio: int = 3):
        super().__init__()
        self.config = SimpleNamespace(causal_condition=True, in_channels=in_channels,
                                      out_channels=in_channels)
        self.img_in = nn.Linear(in_channels, dim, bias=False)
        self.txt_in = nn.Linear(context_dim, dim, bias=False)
        self.time_text_embed = _ToyTimeEmbed(dim)
        self.modulation = nn.Sequential(nn.SiLU(), nn.Linear(dim, 4 * dim, bias=False))
        self.pos_embed = _ToyRope()
        self.transformer_blocks = nn.ModuleList([_ToyBlock(dim, mlp_ratio)
                                                 for _ in range(num_layers)])
        self.norm_out = nn.LayerNorm(dim, elementwise_affine=False)
        self.proj_out = nn.Linear(dim, in_channels, bias=False)

    def _trunk_view(self) -> _QwenTrunk:
        """Unfrozen ``_QwenTrunk`` over this object's own modules (no copying; teacher-side use)."""
        return _QwenTrunk(self.img_in, self.txt_in, self.time_text_embed, self.modulation,
                          self.pos_embed, list(self.transformer_blocks),
                          self.config.causal_condition, self.config.in_channels, freeze=False)

    def forward(self, hidden_states: torch.Tensor, encoder_hidden_states: torch.Tensor,
                timestep: torch.Tensor, img_shapes, img_mask: torch.Tensor,
                encoder_hidden_states_mask: torch.Tensor | None = None,
                **kwargs) -> tuple[torch.Tensor, ...]:
        b = hidden_states.shape[0]
        h, w = img_shapes[0][0][1], img_shapes[0][0][2]
        mask = encoder_hidden_states_mask
        if mask is not None and bool(mask.all()):
            mask = None
        pad = torch.zeros(b, encoder_hidden_states.shape[1], dtype=torch.bool,
                          device=encoder_hidden_states.device)
        sigma = float(timestep.reshape(-1)[0])
        hs = hidden_states.to(self.img_in.weight.dtype)
        taps = self._trunk_view().forward_taps(hs, encoder_hidden_states, mask, pad, h, w, sigma,
                                               (len(self.transformer_blocks),))
        joint = taps[len(self.transformer_blocks)]
        return (self.proj_out(self.norm_out(joint)),)


def make_toy_transformer(**kwargs) -> ToyTransformer:
    """Random-init toy teacher (see ``ToyTransformer``); never loads real weights."""
    return ToyTransformer(**kwargs)


class _ToyKreaBlock(nn.Module):
    """Block speaking the diffusers ``Krea2TransformerBlock`` signature
    ``(hidden_states, temb, image_rotary_emb, attention_mask)``; a per-token MLP (the real block is
    a joint self-attention over [text, image] — the toy is a pure token mixer, like _ToyBlock)."""

    def __init__(self, dim: int, mlp_ratio: int = 3):
        super().__init__()
        self.attn = SimpleNamespace(processor=object())      # LoRA duck (not a Module: skipped)
        self.ff = nn.Sequential(nn.Linear(dim, dim * mlp_ratio), nn.SiLU(),
                                nn.Linear(dim * mlp_ratio, dim))

    def forward(self, hidden_states: torch.Tensor, temb: torch.Tensor,
                image_rotary_emb, attention_mask=None) -> torch.Tensor:
        return hidden_states + self.ff(hidden_states)


class _ToyKreaFusion(nn.Module):
    """``(B, L, n_layers, D) -> (B, L, D)`` like Krea2TextFusion's per-token layer mixing."""

    def forward(self, hidden_states: torch.Tensor, attention_mask=None) -> torch.Tensor:
        return hidden_states.mean(dim=2)


class _ToyKreaTimeEmbed(nn.Module):
    """``forward(timestep, dtype) -> (B, dim)`` like Krea2TimestepEmbedding."""

    def __init__(self, dim: int):
        super().__init__()
        self.fc = nn.Sequential(nn.Linear(1, dim), nn.SiLU(), nn.Linear(dim, dim))

    def forward(self, timestep: torch.Tensor, dtype: torch.dtype) -> torch.Tensor:
        return self.fc(timestep[:, None].to(torch.float32))


class _ToyKreaRope(nn.Module):
    """Parameter-free RoPE stand-in; the toy blocks ignore its return value."""

    def forward(self, ids: torch.Tensor):
        return None


class ToyKreaTransformer(nn.Module):
    """Tiny randomly-initialised Krea-2-structured stand-in (CPU tests / teacher copy source).

    Attribute surface mirrors the diffusers ``Krea2Transformer2DModel``: ``img_in`` on 2x2-packed
    latents, ``text_fusion`` + ``txt_in`` for the tapped text stack, ``time_embed`` /
    ``time_mod_proj``, parameter-free ``rotary_emb``, and ``transformer_blocks``. ``config.
    in_channels`` is the PACKED width (latent channels x 4), matching the real config.
    """

    def __init__(self, num_layers: int = 8, dim: int = 64, in_channels: int = 16,
                 text_layers: int = 2, text_dim: int = 24):
        super().__init__()
        self.config = SimpleNamespace(in_channels=in_channels * 4)
        self.img_in = nn.Linear(in_channels * 4, dim, bias=False)
        self.txt_in = nn.Linear(text_dim, dim, bias=False)
        self.time_embed = _ToyKreaTimeEmbed(dim)
        self.time_mod_proj = nn.Linear(dim, dim * 6, bias=False)
        self.text_fusion = _ToyKreaFusion()
        self.rotary_emb = _ToyKreaRope()
        self.transformer_blocks = nn.ModuleList([_ToyKreaBlock(dim)
                                                 for _ in range(num_layers)])
        self.final_layer = nn.Linear(dim, in_channels * 4, bias=False)

    def forward(self, hidden_states: torch.Tensor, encoder_hidden_states: torch.Tensor,
                timestep: torch.Tensor, position_ids: torch.Tensor,
                encoder_attention_mask: torch.Tensor | None = None,
                return_dict: bool = True, **kwargs) -> tuple[torch.Tensor, ...]:
        """Toy teacher velocity on packed tokens; square grids only (h = w = 2*sqrt(L))."""
        import math as _math
        b, l, _ = hidden_states.shape
        side = int(2 * _math.sqrt(l))
        mask = encoder_attention_mask
        if mask is not None and bool(mask.all()):
            mask = None
        sigma = float(timestep.reshape(-1)[0])
        n = len(self.transformer_blocks)
        taps = _KreaTrunk(self.img_in, self.txt_in, self.time_embed, self.time_mod_proj,
                          self.text_fusion, self.rotary_emb, list(self.transformer_blocks),
                          self.config.in_channels // 4, freeze=False
                          ).forward_taps(hidden_states, encoder_hidden_states, mask, None,
                                         side, side, sigma, (n,))
        text_len = encoder_hidden_states.shape[1]
        joint = taps[n]
        # rebuild the joint sequence text-prefix for the slice bookkeeping is unnecessary: the toy
        # final layer maps image-token hiddens straight to packed velocity.
        return (self.final_layer(joint),)


def make_toy_krea_transformer(**kwargs) -> ToyKreaTransformer:
    """Random-init Krea-2-structured toy teacher; never loads real weights."""
    return ToyKreaTransformer(**kwargs)
