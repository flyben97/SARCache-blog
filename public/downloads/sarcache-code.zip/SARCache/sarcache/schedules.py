"""Sigma grids and refresh schedules.

A refresh schedule is a sorted list of step indices at which the full-resolution model runs. Step 0 is always a
refresh (proposal Sec. 5.1). ``dp_refresh`` chooses the set that minimises a calibrated cost matrix, which is the
concrete "selected on the calibration set and frozen" rule the proposal leaves open.
"""
from __future__ import annotations

import math
from typing import Sequence

import numpy as np
import torch


def base_sigmas(num_steps: int) -> np.ndarray:
    return np.linspace(1.0, 1.0 / num_steps, num_steps)


def shifted_sigmas(num_steps: int, shift: float = 1.0) -> torch.Tensor:
    """Static shift ``shift * s / (1 + (shift - 1) s)`` (SD3 / Sana style), terminal zero appended."""
    s = base_sigmas(num_steps)
    s = shift * s / (1.0 + (shift - 1.0) * s)
    return torch.tensor(np.append(s, 0.0), dtype=torch.float64)


def dynamic_sigmas(num_steps: int, mu: float) -> torch.Tensor:
    """Exponential time shift used by FLUX / Qwen-Image pipelines, terminal zero appended."""
    s = base_sigmas(num_steps)
    s = math.exp(mu) / (math.exp(mu) + (1.0 / s - 1.0))
    return torch.tensor(np.append(s, 0.0), dtype=torch.float64)


def calculate_shift(image_seq_len: int, base_seq_len: int = 256, max_seq_len: int = 4096,
                    base_shift: float = 0.5, max_shift: float = 1.15) -> float:
    m = (max_shift - base_shift) / (max_seq_len - base_seq_len)
    return image_seq_len * m + base_shift - m * base_seq_len


def scheduler_sigmas(scheduler, num_steps: int, image_seq_len: int | None = None) -> torch.Tensor:
    """Sigma grid exactly as the official diffusers pipelines build it (dynamic shift when configured)."""
    kwargs = {}
    if getattr(scheduler.config, "use_dynamic_shifting", False):
        if image_seq_len is None:
            raise ValueError("image_seq_len is required for a dynamically shifted scheduler")
        kwargs["mu"] = calculate_shift(
            image_seq_len,
            scheduler.config.get("base_image_seq_len", 256),
            scheduler.config.get("max_image_seq_len", 4096),
            scheduler.config.get("base_shift", 0.5),
            scheduler.config.get("max_shift", 1.15),
        )
    scheduler.set_timesteps(sigmas=base_sigmas(num_steps), device="cpu", **kwargs)
    return scheduler.sigmas.detach().to(torch.float64).cpu().clone()


def validate_refresh(refresh: Sequence[int], num_steps: int) -> list[int]:
    steps = sorted(set(int(i) for i in refresh))
    if not steps or steps[0] != 0:
        raise ValueError("the first sampling step must be a refresh")
    if steps[-1] >= num_steps:
        raise ValueError(f"refresh index {steps[-1]} outside [0, {num_steps})")
    return steps


def uniform_refresh(num_steps: int, num_full: int) -> list[int]:
    """``num_full`` refreshes spread evenly over ``num_steps``, starting at step 0."""
    if not 1 <= num_full <= num_steps:
        raise ValueError("need 1 <= num_full <= num_steps")
    idx = np.floor(np.arange(num_full) * num_steps / num_full + 1e-9).astype(int)
    return validate_refresh(idx.tolist(), num_steps)


def schedule_cost(cost: np.ndarray, refresh: Sequence[int]) -> float:
    """``sum_t cost[last_refresh(t), t]`` for a refresh set; ``cost[t, t]`` is ignored (exact step)."""
    n = cost.shape[0]
    steps = validate_refresh(refresh, n)
    total, last = 0.0, 0
    for t in range(n):
        if t in steps:
            last = t
            continue
        total += float(cost[last, t])
    return total


def dp_refresh(cost: np.ndarray, num_full: int) -> list[int]:
    """Optimal refresh set of size ``num_full`` under an additive cost matrix, in O(num_full * N^2).

    ``cost[r, t]`` (``r < t``) is the calibrated error of the approximate velocity at step ``t`` when the most
    recent refresh was ``r``; the proposal's natural choice is the median of ``||D_t - D_r|| / ||F_t||``.
    """
    n = cost.shape[0]
    if cost.shape != (n, n):
        raise ValueError("cost must be square")
    if not 1 <= num_full <= n:
        raise ValueError("need 1 <= num_full <= N")
    c = np.where(np.isfinite(cost), cost, 1e30).astype(np.float64)
    # seg[r, e]: cost of steps r+1 .. e-1 served by the refresh at r
    seg = np.zeros((n, n + 1))
    for r in range(n):
        run = 0.0
        for e in range(r + 1, n + 1):
            seg[r, e] = run
            if e < n:
                run += c[r, e]
    inf = float("inf")
    best = np.full((num_full + 1, n + 1), inf)
    arg = np.full((num_full + 1, n + 1), -1, dtype=int)
    for e in range(1, n + 1):
        best[1, e] = seg[0, e]
        arg[1, e] = 0
    for k in range(2, num_full + 1):
        for e in range(k, n + 1):
            for r in range(k - 1, e):
                val = best[k - 1, r] + seg[r, e]
                if val < best[k, e]:
                    best[k, e], arg[k, e] = val, r
    steps, e = [], n
    for k in range(num_full, 0, -1):
        r = int(arg[k, e])
        steps.append(r)
        e = r
    return validate_refresh(steps[::-1], n)
