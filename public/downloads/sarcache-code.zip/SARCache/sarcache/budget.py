"""End-to-end speed budget (proposal Sec. 6).

``T_new / T_base ~= p + (1 - p) (m / N + alpha) + o`` with ``p`` the fixed share of the baseline (text encoding,
VAE decode, ...), ``alpha`` the mean coarse/full forward time ratio, ``o`` the added transform/cache overhead as a
share of the baseline and ``m`` the number of full-resolution forwards. Every step runs one coarse forward,
including refresh steps.
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass


def time_ratio(p: float, alpha: float, o: float, m: int, num_steps: int = 40) -> float:
    return p + (1.0 - p) * (m / num_steps + alpha) + o


def speedup(p: float, alpha: float, o: float, m: int, num_steps: int = 40) -> float:
    return 1.0 / time_ratio(p, alpha, o, m, num_steps)


def max_full_forwards(p: float, alpha: float, o: float, target_speedup: float = 4.0, num_steps: int = 40) -> float:
    """Largest (real-valued) ``m`` meeting the target; negative means unreachable at any ``m``."""
    return num_steps * ((1.0 / target_speedup - p - o) / (1.0 - p) - alpha)


@dataclass
class Measured:
    """Measured seconds for one request at batch 1 on an exclusive GPU."""

    fixed_s: float
    full_forward_s: float
    coarse_forward_s: float
    overhead_per_step_s: float = 0.0
    num_steps: int = 40

    @property
    def base_s(self) -> float:
        return self.fixed_s + self.num_steps * self.full_forward_s

    @property
    def p(self) -> float:
        return self.fixed_s / self.base_s

    @property
    def alpha(self) -> float:
        return self.coarse_forward_s / self.full_forward_s

    @property
    def o(self) -> float:
        return self.num_steps * self.overhead_per_step_s / self.base_s

    def report(self, target_speedup: float = 4.0, m_values=(4, 6, 8, 10, 12)) -> dict:
        m_max = max_full_forwards(self.p, self.alpha, self.o, target_speedup, self.num_steps)
        return {
            **asdict(self),
            "p": self.p,
            "alpha": self.alpha,
            "o": self.o,
            "target_speedup": target_speedup,
            "m_max_real": m_max,
            "m_max": math.floor(m_max) if m_max >= 1 else 0,
            "predicted_speedup": {str(m): speedup(self.p, self.alpha, self.o, m, self.num_steps) for m in m_values},
        }
