# SARCache

Training-free **Staleness-Aware Residual Caching** for diffusion transformers. SARCache separates the decision to refresh a cache from the decision of how long to extrapolate its residual. Inside the forecast window it uses local linear residual prediction; beyond the window it holds the latest observed residual while retaining the current input projection and output head.

This repository contains implementation code and toy tests only. Model weights, generated media, run outputs, and evaluation artifacts are not included.

## Installation

Python 3.10 or newer is recommended. Install PyTorch for your platform, then install the package and model dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

`requirements-models.txt` pins the Diffusers source revision and related model dependencies. Installation does not download model weights.

## Minimal inference command

Prepare a local Diffusers-format Qwen-Image-2.1 checkpoint, then run:

```bash
python scripts/run_methods.py \
  --config configs/qwenimage21_sarcache.json \
  --model-path /path/to/Qwen-Image-2.1 \
  --prompt "A red bicycle leaning against a blue wall" \
  --seeds 0 \
  --out runs/example
```

The runner uses local files by default. `--allow-download` is an explicit opt-in for Hub loading. For a download dry-run without network access:

```bash
python scripts/download_model.py --dry-run
```

## Configuration

Each entry in `methods` is a `Method` configuration. The reference uses `predictor: exact`; SARCache uses `predictor: sarcache`.

Important SARCache fields:

- `forecast_age_window`: integer prediction horizon, or `"unbounded"`; zero means residual holding.
- `sarcache_thresh`: accumulated refresh-gate threshold.
- `sarcache_max_reuse`: maximum consecutive reuse count; zero disables this cap.
- `sarcache_warmup`: initial full-evaluation steps.
- `sarcache_raw_residual`: retain the unfiltered residual for reconstruction.
- `sarcache_img_indicator`: use the image-space spectral refresh indicator.
- `sarcache_fixed_refresh`: optional fixed full-refresh positions for controlled execution.

Legacy `krea_fb` and `kreafb_*` configuration keys are normalized by `Method.from_dict`. New records emitted by `to_dict()` use SARCache names.

## Package layout

- `sarcache/`: sampler, cache predictors, pipeline adapters, operators, schedules, and timing.
- `scripts/`: model download, parity, budget, diagnostics, calibration, and inference entry points.
- `h3/`: optional MiniMax-H3 integration layer; see `h3/README.md`.
- `configs/`: clean example configuration without run-specific notes.
- `data/`: prompt inputs used by the smoke checks.
- `tests/`: CPU toy-model and configuration-compatibility tests.

## Tests

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q tests/test_sarcache_cpu.py tests/test_sarcache_v3_cpu.py
python smoke_test.py --skip-diffusers --report /tmp/sarcache_smoke.json
```

The toy tests check implementation contracts, configuration normalization, cache identities, and forecast behavior. They do not replace real-weight inference or quality evaluation.

## External components

Model checkpoints and third-party frameworks are not redistributed here. Users are responsible for obtaining them and complying with their respective licenses. The H3 integration additionally requires its external ComfyUI environment described in `h3/README.md`.
