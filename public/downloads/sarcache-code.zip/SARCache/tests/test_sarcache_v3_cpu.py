"""CPU/toy tests for sarcache v3 (sarcache_raw_residual, 10-08): the commit path must carry the
UNFILTERED step-index-extrapolated residual (official SeaCache semantics). The §8.87 v2 line
filtered the committed residual with the mean-norm Wiener -- DC amplification at real shapes
was its death cause ②. Fixture toys commit the residual they receive so the plumbing is
directly inspectable. Same convention as test_sarcache_cpu.py: toys verify the sampler computes
what the configs specify, not real-model quality."""
from __future__ import annotations

import math
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from sarcache.operators import sea_wiener_filter  # noqa: E402
from sarcache.sampler import Method, sample  # noqa: E402


def rel(a, b):
    return float((a.double() - b.double()).norm() / (b.double().norm() + 1e-30))


class SarV3Toy:
    """Whole-stack residual toy with a sigma-dependent residual (so the extrapolation scale is
    observable) and an embed_reuse that records the residual it was handed."""

    def __init__(self, seed=0, res_scale=0.3):
        g = torch.Generator().manual_seed(seed)
        self.u = torch.randn(1, 2, 8, 8, dtype=torch.float64, generator=g)
        self.res_scale = res_scale
        self.records = []  # (sigma, committed residual[0]) in call order

    def begin(self):
        pass

    def fa(self, s):
        return 0.5 * self.u + 0.1 * s * self.u

    def __call__(self, x, sigma, role="full", factor=1):
        return self.fa(sigma)

    def embed(self, x):
        return (0.3 * x.to(torch.float64).sum(dim=1, keepdim=True)
                .expand(-1, 2, -1, -1).contiguous())

    def embed_full(self, x, sigma):
        emb = self.embed(x)
        resid = self.res_scale * (1.0 + float(sigma)) * torch.ones(
            1, 16, 4, dtype=x.dtype, device=x.device)
        return self.fa(sigma), emb, resid

    def embed_reuse(self, x, sigma, residual):
        self.records.append((float(sigma), float(residual.flatten()[0])))
        return self.fa(sigma)


def toy_inputs(num_steps=12, x_seed=7, quadratic=False):
    lin = torch.linspace(1.0, 0.0, num_steps + 1, dtype=torch.float64)
    sig = lin ** 2 if quadratic else lin  # quadratic: sigma scale != step-index scale
    x = torch.randn(1, 2, 8, 8, dtype=torch.float64,
                    generator=torch.Generator().manual_seed(x_seed))
    return sig, x


def _closed_form(toy, compute_steps, compute_sigmas, i, s_i):
    """resid_used at reuse step i given compute history (official step-index scale)."""
    r = {st: toy.res_scale * (1.0 + float(sg)) for st, sg in zip(compute_steps, compute_sigmas)}
    latest_i, latest_s = compute_steps[-1], compute_sigmas[-1]
    if len(compute_steps) >= 2:
        prev_i, prev_s = compute_steps[-2], compute_sigmas[-2]
        scale_step = (i - latest_i) / max(latest_i - prev_i, 1)
        scale_sig = (float(s_i) - float(latest_s)) / max(float(latest_s) - float(prev_s), 1e-8)
        return r[latest_i] + (r[latest_i] - r[prev_i]) * scale_step, \
               r[latest_i] + (r[latest_i] - r[prev_i]) * scale_sig
    return r[latest_i], r[latest_i]


def test_sarcache_v3_raw_residual_step_index_scale():
    """v3 commits the unfiltered residual extrapolated in STEP-INDEX space (official); with a
    quadratic sigma schedule the sigma-space scale would give different values, so the two are
    distinguishable. max_reuse=2 with a never-firing gate gives the deterministic F R R pattern."""
    for quadratic in (False, True):
        sig, x = toy_inputs(quadratic=quadratic)
        toy = SarV3Toy(seed=3)
        m = Method(name="v3", predictor="sarcache", sarcache_thresh=1e9, sarcache_max_reuse=2,
                   sarcache_filter_gate=False, sarcache_raw_residual=True)
        r = sample(toy, x, sig, m, record=True)
        used = [(s_["step"], s_["used"], s_["sigma"]) for s_ in r.steps]
        computes = [(st, sg) for st, u, sg in used if u == "sar_F"]
        assert len(computes) >= 3, used
        reuses = [(st, sg) for st, u, sg in used if u == "sar_reuse"]
        assert len(toy.records) == len(reuses), (toy.records, reuses)
        seen_step_scale = False
        for (st, sg), (_rs, got) in zip(reuses, toy.records):
            hist = [(cst, csg) for cst, csg in computes if cst < st]
            exp_step, exp_sig = _closed_form(toy, [h[0] for h in hist],
                                             [h[1] for h in hist], st, sg)
            assert abs(got - exp_step) < 1e-9, (quadratic, st, got, exp_step)
            if abs(exp_step - exp_sig) > 1e-12:
                seen_step_scale = True
                assert abs(got - exp_sig) > 1e-9, (quadratic, st, "sigma scale leaked in")
        if quadratic:
            assert seen_step_scale, "quadratic schedule must distinguish the two scales"


def test_sarcache_v3_raw_vs_filtered_differ():
    """The v2 (filtered) path must still apply the Wiener to the commit; v3 must not.
    Uniform sigmas: both arms extrapolate identically, so any committed-residual difference
    is exactly the filter (quadratic schedules would mix in the scale change — kept in the
    step-index test above)."""
    sig, x = toy_inputs(quadratic=False)
    raw, filt = SarV3Toy(seed=3), SarV3Toy(seed=3)
    base = dict(predictor="sarcache", sarcache_thresh=1e9, sarcache_max_reuse=2,
                sarcache_filter_gate=False)
    m_raw = Method(name="vr", sarcache_raw_residual=True, **base)
    m_fil = Method(name="vf", sarcache_a=1.0, sarcache_b=2.0, **base)
    rr = sample(raw, x, sig, m_raw, record=True)
    rf = sample(filt, x, sig, m_fil, record=True)
    raw_resid = {s_["step"]: v for s_, (_sg, v) in
                 zip([s_ for s_ in rr.steps if s_["used"] == "sar_reuse"], raw.records)}
    filt_resid = {s_["step"]: v for s_, (_sg, v) in
                  zip([s_ for s_ in rf.steps if s_["used"] == "sar_reuse"], filt.records)}
    for st in raw_resid:
        exp_filtered = float(sea_wiener_filter(
            torch.full((1, 16, 4), raw_resid[st]), 1.0, 2.0, dims=(1,)).flatten()[0])
        # the filter works in fp32 internally — 1e-7-level rounding is expected
        assert abs(filt_resid[st] - exp_filtered) < 1e-5, (st, filt_resid[st], exp_filtered)
        assert abs(raw_resid[st] - filt_resid[st]) > 1e-9, (st, "filtered == raw?!")


def test_sarcache_v31_img_indicator_gate():
    """v3.1 gate domain: the official SEA indicator filters the raw input latent in image space
    and refreshes its reference EVERY step. A toy with a CONSTANT embed probe but a drifting
    latent must therefore fire the img-indicator gate while the embed gate stays silent."""
    import pytest

    class ConstProbeToy(SarV3Toy):
        def embed(self, x):
            # constant: the embed-probe rel-L1 is identically 0 (gate can never fire)
            return torch.ones(1, 2, 8, 8, dtype=torch.float64, device=x.device)

    sig, x = toy_inputs()
    # filter_gate=False: the constant probe stays bitwise constant (the Wiener gain itself
    # varies with sigma and would make even a constant probe drift -- that is the img arm's
    # signal, not the embed arm's).
    base = dict(predictor="sarcache", sarcache_thresh=1e-6, sarcache_order=1,
                sarcache_max_reuse=0, sarcache_filter_gate=False)
    emb_arm = sample(ConstProbeToy(seed=3), x, sig,
                     Method(name="e", sarcache_raw_residual=True, **base), record=True)
    img_arm = sample(ConstProbeToy(seed=3), x, sig,
                     Method(name="i", sarcache_raw_residual=True, sarcache_img_indicator=True,
                            **base), record=True)
    emb_fires = sum(1 for s_ in emb_arm.steps if s_["used"] == "sar_F")
    img_fires = sum(1 for s_ in img_arm.steps if s_["used"] == "sar_F")
    # embed gate: constant probe -> rel-L1 == 0 -> only the forced endpoints compute
    assert emb_fires == 2, emb_fires
    # img gate: the latent drifts every step -> the drift gate fires throughout
    assert img_fires > len(img_arm.steps) // 2, img_fires
    with pytest.raises(ValueError, match="requires sarcache_raw_residual"):
        Method(name="bad", predictor="sarcache", sarcache_thresh=0.1,
               sarcache_img_indicator=True)


def test_spec_kf_commit_hybrid():
    """v3.1xspec hybrid: accepted steps with a fresh residual (age <= spec_kf_max_age) commit
    the SeaCore reuse velocity via embed_reuse; stale steps fall back to draft/fusion. The
    extrapolation is order-1 in step-index space over the residual history captured at
    verify/refresh full forwards (zero extra cost)."""
    import pytest

    class SpecSarToy:
        def __init__(self, seed=0, res_scale=0.3):
            g = torch.Generator().manual_seed(seed)
            # full-resolution fields for fa and the draft (both bands carry signal; the
            # naive CoarseView lift is block-constant = pure lo band, so the toy routes the
            # draft through spec_distill's draft_net like the real distilled student)
            self.u = torch.randn(1, 2, 8, 8, dtype=torch.float64, generator=g)
            self.w = torch.randn(1, 2, 8, 8, dtype=torch.float64, generator=g)
            self.n = torch.randn(1, 2, 8, 8, dtype=torch.float64, generator=g)
            self.res_scale = res_scale
            self.records = []

        def begin(self):
            pass

        def fa(self, s):
            return 0.5 * self.u + 0.1 * float(s) * self.w

        def draft_net(self, x, s):
            return 0.5 * self.fa(s) + 0.1 * self.n

        def __call__(self, x, sigma, role="full", factor=1):
            return self.fa(sigma)

        def embed_full(self, x, sigma):
            emb = x.to(torch.float64).mean()
            resid = self.res_scale * (1.0 + float(sigma)) * torch.ones(
                1, 16, 4, dtype=x.dtype, device=x.device)
            return self.fa(sigma), emb, resid

        def embed_reuse(self, x, sigma, residual):
            self.records.append((float(sigma), float(residual.flatten()[0])))
            return self.fa(sigma)

    sig = torch.linspace(1.0, 0.0, 13, dtype=torch.float64)
    x = torch.randn(1, 2, 8, 8, dtype=torch.float64,
                    generator=torch.Generator().manual_seed(7))
    base = dict(predictor="spec", factor=2, coarse_mode="naive", num_full=12,
                refresh=[0, 1], spec_threshold=1e9, spec_fusion=False, spec_distill=True)

    # flag-off arm: accepted steps all draft; same verify budget as the hybrid arm
    a = sample(SpecSarToy(), x, sig, Method(name="a", **base), record=True)
    assert all(s_["used"] in ("F", "draft") for s_ in a.steps)
    b = sample(SpecSarToy(), x, sig, Method(name="b", spec_kf_commit=True, **base), record=True)
    assert a.counts == b.counts, (a.counts, b.counts)  # kf swap adds no full forwards

    # fresh-residual commit swap + closed-form extrapolation (captures at steps 0,1 only
    # because the gate never fires past the refresh steps)
    toy = SpecSarToy(seed=3)
    r = sample(toy, x, sig, Method(name="h", spec_kf_commit=True, spec_kf_max_age=2, **base),
               record=True)
    used = [(s_["step"], s_["used"], s_["sigma"]) for s_ in r.steps]
    assert used[0][1] == "F" and used[1][1] == "F"
    assert [u for _, u, _ in used[2:4]] == ["sar_reuse", "sar_reuse"], used
    assert all(u == "draft" for _, u, _ in used[4:]), used
    r0 = toy.res_scale * (1.0 + float(sig[0]))
    r1 = toy.res_scale * (1.0 + float(sig[1]))
    exp = [(float(sig[2]), r1 + (r1 - r0) * 1.0), (float(sig[3]), r1 + (r1 - r0) * 2.0)]
    assert len(toy.records) == 2
    for (sg, got), (_es, want) in zip(toy.records, exp):
        # 1e-6: the residual chain passes through a float32-precision value upstream of the
        # extrapolation (observed 1.2e-8 absolute) — the mechanism is step-index exact
        assert abs(got - want) < 1e-6, (got, want)

    # max_age=1: only the first accepted step commits kf
    r1t = sample(SpecSarToy(seed=3), x, sig,
                 Method(name="h1", spec_kf_commit=True, spec_kf_max_age=1, **base), record=True)
    u1 = [s_["used"] for s_ in r1t.steps]
    assert u1[2] == "sar_reuse" and all(u == "draft" for u in u1[3:]), u1

    # perfect-reuse kf commits keep the exact trajectory when every accepted step is kf
    # (max_age large): every commit is fa(sigma), matching the exact integrator end-to-end
    ref = sample(SpecSarToy(seed=3), x, sig, Method(name="ref", predictor="exact"), record=True)
    r_all = sample(SpecSarToy(seed=3), x, sig,
                   Method(name="ha", spec_kf_commit=True, spec_kf_max_age=99, **base),
                   record=True)
    assert all(s_["used"] in ("F", "sar_reuse") for s_ in r_all.steps)
    assert rel(r_all.latents, ref.latents) < 1e-9
    # and the hybrid differs from the draft-only arm (the swap actually engages)
    assert rel(r.latents, a.latents) > 1e-3

    # band split: intercept the committed velocity (euler_update is the single consumer of
    # v) and assert step-2's commit is lo(fa) + hi(draft) band-exact. The toy velocity
    # fields are x-independent, so bands are the right invariant; final-latent band
    # attribution is washed out by the shared x0, hence the per-step intercept.
    import sarcache.sampler as _smp
    from sarcache.operators import low_high_split as _lhs
    captured = {}
    orig_euler = _smp.euler_update
    def spy_euler(x, v, s, sn):
        captured.setdefault("v", []).append(v.clone())
        return orig_euler(x, v, s, sn)
    _smp.euler_update = spy_euler
    try:
        sample(SpecSarToy(seed=3), x, sig, Method(name="a2", **base), record=True)
        chain_v = captured["v"][2]  # the flag-off commit IS the chain commit by definition
        captured.clear()
        rb = sample(SpecSarToy(seed=3), x, sig,
                    Method(name="hb", spec_kf_commit=True, spec_kf_max_age=99,
                           spec_kf_band=True, **base), record=True)
        v2 = captured["v"][2]
    finally:
        _smp.euler_update = orig_euler
    assert any(s_["used"] == "sar_reuse_band" for s_ in rb.steps)
    fa2 = SpecSarToy(seed=3).fa(float(sig[2]))
    e_lo, _e_hi = _lhs(fa2, 2)
    _c_lo, c_hi = _lhs(chain_v, 2)
    # 1e-7: the residual chain carries float32-precision values (observed ~2.5e-9 rel)
    assert rel(v2, e_lo + c_hi) < 1e-7, "band commit must be lo(kf) + hi(chain)"
    assert rel(v2, fa2) > 1e-3 and rel(v2, chain_v) > 1e-3, "band commit differs from both parents"

    def must_raise(desc, **kw):
        with pytest.raises(ValueError):
            Method(**kw)

    must_raise("kf x fusion_sea", predictor="spec", spec_threshold=0.1, spec_kf_commit=True,
               spec_fusion_sea=True, spec_sea_a=1.0, spec_sea_b=2.0)
    must_raise("kf outside spec", predictor="fcache", spec_kf_commit=True)
    must_raise("kf x nodraft", predictor="spec", spec_threshold=0.1, spec_kf_commit=True,
               spec_nodraft=True, spec_ref_order=2)
    must_raise("kf age 0", predictor="spec", spec_threshold=0.1, spec_kf_commit=True,
               spec_kf_max_age=0)
    must_raise("band without kf", predictor="spec", spec_threshold=0.1, spec_kf_band=True)


    # warmup anchor (lever ①): steps < sarcache_warmup always compute, even with a
    # never-firing gate -- EC's dense early anchor, the per-prompt autopsy's structural find
    sig, x = toy_inputs()
    toy = SarV3Toy(seed=3)
    r = sample(toy, x, sig, Method(name="w", predictor="sarcache", sarcache_thresh=1e9,
                                   sarcache_max_reuse=0, sarcache_filter_gate=False,
                                   sarcache_warmup=5), record=True)
    used = [s_["used"] for s_ in r.steps]
    assert all(u == "sar_F" for u in used[:5]), used
    assert any(u == "sar_reuse" for u in used[5:]), used
    with pytest.raises(ValueError, match="sarcache_warmup"):
        Method(name="bad3", predictor="sarcache", sarcache_thresh=0.1, sarcache_warmup=0)


    # adaptive order (10-09): order=2 extrapolates only within 2 steps of the freshest
    # residual, raw beyond -- official max_consecutive_cached semantics at long spans.
    sig, x = toy_inputs()
    toy = SarV3Toy(seed=3)
    r = sample(toy, x, sig, Method(name="ad", predictor="sarcache", sarcache_thresh=1e9,
                                   sarcache_max_reuse=0, sarcache_filter_gate=False,
                                   sarcache_raw_residual=True, sarcache_order=2), record=True)
    used = [s_["used"] for s_ in r.steps]
    # captures at 0,3,6... (never-firing gate, no cap): reuse age<=2 extrapolates, older raw
    reuse_steps = [s_["step"] for s_ in r.steps if s_["used"] == "sar_reuse"]
    assert len(toy.records) == len(reuse_steps)
    r_of = {s_["step"]: toy.res_scale * (1.0 + float(s_["sigma"]))
            for s_ in r.steps if s_["used"] == "sar_F"}
    hist = sorted(r_of)
    for st, (_sg, got) in zip(reuse_steps, toy.records):
        prior = [c for c in hist if c < st]
        latest = prior[-1]
        if st - latest <= 2 and len(prior) >= 2:
            prev = prior[-2]
            exp = r_of[latest] + (r_of[latest] - r_of[prev]) * ((st - latest) / max(latest - prev, 1))
        else:
            exp = r_of[latest]
        assert abs(got - exp) < 1e-6, (st, got, exp)
    with pytest.raises(ValueError, match="sarcache_order"):
        Method(name="bad4", predictor="sarcache", sarcache_thresh=0.1, sarcache_order=3)


    # output-cache mode (10-09): reuse steps commit the stale cached velocity verbatim (EC
    # semantics) -- with a perfect-reuse toy every commit equals fa(sigma at the compute
    # step), so the trajectory is piecewise-frozen; assert the used string and that the
    # committed velocity at reuse step i equals fa(sigma of the last compute).
    sig, x = toy_inputs()
    toy = SarV3Toy(seed=3)
    r = sample(toy, x, sig, Method(name="oc", predictor="sarcache", sarcache_thresh=1e9,
                                   sarcache_max_reuse=0, sarcache_filter_gate=False,
                                   sarcache_raw_residual=True, sarcache_output_cache=True),
               record=True)
    used = [s_["used"] for s_ in r.steps]
    assert used[0] == "sar_F" and all(u == "sar_ocache" for u in used[1:-1]) and used[-1] == "sar_F"
    # capture the committed velocities via the euler spy
    import sarcache.sampler as _smp2
    captured = {}
    orig_euler = _smp2.euler_update
    def spy_euler(x, v, s, sn):
        captured.setdefault("v", []).append(v.clone())
        return orig_euler(x, v, s, sn)
    _smp2.euler_update = spy_euler
    try:
        sample(SarV3Toy(seed=3), x, sig, Method(name="oc2", predictor="sarcache", sarcache_thresh=1e9,
                      sarcache_max_reuse=0, sarcache_filter_gate=False,
                      sarcache_raw_residual=True, sarcache_output_cache=True), record=True)
    finally:
        _smp2.euler_update = orig_euler
    # the never-firing gate reuses from step 1, so every reuse commits the step-0 velocity
    assert rel(captured["v"][2], captured["v"][0]) < 1e-12, "reuse must commit the cached compute velocity"
    assert rel(captured["v"][2], SarV3Toy(seed=3).fa(float(sig[2]))) > 1e-3, "stale != fresh"
    with pytest.raises(ValueError, match="must not mix"):
        Method(name="bad5", predictor="sarcache", sarcache_thresh=0.1, sarcache_output_cache=True)


    # k-rate gate (10-09): EC's propagation-rate semantics. tiny thresh -> all compute (exact);
    # huge thresh -> only the forced endpoints. krate x img_indicator is rejected (domains).
    sig, x = toy_inputs()
    toy = SarV3Toy(seed=3)
    base_kw = dict(predictor="sarcache", sarcache_order=0, sarcache_max_reuse=0,
                   sarcache_filter_gate=False, sarcache_raw_residual=True, sarcache_krate=True)
    r_lo = sample(toy, x, sig, Method(name="kl", sarcache_thresh=0.0, **base_kw), record=True)
    ref = sample(SarV3Toy(seed=3), x, sig, Method(name="ref", predictor="exact"), record=True)
    assert rel(r_lo.latents, ref.latents) < 1e-9, "thresh=0 must compute every step"
    r_hi = sample(SarV3Toy(seed=3), x, sig, Method(name="kh", sarcache_thresh=1e9, **base_kw),
                  record=True)
    u_hi = [s_["used"] for s_ in r_hi.steps]
    assert u_hi[0] == "sar_F" and u_hi[-1] == "sar_F" and all(u == "sar_ocache" or u == "sar_reuse"
            for u in u_hi[1:-1]), u_hi
    with pytest.raises(ValueError, match="pick one gate"):
        Method(name="bad6", predictor="sarcache", sarcache_thresh=0.1, sarcache_krate=True,
               sarcache_img_indicator=True, sarcache_raw_residual=True)


    # mean ensemble: v = 0.5*chain + 0.5*kf on fresh steps
    import sarcache.sampler as _smp3
    cap2 = {}
    orig_euler = _smp3.euler_update
    def spy2(x, v, s, sn):
        cap2.setdefault("v", []).append(v.clone())
        return orig_euler(x, v, s, sn)
    _smp3.euler_update = spy2
    try:
        sample(SpecSarToy(seed=3), x, sig, Method(name="a3", **base), record=True)
        chain_v = cap2["v"][2]
        cap2.clear()
        rm = sample(SpecSarToy(seed=3), x, sig,
                    Method(name="m", spec_kf_commit=True, spec_kf_max_age=99, spec_kf_mean=0.5,
                           **base), record=True)
        v2m = cap2["v"][2]
    finally:
        _smp3.euler_update = orig_euler
    fa2 = SpecSarToy(seed=3).fa(float(sig[2]))
    assert rel(v2m, 0.5 * chain_v + 0.5 * fa2) < 1e-7, "mean commit = 0.5*chain + 0.5*kf"
    assert any(s_["used"] == "sar_reuse_mean" for s_ in rm.steps)
    must_raise("mean without kf", predictor="spec", spec_threshold=0.1, spec_kf_mean=0.5)
    must_raise("mean range", predictor="spec", spec_threshold=0.1, spec_kf_commit=True,
               spec_kf_mean=1.5)
    must_raise("mean x band", predictor="spec", spec_threshold=0.1, spec_kf_commit=True,
               spec_kf_mean=0.5, spec_kf_band=True)


if __name__ == "__main__":
    failed = 0
    for fn in [v for k, v in sorted(globals().items()) if k.startswith("test_")]:
        try:
            fn()
            print(f"PASS {fn.__name__}", flush=True)
        except Exception:
            failed += 1
            print(f"FAIL {fn.__name__}", flush=True)
            import traceback
            traceback.print_exc()
    sys.exit(1 if failed else 0)
