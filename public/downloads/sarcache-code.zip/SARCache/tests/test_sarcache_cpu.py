"""CPU/toy-model tests for the sarcache predictor (SeaCache-core v1, §8.87). Runnable with
pytest or directly: ``python tests/test_sarcache_cpu.py``.

Fixture ``SarToy``: F = 0.5*U + sin(6s)*V (time-varying); the adapter contract mirrors Krea 2:
``embed(x)`` = the img_in probe, ``embed_full(x, s)`` = (velocity, embed, hN-embed),
``embed_reuse(x, s, resid)`` = a velocity from the current embed + residual. With a PERFECT
reuse (returns fa exactly) the gated run must verify-freeze correctly and hug the reference
once the probe tracks; with the gate tight (thresh=0) it degenerates to all-compute.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from sarcache.sampler import Method, sample  # noqa: E402

TH = 0.05


class SarToy:
    def __init__(self, alpha=0.8, seed=0, omega=6.0, perfect=True):
        g = torch.Generator().manual_seed(seed)
        self.omega = omega
        self.perfect = perfect
        self.uc = torch.randn(1, 2, 4, 4, dtype=torch.float64, generator=g)
        self.u = torch.randn(1, 2, 8, 8, dtype=torch.float64, generator=g)
        self.v = torch.randn(1, 2, 8, 8, dtype=torch.float64, generator=g)

    def fa(self, sf):
        return 0.5 * self.u + math.sin(self.omega * sf) * self.v

    def __call__(self, x, sigma, role="full", factor=1):
        if role == "coarse":
            return 0.4 * self.alpha * self.uc
        return self.fa(sigma)

    def embed(self, x):
        return 0.3 * x.to(torch.float64).sum(dim=1, keepdim=True).expand(-1, 4, -1, -1).contiguous()

    def embed_full(self, x, sigma):
        emb = self.embed(x)
        resid = torch.ones(1, 16, 4, dtype=x.dtype, device=x.device)
        return self.fa(sigma), emb, resid

    def embed_reuse(self, x, sigma, residual):
        if self.perfect:
            return self.fa(sigma)
        return self.fa(sigma) + 0.05 * torch.randn_like(self.fa(sigma))


def toy_inputs(num_steps=12, x_seed=7):
    sig = torch.linspace(1.0, 0.0, num_steps + 1, dtype=torch.float64)
    x = torch.randn(1, 2, 8, 8, dtype=torch.float64, generator=torch.Generator().manual_seed(x_seed))
    return sig, x


def test_sarcache_perfect_reuse_gate_cycle():
    """Gate semantics: thresh=0 -> all-compute (== exact); a finite thresh reuses and with a
    PERFECT reuse the trajectory is as good as exact."""
    sig, x = toy_inputs()
    toy = SarToy()
    m0 = Method(name="k0", predictor="sarcache", sarcache_thresh=0.0)
    r0 = sample(toy, x, sig, m0, record=True)
    ref = sample(toy, x, sig, Method(name="ref", predictor="exact"), record=True)
    assert torch.allclose(r0.latents, ref.latents), "thresh=0 must compute every step"
    m1 = Method(name="k1", predictor="sarcache", sarcache_thresh=TH, sarcache_a=1.0, sarcache_b=2.0,
                           sarcache_filter_gate=False)
    r1 = sample(toy, x, sig, m1, record=True)
    used = [s["used"] for s in r1.steps]
    assert any(u == "sar_reuse" for u in used), used
    assert used[0] == "sar_F" and used[-1] == "sar_F"
    assert r1.counts["full"] < len(used), r1.counts
    rel = float((r1.latents - ref.latents).norm() / ref.latents.norm())
    assert rel < 1e-9, rel   # perfect reuse + correct gate == exact


def test_sarcache_gate_accumulates_and_resets():
    """The gate accumulates probe rel-L1 and resets at compute steps (SeaCache semantics)."""
    sig, x = toy_inputs()
    toy = SarToy()
    r = sample(toy, x, sig, Method(name="k", predictor="sarcache", sarcache_thresh=TH, sarcache_filter_gate=False), record=True)
    used = [s["used"] for s in r.steps]
    # after each sar_F there is at least one reuse before the next sar_F (accumulation from 0)
    first_reuse = next(i for i, u in enumerate(used) if u == "sar_reuse")
    assert used[first_reuse - 1] == "sar_F"


def test_sarcache_validation_and_capability():
    with pytest.raises(ValueError, match="needs sarcache_thresh"):
        Method(name="x", predictor="sarcache")
    with pytest.raises(ValueError, match=">= 0"):
        Method(name="x", predictor="sarcache", sarcache_thresh=-1.0)

    from sarcache.sampler import _sample, Timer

    class NoSar:
        def begin(self): pass
        def __call__(self, x, s, role="full", factor=1):
            return 0.5 * torch.ones_like(x)

    sig, x = toy_inputs()
    with pytest.raises(NotImplementedError, match="embed"):
        _sample(NoSar(), x, sig, Method(name="np", predictor="sarcache", sarcache_thresh=TH),
                Timer(False), None)


def test_sarcache_v2_max_reuse_forces_compute():
    """max_reuse=1 with a never-firing gate: reuses may never exceed one consecutive — every
    other step computes (the official max_consecutive_cached staleness cap)."""
    sig, x = toy_inputs()
    toy = SarToy()
    r = sample(toy, x, sig, Method(name="v2", predictor="sarcache", sarcache_thresh=1e9,
                                   sarcache_max_reuse=1, sarcache_filter_gate=False), record=True)
    used = [s["used"] for s in r.steps]
    assert all(used[i] == "sar_F" for i in range(0, len(used), 2)), used


def test_sarcache_imperfect_reuse_degrades():
    """Direction: an imperfect reuse must be worse than the perfect one (mechanism sanity)."""
    sig, x = toy_inputs()
    perfect = sample(SarToy(perfect=True), x, sig,
                     Method(name="p", predictor="sarcache", sarcache_thresh=TH,
                            sarcache_filter_gate=False), record=True)
    noisy = sample(SarToy(perfect=False, seed=1), x, sig,
                   Method(name="n", predictor="sarcache", sarcache_thresh=TH,
                          sarcache_filter_gate=False), record=True)
    ref = sample(SarToy(perfect=True), x, sig, Method(name="r", predictor="exact"), record=True)
    rp = float((perfect.latents - ref.latents).norm())
    rn = float((noisy.latents - ref.latents).norm())
    assert rn > rp


def test_sarcache_legacy_config_normalization():
    legacy = {
        "name": "legacy", "predictor": "krea_fb", "kreafb_thresh": 0.1,
        "kreafb_raw_residual": True, "kreafb_max_reuse": 6,
        "kreafb_warmup": 8, "forecast_age_window": 3,
    }
    current = {
        "name": "legacy", "predictor": "sarcache", "sarcache_thresh": 0.1,
        "sarcache_raw_residual": True, "sarcache_max_reuse": 6,
        "sarcache_warmup": 8, "forecast_age_window": 3,
    }
    assert Method.from_dict(legacy) == Method.from_dict(current)
    assert Method(name="direct", predictor="krea_fb", sarcache_thresh=0.1).predictor == "sarcache"
    exported = Method.from_dict(legacy).to_dict()
    assert exported["predictor"] == "sarcache"
    assert not any(key.startswith("kreafb_") for key in exported)
    with pytest.raises(ValueError, match="duplicate Method field"):
        Method.from_dict({"predictor": "sarcache", "kreafb_thresh": 0.1,
                          "sarcache_thresh": 0.2})
    with pytest.raises(ValueError, match="unknown Method field"):
        Method.from_dict({"predictor": "sarcache", "not_a_field": True})


if __name__ == "__main__":
    test_sarcache_perfect_reuse_gate_cycle()
    test_sarcache_gate_accumulates_and_resets()
    test_sarcache_validation_and_capability()
    test_sarcache_imperfect_reuse_degrades()
    test_sarcache_legacy_config_normalization()
    print("all sarcache tests passed")
