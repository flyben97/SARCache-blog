"""语义指标评测：ImageReward + CLIP score (+LPIPS vs full，可选)。

对一个 closed_loop 输出目录（records.jsonl + images/）逐条计算：
  - ImageReward(prompt, image)
  - CLIP ViT-L/14 图文余弦相似度 x100
  - LPIPS(image, full 同 prompt/seed 参考图)（若 lpips 可用）

用法: python scripts/eval_semantic.py --dir <closed_loop子目录或绝对路径> [--out xxx.json]
模型路径: $MODELS_DIR/ImageReward-v1.0, $MODELS_DIR/clip-vit-large-patch14（默认 Image-gen/models/）
"""
import argparse, collections, json, math, os, statistics as st, sys

import numpy as np
import torch
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', required=True)
    ap.add_argument('--out', default=None)
    args = ap.parse_args()
    D = args.dir if os.path.isabs(args.dir) else os.path.join(
        open(os.path.join(ROOT, 'runs/latest_run_path.txt')).read().strip(), 'closed_loop', args.dir)
    D = os.path.normpath(os.path.join(ROOT, D)) if not os.path.isabs(D) else D
    if not os.path.isdir(D):
        D = os.path.normpath(os.path.join(ROOT, args.dir))
    models = os.environ.get('MODELS_DIR', os.path.join(ROOT, 'models'))
    out_path = args.out or os.path.join(D, 'semantic.json')

    recs = [json.loads(l) for l in open(os.path.join(D, 'records.jsonl'))]
    print(f'records = {len(recs)}, dir = {D}', file=sys.stderr)

    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # --- ImageReward (PyPI: image-reward, import name: ImageReward); pass file paths directly so
    # no HF download happens at runtime (jobs run with HF_HUB_OFFLINE=1)
    # transformers>=4.40 moved these helpers from modeling_utils to pytorch_utils;
    # ImageReward's bundled BERT still imports them from the old location, so re-export.
    import transformers.modeling_utils as _mu
    try:
        import transformers.pytorch_utils as _pu
    except Exception:
        _pu = None
    for _name in ('apply_chunking_to_forward', 'find_pruneable_heads_and_indices',
                  'prune_linear_layer', 'prune_conv1d_layer', 'prune_layer'):
        if not hasattr(_mu, _name):
            if _pu is not None and hasattr(_pu, _name):
                setattr(_mu, _name, getattr(_pu, _name))
            elif _name == 'apply_chunking_to_forward':
                def _apply_chunking_to_forward(forward_fn, chunk_size, chunk_dim, *input_tensors):
                    if not chunk_size or chunk_size <= 0:
                        return forward_fn(*input_tensors)
                    outs = []
                    for parts in zip(*(t.split(chunk_size, dim=chunk_dim) for t in input_tensors)):
                        outs.append(forward_fn(*parts))
                    return torch.cat(outs, dim=chunk_dim)
                _mu.apply_chunking_to_forward = _apply_chunking_to_forward
            elif _name == 'find_pruneable_heads_and_indices':
                def _find_pruneable_heads_and_indices(heads, n_heads, head_size, already_pruned_heads):
                    mask = torch.ones(n_heads, head_size)
                    heads = set(heads) - set(already_pruned_heads)
                    for head in heads:
                        head = head - sum(1 if h < head else 0 for h in already_pruned_heads)
                        mask[head] = 0
                    mask = mask.view(-1).contiguous().eq(1)
                    return heads, torch.nonzero(mask, as_tuple=False).squeeze(-1)
                _mu.find_pruneable_heads_and_indices = _find_pruneable_heads_and_indices
            elif _name == 'prune_linear_layer':
                def _prune_linear_layer(layer, index, dim=0):
                    if dim == 0:
                        W = layer.weight.index_select(dim, index).clone().detach()
                        b = layer.bias[index].clone().detach() if layer.bias is not None else None
                        new = torch.nn.Linear(layer.in_features, index.numel(), bias=layer.bias is not None)
                    else:
                        W = layer.weight.index_select(dim, index).clone().detach()
                        b = layer.bias.clone().detach() if layer.bias is not None else None
                        new = torch.nn.Linear(index.numel(), layer.out_features, bias=layer.bias is not None)
                    new.weight.requires_grad = False
                    new.weight.copy_(W.contiguous())
                    new.weight.requires_grad = True
                    if layer.bias is not None:
                        new.bias.requires_grad = False
                        new.bias.copy_(b.contiguous())
                        new.bias.requires_grad = True
                    return new.to(layer.weight.device)
                _mu.prune_linear_layer = _prune_linear_layer
    import ImageReward as rm
    # BLIP 的 init_tokenizer 硬编码 BertTokenizer.from_pretrained('bert-base-uncased')，
    # 作业离线（HF_HUB_OFFLINE=1）下会失败；改为本地 models/bert-base-uncased
    import ImageReward.models.BLIP.blip as _blip
    import ImageReward.models.BLIP.blip_pretrain as _blip_pre
    def _init_tokenizer_local():
        from transformers import BertTokenizer
        tok = BertTokenizer.from_pretrained(os.path.join(models, 'bert-base-uncased'))
        tok.add_special_tokens({'bos_token': '[DEC]'})
        tok.add_special_tokens({'additional_special_tokens': ['[ENC]']})
        tok.enc_token_id = tok.additional_special_tokens_ids[0]
        return tok
    _blip.init_tokenizer = _init_tokenizer_local
    _blip_pre.init_tokenizer = _init_tokenizer_local  # blip_pretrain 用 from-import，需单独打补丁
    ir_dir = os.path.join(models, 'ImageReward-v1.0')
    ir = rm.load(os.path.join(ir_dir, 'ImageReward.pt'),
                 med_config=os.path.join(ir_dir, 'med_config.json'), device=device)

    # --- CLIP
    from transformers import CLIPModel, CLIPProcessor
    clip = CLIPModel.from_pretrained(os.path.join(models, 'clip-vit-large-patch14')).to(device).eval()
    clip_proc = CLIPProcessor.from_pretrained(os.path.join(models, 'clip-vit-large-patch14'))

    # --- LPIPS (optional)
    lpips_fn = None
    try:
        import lpips
        lpips_fn = lpips.LPIPS(net='vgg').to(device).eval()
    except Exception as e:
        print(f'LPIPS unavailable: {e}', file=sys.stderr)

    full_img = {}
    for r in recs:
        if r['method']['name'] == 'full':
            full_img[(r['id'], r['seed'])] = r['image']

    results = []
    with torch.no_grad():
        for k, r in enumerate(recs):
            img_path = os.path.join(D, r['image'])
            prompt = r['prompt']
            score_ir = float(ir.score(prompt, img_path))
            img = Image.open(img_path).convert('RGB')
            inputs = clip_proc(text=[prompt], images=[img], return_tensors='pt', padding=True,
                               truncation=True, max_length=77).to(device)
            out = clip(**inputs)
            cs = torch.nn.functional.cosine_similarity(out.image_embeds, out.text_embeds).item() * 100
            lp = None
            if lpips_fn is not None and r['method']['name'] != 'full':
                ref = full_img.get((r['id'], r['seed']))
                if ref:
                    import lpips as _lp
                    a = lpips.normalize_tensor(
                        torch.from_numpy(np.asarray(img, dtype=np.float32) / 255.).permute(2, 0, 1)[None].to(device))
                    b_img = Image.open(os.path.join(D, ref)).convert('RGB')
                    b = lpips.normalize_tensor(
                        torch.from_numpy(np.asarray(b_img, dtype=np.float32) / 255.).permute(2, 0, 1)[None].to(device))
                    lp = float(lpips_fn(a, b).item())
            results.append(dict(id=r['id'], seed=r['seed'], method=r['method']['name'],
                                category=r['category'], imagereward=score_ir, clip=cs, lpips=lp))
            if (k + 1) % 50 == 0:
                print(f'{k + 1}/{len(recs)}', file=sys.stderr)

    agg = collections.defaultdict(lambda: collections.defaultdict(list))
    for x in results:
        agg[x['method']]['imagereward'].append(x['imagereward'])
        agg[x['method']]['clip'].append(x['clip'])
        if x['lpips'] is not None:
            agg[x['method']]['lpips'].append(x['lpips'])
    summary = {m: {k: (st.mean(v) if v else None) for k, v in d.items()} for m, d in agg.items()}
    json.dump(dict(summary=summary, records=results), open(out_path, 'w'), indent=1)
    print(f"{'method':26s} {'ImageReward':>11s} {'CLIP':>7s} {'LPIPS':>7s}")
    for m in sorted(summary):
        s = summary[m]
        lp = f"{s['lpips']:.4f}" if s.get('lpips') is not None else '-'
        print(f"{m:26s} {s['imagereward']:11.4f} {s['clip']:7.2f} {lp:>7s}")
    print(f'saved -> {out_path}', file=sys.stderr)


if __name__ == '__main__':
    main()
