"""Freeze refresh schedules from calibration traces (optimal under the median teacher-trajectory cost).

Each method gets a schedule tuned on its own cost (``diff`` for the proposed method, ``fcache`` for the full-output
cache), so the cache baseline is not handicapped by the proposed method's schedule.

  python scripts/calibrate_schedule.py --costs runs/diag_qwen21_f4/cost_median_aligned.npz \
      --base-config configs/qwenimage21_2048.json --m 6 8 10 12 --out configs/qwenimage21_2048_calibrated.json
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts._common import write_json
from sarcache.schedules import dp_refresh, schedule_cost, uniform_refresh


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--costs", required=True)
    ap.add_argument("--base-config", required=True)
    ap.add_argument("--m", type=int, nargs="+", default=[6, 8, 10, 12])
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    costs = np.load(args.costs)
    base = json.loads(Path(args.base_config).read_text(encoding="utf-8"))
    factor, mode = base.get("factor", 4), base.get("coarse_mode", "aligned")
    methods = [{"name": "full", "predictor": "exact"}]
    table = []
    for m in args.m:
        s_diff = dp_refresh(costs["diff"], m)
        s_fc = dp_refresh(costs["fcache"], m)
        uni = uniform_refresh(costs["diff"].shape[0], m)
        methods += [
            {"name": f"xres_dp_m{m}", "predictor": "diff", "factor": factor, "coarse_mode": mode, "refresh": s_diff},
            {"name": f"fcache_dp_m{m}", "predictor": "fcache", "refresh": s_fc},
            {"name": f"stale_g_dp_m{m}", "predictor": "stale_g", "factor": factor, "coarse_mode": mode,
             "refresh": s_diff},
        ]
        table.append({"m": m, "diff_schedule": s_diff, "diff_cost": schedule_cost(costs["diff"], s_diff),
                      "diff_cost_uniform": schedule_cost(costs["diff"], uni), "fcache_schedule": s_fc,
                      "fcache_cost": schedule_cost(costs["fcache"], s_fc)})
        print(f"m={m}: diff {s_diff} (cost {table[-1]['diff_cost']:.3f} vs uniform "
              f"{table[-1]['diff_cost_uniform']:.3f}); fcache {s_fc}")
    cfg = {**base, "methods": methods, "calibration": {"costs": args.costs, "table": table}}
    write_json(Path(args.out), cfg)


if __name__ == "__main__":
    main()
