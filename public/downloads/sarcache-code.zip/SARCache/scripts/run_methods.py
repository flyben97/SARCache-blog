"""Closed-loop runs of every configured method on the same initial noise (days 5-6 and Sec. 8).

For each (prompt, seed) the ``exact`` baseline runs first; every other method records wall time split into
text/latent preparation, sampling (full / coarse / ops) and VAE decode, forward counts, and trajectory fidelity
against the baseline (latent relative L2, pixel PSNR). Images are saved for GenEval / DPG / OCR evaluation, which
run with their official tools on ``images/``.

  python scripts/run_methods.py --config configs/qwenimage21_2048.json --model-path /data/Qwen-Image-2.1 \
      --prompts data/dev_prompts.tsv --seeds 0 --out runs/dev_qwen21_f4
"""
from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import torch

import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts._common import add_model_args, load_config, read_prompts, write_json
from sarcache.pipelines import build_request, load_pipeline, public_meta, sigmas_for
from sarcache.sampler import sample
from sarcache.timing import Timer


def psnr(a, b) -> float:
    x = np.asarray(a, dtype=np.float64)
    y = np.asarray(b, dtype=np.float64)
    mse = float(np.mean((x - y) ** 2))
    return float("inf") if mse == 0 else 10.0 * np.log10(255.0 ** 2 / mse)


def sync():
    if torch.cuda.is_available():
        torch.cuda.synchronize()


@torch.no_grad()
def main():
    ap = add_model_args(argparse.ArgumentParser(description=__doc__))
    prompts = ap.add_mutually_exclusive_group(required=True)
    prompts.add_argument("--prompts", default=None)
    prompts.add_argument("--prompt", default=None)
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--methods", nargs="*", default=None, help="subset of method names")
    ap.add_argument("--warmup", type=int, default=1)
    args = ap.parse_args()
    cfg = load_config(args.config)
    kind, n = cfg["model"], cfg["num_steps"]
    methods = [m for m in cfg["methods"] if not args.methods or m.name in args.methods]
    if not methods or (methods[0].predictor != "exact"
                       and os.environ.get("RUN_METHODS_ALLOW_NO_FULL") != "1"):
        raise SystemExit("the first configured method must be the exact baseline"
                         " (set RUN_METHODS_ALLOW_NO_FULL=1 for reference-free supplement runs)")
    rows = read_prompts(args.prompts, args.limit) if args.prompts else [{"id": "p0", "category": "adhoc",
                                                                         "prompt": args.prompt}]
    if not rows:
        ap.error("no prompts found")
    out = Path(args.out)
    (out / "images").mkdir(parents=True, exist_ok=True)
    pipe = load_pipeline(kind, args.model_path, args.dtype, args.device, args.offload,
                         local_files_only=not args.allow_download)

    def run(row, seed, method):
        sync()
        t0 = time.perf_counter()
        req = build_request(pipe, kind, row["prompt"], height=cfg["height"], width=cfg["width"], num_steps=n,
                            seed=seed, cfg=cfg.get("cfg"), coarse_positions=cfg.get("coarse_positions", "native"))
        sigmas = req.sigmas if not method.num_steps else sigmas_for(pipe, kind, req.meta, method.num_steps)
        sync()
        t1 = time.perf_counter()
        res = sample(req.adapter, req.x_init, sigmas, method, timer=Timer(True, args.device), record=True)
        sync()
        t2 = time.perf_counter()
        image = req.decode(res.latents)[0]
        sync()
        t3 = time.perf_counter()
        return req, res, image, {"prepare_s": t1 - t0, "sample_s": t2 - t1, "decode_s": t3 - t2, "total_s": t3 - t0}

    for _ in range(args.warmup):
        run(rows[0], args.seeds[0], methods[0])
    torch.cuda.reset_peak_memory_stats() if torch.cuda.is_available() else None
    log = open(out / "records.jsonl", "a", encoding="utf-8")
    for row in rows:
        for seed in args.seeds:
            base_lat = base_img = None
            for method in methods:
                req, res, image, secs = run(row, seed, method)
                name = f"{row['id']}_s{seed}_{method.name}.png"
                image.save(out / "images" / name)
                rec = {"id": row["id"], "category": row.get("category"), "prompt": row["prompt"],
                       "target_text": row.get("target_text"), "seed": seed, "method": method.to_dict(),
                       "refresh": res.refresh, "counts": res.counts, "timing": res.timing, "wall": secs,
                       "steps": res.steps,
                       "image": f"images/{name}", "meta": public_meta(req.meta)}
                if base_lat is None:
                    base_lat, base_img, base_total = res.latents.float(), image, secs["total_s"]
                else:
                    lat = res.latents.float()
                    rec["fidelity"] = {"latent_rel_l2": float((lat - base_lat).norm() / base_lat.norm()),
                                       "psnr_vs_full": psnr(image, base_img)}
                    rec["speedup_vs_full"] = base_total / secs["total_s"]
                log.write(json.dumps(rec, ensure_ascii=False) + "\n")
                log.flush()
                fid = rec.get("fidelity", {})
                print(f"{row['id']} s{seed} {method.name:18s} total={secs['total_s']:.2f}s "
                      f"full={res.counts['full']} coarse={res.counts['coarse']} "
                      f"speedup={rec.get('speedup_vs_full', 1.0):.2f}x psnr={fid.get('psnr_vs_full', float('inf')):.2f}",
                      flush=True)
    log.close()
    if torch.cuda.is_available():
        write_json(out / "memory.json", {"peak_memory_gb": torch.cuda.max_memory_allocated() / 2**30})


if __name__ == "__main__":
    main()
