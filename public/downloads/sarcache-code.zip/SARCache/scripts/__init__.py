"""Command-line experiment helpers for XResCache."""
