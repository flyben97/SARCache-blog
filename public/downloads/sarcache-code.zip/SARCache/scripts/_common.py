"""Shared helpers for the experiment scripts (run from the project root or anywhere)."""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sarcache.sampler import Method  # noqa: E402


def load_config(path: str | Path) -> dict:
    cfg = json.loads(Path(path).read_text(encoding="utf-8"))
    cfg["methods"] = [Method.from_dict(m) for m in cfg.get("methods", [])]
    return cfg


def read_prompts(path: str | Path, limit: int | None = None) -> list[dict]:
    """TSV with columns ``id``, ``category``, ``prompt`` (and optional ``target_text`` for OCR/CER)."""
    with open(path, encoding="utf-8") as fh:
        rows = [r for r in csv.DictReader(fh, delimiter="\t") if r.get("prompt")]
    return rows[:limit] if limit else rows


def add_model_args(ap):
    ap.add_argument("--config", required=True, help="configs/*.json")
    ap.add_argument("--model-path", required=True, help="local diffusers checkpoint directory or hub id")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--dtype", default="bfloat16", choices=["bfloat16", "float16", "float32"])
    ap.add_argument("--offload", action="store_true", help="enable_model_cpu_offload (not for latency numbers)")
    ap.add_argument("--allow-download", action="store_true", help="allow Hub downloads; default uses local files only")
    ap.add_argument("--out", required=True)
    return ap


def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
