"""Check that the ``exact`` method reproduces the official diffusers pipeline on real weights (proposal Sec. 5.2,
"first check the full path against the official implementation, then attach the coarse path").

  python scripts/parity_check.py --config configs/qwenimage21_2048.json --model-path /data/Qwen-Image-2.1 \
      --out runs/parity_qwen21.json --steps 8
"""
from __future__ import annotations

import argparse
from pathlib import Path

# Initialise NumPy before Torch for Conda environments using Intel MKL.
import numpy as np  # noqa: F401
import torch

import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts._common import add_model_args, load_config, write_json
from sarcache.pipelines import build_request, load_pipeline
from sarcache.sampler import Method, sample


@torch.no_grad()
def main():
    ap = add_model_args(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--prompt", default="A red bicycle leaning on a blue wall, a sign reads \"CITY BIKES\"")
    ap.add_argument("--steps", type=int, default=8)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--atol", type=float, default=1e-5)
    ap.add_argument("--rtol", type=float, default=1e-5)
    args = ap.parse_args()
    cfg = load_config(args.config)
    kind = cfg["model"]
    if kind == "sana":
        raise SystemExit("SanaPipeline samples with DPM-Solver by default; parity is defined for Euler pipelines")
    pipe = load_pipeline(kind, args.model_path, args.dtype, args.device, args.offload,
                         local_files_only=not args.allow_download)
    kw = dict(height=cfg["height"], width=cfg["width"], num_inference_steps=args.steps, output_type="latent",
              generator=torch.Generator(device=pipe._execution_device).manual_seed(args.seed))
    if kind == "flux":
        kw["guidance_scale"] = 3.5 if cfg.get("cfg") is None else cfg["cfg"]
    elif kind == "qwenimage21":
        kw["true_cfg_scale"] = 1.0 if cfg.get("cfg") is None else cfg["cfg"]
        if kw["true_cfg_scale"] > 1:
            kw["negative_prompt"] = " "
    official = pipe(prompt=args.prompt, **kw).images
    req = build_request(pipe, kind, args.prompt, height=cfg["height"], width=cfg["width"], num_steps=args.steps,
                        seed=args.seed, cfg=cfg.get("cfg"))
    ours = req.meta["_pack"](sample(req.adapter, req.x_init, req.sigmas, Method(predictor="exact")).latents)
    diff = (ours.float() - official.float())
    passed = torch.allclose(ours.float(), official.float(), atol=args.atol, rtol=args.rtol)
    rep = {"status": "passed" if passed else "failed", "atol": args.atol, "rtol": args.rtol,
           "max_abs": float(diff.abs().max()), "rel_l2": float(diff.norm() / official.float().norm()),
           "steps": args.steps, "shape": list(official.shape)}
    print(rep)
    write_json(Path(args.out), rep)
    if not passed:
        raise SystemExit("pipeline parity failed; see report")


if __name__ == "__main__":
    main()
