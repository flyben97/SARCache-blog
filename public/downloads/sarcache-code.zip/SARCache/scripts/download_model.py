"""Explicit, optional Qwen-Image-2.1 download; --dry-run never contacts the Hub."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

DEFAULT_REPO = "Qwen/Qwen-Image-2.1"
DEFAULT_DIR = Path(__file__).resolve().parents[1] / "models" / "Qwen-Image-2.1"


def download_model(repo_id=DEFAULT_REPO, local_dir=DEFAULT_DIR, revision="main", *, dry_run=False):
    destination = Path(local_dir).expanduser().resolve()
    plan = {"repo_id": repo_id, "revision": revision, "local_dir": str(destination)}
    if dry_run:
        return {"status": "dry_run", **plan}
    from huggingface_hub import snapshot_download

    # Download the complete diffusers repository, including processor and text encoder.
    # Hub handles cache reuse/resume and HF_TOKEN authentication itself.
    path = snapshot_download(**plan)
    return {"status": "downloaded", **plan, "path": str(path)}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo-id", default=DEFAULT_REPO)
    ap.add_argument("--local-dir", type=Path, default=DEFAULT_DIR)
    ap.add_argument("--revision", default="main", help="Hub branch, tag, or commit hash")
    ap.add_argument("--dry-run", action="store_true", help="print plan only; no network or directory creation")
    args = ap.parse_args(argv)
    print(json.dumps(download_model(args.repo_id, args.local_dir, args.revision, dry_run=args.dry_run),
                     indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
