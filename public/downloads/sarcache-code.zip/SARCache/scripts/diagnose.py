"""Days 3-4: record F, G, D along full teacher trajectories and test whether D is easier to carry than F.

Example (32 calibration prompts x 2 seeds):
  python scripts/diagnose.py --config configs/qwenimage21_2048.json --model-path /data/Qwen-Image-2.1 \
      --prompts data/calibration_prompts.tsv --seeds 0 1 --out runs/diag_qwen21_f4
Writes one ``trace_*.npz`` per (prompt, seed, coarse mode), ``summary_<mode>.json`` with the continue gate, and the
median cost matrices used by ``calibrate_schedule.py``.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts._common import add_model_args, load_config, read_prompts, write_json
from sarcache.diagnostics import cost_matrices, summarize, teacher_trace, trace_errors
from sarcache.pipelines import build_request, load_pipeline


@torch.no_grad()
def main():
    ap = add_model_args(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--prompts", required=True)
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1])
    ap.add_argument("--coarse-modes", nargs="+", default=["aligned"], choices=["aligned", "naive", "subsample"])
    ap.add_argument("--intervals", type=int, nargs="+", default=[2, 4, 6, 8])
    args = ap.parse_args()
    cfg = load_config(args.config)
    kind, factor = cfg["model"], cfg.get("factor", 4)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    pipe = load_pipeline(kind, args.model_path, args.dtype, args.device, args.offload,
                         local_files_only=not args.allow_download)
    prompts = read_prompts(args.prompts, args.limit)
    by_mode: dict[str, list] = {m: [] for m in args.coarse_modes}
    costs: dict[str, dict[str, list]] = {m: {"diff": [], "fcache": []} for m in args.coarse_modes}
    for row in prompts:
        for seed in args.seeds:
            req = build_request(pipe, kind, row["prompt"], height=cfg["height"], width=cfg["width"],
                                num_steps=cfg["num_steps"], seed=seed, cfg=cfg.get("cfg"),
                                coarse_positions=cfg.get("coarse_positions", "native"))
            for mode in args.coarse_modes:
                tr = teacher_trace(req.adapter, req.x_init, req.sigmas, factor, mode)
                err = trace_errors(tr, args.intervals, factor)
                cm = cost_matrices(tr)
                by_mode[mode].append(err)
                for k in cm:
                    costs[mode][k].append(cm[k])
                np.savez_compressed(out / f"trace_{row['id']}_s{seed}_{mode}.npz",
                                    **{k: v for k, v in err.items() if k.startswith("E_")},
                                    intervals=np.array(err["intervals"]), sigmas=np.array(err["sigmas"]),
                                    cost_diff=cm["diff"], cost_fcache=cm["fcache"])
                e = err["E_D"][:, 1] if len(args.intervals) > 1 else err["E_D"][:, 0]
                print(f"{row['id']} seed={seed} {mode}: median E_D(k={args.intervals[min(1, len(args.intervals)-1)]})"
                      f"={np.nanmedian(e):.4f}", flush=True)
    for mode in args.coarse_modes:
        report = summarize(by_mode[mode])
        report.update(config=args.config, factor=factor, coarse_mode=mode, traces=len(by_mode[mode]))
        write_json(out / f"summary_{mode}.json", report)
        np.savez_compressed(out / f"cost_median_{mode}.npz",
                            diff=np.median(np.stack(costs[mode]["diff"]), 0),
                            fcache=np.median(np.stack(costs[mode]["fcache"]), 0))
        print(json.dumps({k: {m: v[m] for m in ("E_D_median", "E_F_median", "fraction_improved",
                                                 "median_relative_improvement_vs_strongest", "gate_pass")}
                          for k, v in report["per_interval"].items()}, indent=1))


if __name__ == "__main__":
    main()
