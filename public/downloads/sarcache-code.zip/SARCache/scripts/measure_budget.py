"""Day 1: measure p, alpha, o and peak memory on one exclusive GPU, then the largest m meeting the target speedup.

Example:
  python scripts/measure_budget.py --config configs/qwenimage21_2048.json --model-path /data/Qwen-Image-2.1 \
      --out runs/budget_qwen21_2048.json --factors 2 4
"""
from __future__ import annotations

import argparse
import statistics
import time
from pathlib import Path

# Initialise NumPy before Torch for Conda environments using Intel MKL.
import numpy as np  # noqa: F401
import torch

import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts._common import add_model_args, load_config, write_json
from sarcache.budget import Measured
from sarcache.operators import CoarseView, pool, unpool
from sarcache.pipelines import build_request, load_pipeline, public_meta


def timed(fn, repeat: int, warmup: int = 2) -> float:
    for _ in range(warmup):
        fn()
    vals = []
    for _ in range(repeat):
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        fn()
        torch.cuda.synchronize()
        vals.append(time.perf_counter() - t0)
    return statistics.median(vals)


@torch.no_grad()
def main():
    ap = add_model_args(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--prompt", default="A neon shop sign that reads \"OPEN 24 HOURS\", rainy night street")
    ap.add_argument("--factors", type=int, nargs="+", default=None)
    ap.add_argument("--repeat", type=int, default=5)
    ap.add_argument("--target", type=float, default=4.0)
    args = ap.parse_args()
    if torch.device(args.device).type != "cuda" or not torch.cuda.is_available():
        ap.error("budget measurements require CUDA")
    if args.repeat < 1:
        ap.error("--repeat must be positive")
    cfg = load_config(args.config)
    kind, n = cfg["model"], cfg["num_steps"]
    factors = args.factors or [cfg.get("factor", 4)]
    pipe = load_pipeline(kind, args.model_path, args.dtype, args.device, args.offload,
                         local_files_only=not args.allow_download)
    torch.cuda.reset_peak_memory_stats()

    build = lambda: build_request(pipe, kind, args.prompt, height=cfg["height"], width=cfg["width"], num_steps=n,
                                  seed=0, cfg=cfg.get("cfg"), coarse_positions=cfg.get("coarse_positions", "native"))
    t_build = timed(build, args.repeat, warmup=1)
    req = build()
    model, x = req.adapter, req.x_init
    sigma = float(req.sigmas[n // 2])

    def first_full():
        if hasattr(model, "begin"):
            model.begin()
        model(x, float(req.sigmas[0]), "full", 1)

    t_first = timed(first_full, args.repeat, warmup=1)
    first_full()
    t_full = timed(lambda: model(x, sigma, "full", 1), args.repeat)
    coarse, ops = {}, {}
    for f in factors:
        view = CoarseView(f, cfg.get("coarse_mode", "aligned"))
        coarse[f] = timed(lambda: view(lambda y, t: model(y, t, "coarse", f), x, sigma), args.repeat)
        d = torch.zeros_like(x, dtype=torch.float32)
        ops[f] = timed(lambda: (unpool(pool(x, f), f).float() + d, x.float() + 0.01 * d), args.repeat)
    lat = x.to(pipe.vae.dtype) if hasattr(pipe, "vae") else x
    t_decode = timed(lambda: req.decode(lat), max(2, args.repeat // 2), warmup=1)

    report = {"config": args.config, "model_path": args.model_path, "meta": public_meta(req.meta),
              "gpu": torch.cuda.get_device_name(), "seconds": {
                  "build_request_incl_text_encoder": t_build, "first_full_forward_incl_prefix": t_first,
                  "full_forward": t_full, "decode": t_decode,
                  **{f"coarse_forward_f{f}": v for f, v in coarse.items()},
                  **{f"transform_ops_f{f}": v for f, v in ops.items()}},
              "peak_memory_gb": torch.cuda.max_memory_allocated() / 2**30, "budgets": {}}
    fixed = t_build + t_decode + (t_first - t_full)
    for f in factors:
        m = Measured(fixed_s=fixed, full_forward_s=t_full, coarse_forward_s=coarse[f], overhead_per_step_s=ops[f],
                     num_steps=n)
        report["budgets"][f"f{f}"] = m.report(args.target)
        r = report["budgets"][f"f{f}"]
        print(f"factor {f}: p={r['p']:.3f} alpha={r['alpha']:.3f} o={r['o']:.3f} "
              f"m_max(<={args.target}x)={r['m_max_real']:.2f}  speedup(m=8)={r['predicted_speedup']['8']:.2f}x")
    write_json(Path(args.out), report)


if __name__ == "__main__":
    main()
