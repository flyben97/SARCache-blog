"""Smoke test: scientific invariants of the method and integration with the real diffusers model classes.

Fixture numbers (oracle errors, tiny random models) are not evidence about Qwen-Image-2.1 or FLUX quality; they
check that the implementation computes what the proposal specifies. Real weights are optional:
  python smoke_test.py                                        # CPU invariants + tiny models (+ CUDA bf16 if present)
  python smoke_test.py --real-model sana=/mnt/e/models/Sana_600M_1024px_diffusers
"""
from __future__ import annotations

import argparse
import itertools
import json
import os
import platform
import py_compile
import subprocess
import sys
import tempfile
import time
import traceback
from contextlib import ExitStack
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from sarcache.adapters.oracle import SeparableGMMOracle  # noqa: E402
from sarcache.budget import Measured, max_full_forwards, time_ratio  # noqa: E402
from sarcache.diagnostics import cost_matrices, summarize, teacher_trace, trace_errors  # noqa: E402
from sarcache.operators import CoarseView, alignment, low_high_split, pool, sd3_shift, subsample, unpool  # noqa: E402
from sarcache.sampler import Method, sample  # noqa: E402
from sarcache.schedules import dp_refresh, schedule_cost, shifted_sigmas, uniform_refresh  # noqa: E402

CHECKS: list[dict] = []


def passed(name: str, **details):
    CHECKS.append({"name": name, "status": "passed", **details})
    print(f"PASS {name} {json.dumps(details, ensure_ascii=False) if details else ''}", flush=True)


def skipped(name: str, reason: str):
    CHECKS.append({"name": name, "status": "skipped", "reason": reason})
    print(f"SKIP {name}: {reason}", flush=True)


def rel(a: torch.Tensor, b: torch.Tensor) -> float:
    return float((a - b).double().norm() / (b.double().norm() + 1e-30))


# ----------------------------------------------------------------------------------------------- CPU invariants
def check_operators():
    g = torch.Generator().manual_seed(0)
    x = torch.randn(2, 3, 16, 16, dtype=torch.float64, generator=g)
    y = torch.randn(2, 3, 4, 4, dtype=torch.float64, generator=g)
    b = torch.randn_like(x)
    assert torch.allclose(pool(unpool(y, 4), 4), y)
    pr = lambda t: unpool(pool(t, 4), 4)
    assert torch.allclose(pr(pr(x)), pr(x))
    assert abs(float((pr(x) * b).sum() - (x * pr(b)).sum())) < 1e-9
    lo, hi = low_high_split(x, 4)
    assert abs(float((lo * hi).sum())) < 1e-9 and torch.allclose(lo + hi, x)
    assert subsample(x, 4, (1, 2)).shape == (2, 3, 4, 4) and torch.equal(subsample(x, 4, (1, 2))[..., 0, 0], x[..., 1, 2])
    passed("operators_RP_identity_projector_split")


def check_noise_alignment():
    g = torch.Generator().manual_seed(1)
    x0 = torch.randn(1, 4, 16, 16, dtype=torch.float64, generator=g)
    eps = torch.randn(4000, 4, 16, 16, dtype=torch.float64, generator=g)
    out = {}
    for sigma in (0.9, 0.5, 0.2):
        s, a, tau = alignment(sigma, 4)
        x = (1 - sigma) * x0 + sigma * eps
        y = pool(x, 4) / a
        resid = y - (1 - tau) * pool(x0, 4)
        std_aligned = float(resid.std())
        std_naive = float((pool(x, 4) - (1 - sigma) * pool(x0, 4)).std())
        assert abs(std_aligned / tau - 1) < 0.02, (sigma, std_aligned, tau)
        assert abs(std_naive / (s * sigma) - 1) < 0.02
        out[str(sigma)] = {"tau": round(tau, 4), "aligned_noise_std": round(std_aligned, 4),
                           "naive_noise_std": round(std_naive, 4), "naive_timestep": sigma}
    passed("noise_alignment_unit_variance_interpolant", **out)


def check_sd3_equivalence():
    worst = 0.0
    for f in (2, 3, 4, 8):
        for sigma in np.linspace(0.01, 0.99, 25):
            _, _, tau = alignment(float(sigma), f)
            worst = max(worst, abs(sd3_shift(tau, float(f)) - sigma))
    assert worst < 1e-12
    passed("tau_equals_inverse_sd3_resolution_shift", max_abs=worst)


def make_oracle(**kw):
    return SeparableGMMOracle.random(channels=4, coarse_hw=(4, 4), components=6, factor=4, lam_z=0.25,
                                     lam_h=0.05, seed=1, **kw)


def check_chain_rule():
    orc = make_oracle()
    g = torch.Generator().manual_seed(2)
    x0 = orc.sample_x0(3, g)
    eps = torch.randn(x0.shape, dtype=torch.float64, generator=g)
    res = {}
    for sigma in (0.95, 0.6, 0.3, 0.05):
        x = (1 - sigma) * x0 + sigma * eps
        prf = unpool(pool(orc(x, sigma), 4), 4)
        errs = {m: rel(CoarseView(4, m)(lambda y, t: orc(y, t, "coarse", 4), x, sigma), prf)
                for m in ("aligned", "naive", "subsample")}
        assert errs["aligned"] < 1e-10 and errs["naive"] > 1e-2 and errs["subsample"] > 1e-2, errs
        res[str(sigma)] = {k: float(f"{v:.3e}") for k, v in errs.items()}
    bad = SeparableGMMOracle.random(channels=4, coarse_hw=(4, 4), components=6, factor=4, lam_z=0.25, lam_h=0.05,
                                    seed=1, coarse_lam_z=0.4, coarse_mean_shift=0.1)
    x = 0.5 * x0 + 0.5 * eps
    mismatch = rel(CoarseView(4)(lambda y, t: bad(y, t, "coarse", 4), x, 0.5), unpool(pool(bad(x, 0.5), 4), 4))
    assert mismatch > 1e-3
    passed("chain_rule_G_equals_PRF_on_separable_oracle", rel_err=res, coarse_prior_mismatch_rel_err=mismatch)


def check_method_identities():
    orc = make_oracle()
    sig = shifted_sigmas(20, 3.0)
    x = torch.randn(2, 4, 16, 16, dtype=torch.float64, generator=torch.Generator().manual_seed(3))
    full = sample(orc, x, sig, Method(predictor="exact"))
    every = sample(orc, x, sig, Method(predictor="diff", refresh=list(range(20))))
    assert torch.equal(every.latents, full.latents)
    fc = sample(orc, x, sig, Method(predictor="fcache", num_full=5))
    st = sample(orc, x, sig, Method(predictor="stale_g", num_full=5))
    df = sample(orc, x, sig, Method(predictor="diff", num_full=5))
    assert rel(st.latents, fc.latents) < 1e-12
    assert df.counts == {"full": 5, "coarse": 20} and fc.counts == {"full": 5, "coarse": 0}
    assert st.counts == {"full": 5, "coarse": 5} and full.counts == {"full": 20, "coarse": 0}
    try:
        sample(orc, x, sig, Method(predictor="diff", refresh=[3, 9]))
        raise AssertionError("a schedule without step 0 must be rejected")
    except ValueError:
        pass
    m = Method(name="z", predictor="diff", factor=2, refresh=[0, 4], coarse_positions="aligned")
    assert Method.from_dict(json.loads(json.dumps(m.to_dict()))) == m
    passed("method_identities", stale_g_vs_fcache=rel(st.latents, fc.latents))


def check_closed_loop():
    orc = make_oracle()
    sig = shifted_sigmas(40, 3.0)
    x = torch.randn(4, 4, 16, 16, dtype=torch.float64, generator=torch.Generator().manual_seed(5))
    ref = sample(orc, x, sig, Method(predictor="exact")).latents
    specs = {"diff": {}, "fcache": {}, "stale_g": {}, "coarse_only": {}, "linear_f": {}, "diff_linear": {},
             "diff_naive": {"coarse_mode": "naive"}, "diff_subsample": {"coarse_mode": "subsample"}}
    err = {}
    for name, extra in specs.items():
        pred = name.split("_naive")[0].split("_subsample")[0]
        r = sample(orc, x, sig, Method(name=name, predictor=pred, num_full=8, factor=4, **extra))
        err[name] = round(rel(r.latents, ref), 4)
    assert err["diff"] < err["fcache"], err
    assert err["diff"] < err["diff_naive"] and err["diff"] < err["coarse_only"], err
    assert abs(err["stale_g"] - err["fcache"]) < 1e-9, err
    # spec identities: tau=inf degenerates to diff on the same init refresh; tau=0 with full budget == exact
    sp_inf = sample(orc, x, sig, Method(name="spec_inf", predictor="spec", num_full=8, factor=4,
                                        refresh=[0, 1], spec_threshold=float("inf")))
    df_init = sample(orc, x, sig, Method(name="diff_init", predictor="diff", factor=4, refresh=[0, 1]))
    assert rel(sp_inf.latents, df_init.latents) < 1e-9, "spec(tau=inf) != diff([0,1])"
    sp_zero = sample(orc, x, sig, Method(name="spec_zero", predictor="spec", num_full=40, factor=4,
                                         refresh=[0, 1], spec_threshold=-1.0))
    assert rel(sp_zero.latents, ref) < 1e-9, "spec(tau=-1, budget=40) != exact"
    passed("closed_loop_oracle_m8_of_40", rel_err_vs_full=err,
           note="linear_f can beat zero-order diff even with exact G; the gate must compare matched orders")


def check_diagnostics():
    orc = make_oracle()
    sig = shifted_sigmas(24, 3.0)
    errs, costs = [], []
    for seed in range(3):
        x = torch.randn(1, 4, 16, 16, dtype=torch.float64, generator=torch.Generator().manual_seed(10 + seed))
        tr = teacher_trace(orc, x, sig, factor=4)
        e = trace_errors(tr, (2, 4), factor=4)
        errs.append(e)
        costs.append(cost_matrices(tr)["diff"])
        assert np.nanmax(e["E_D_low"]) < 1e-9, "aligned difference must have no block-constant part here"
        mask = torch.zeros(1, 1, 16, 16, dtype=torch.float64)
        mask[..., :8, :8] = 1
        em = trace_errors(tr, (4,), factor=4, mask=mask)
        assert np.isfinite(np.nanmedian(em["E_D"]))
    rep = summarize(errs)
    k4 = rep["per_interval"]["4"]
    assert k4["E_D_median"] < k4["E_F_median"]
    for key in ("fraction_improved", "median_relative_improvement_vs_strongest", "gate_pass", "stages"):
        assert key in k4
    json.loads(json.dumps(rep))
    s = dp_refresh(np.median(np.stack(costs), 0), 6)
    assert s[0] == 0 and len(s) == 6
    passed("diagnostics_teacher_trace_and_gate", k4={k: k4[k] for k in (
        "E_D_median", "E_Dlin_median", "E_F_median", "E_Flin_median", "E_Fcheb_median", "fraction_improved",
        "gate_pass")}, dp_schedule_m6=s)


def check_budget():
    table = [((0.05, 0.04, 0.01, 6), 0.2405), ((0.08, 0.04, 0.01, 6), 0.2648), ((0.05, 0.10, 0.01, 6), 0.2975)]
    for args, want in table:
        assert abs(time_ratio(*args) - want) < 5e-5
    assert abs(max_full_forwards(0.05, 0.04, 0.01) - 6.4) < 1e-9
    assert max_full_forwards(0.05, 0.16, 0.01) < 2 and max_full_forwards(0.10, 0.16, 0.01) < 0
    m = Measured(fixed_s=1.0, full_forward_s=0.5, coarse_forward_s=0.04, overhead_per_step_s=0.002)
    r = m.report()
    assert abs(r["p"] - 1.0 / 21.0) < 1e-12 and abs(r["alpha"] - 0.08) < 1e-12
    passed("budget_matches_proposal_table", m_max_alpha_0_08=round(max_full_forwards(0.05, 0.08, 0.01), 2),
           m_max_alpha_0_16=round(max_full_forwards(0.05, 0.16, 0.01), 2))


def check_dp():
    rng = np.random.default_rng(0)
    for n, m in itertools.product((7, 10), (1, 2, 3, 4)):
        c = np.triu(rng.random((n, n)), 1)
        best = min(schedule_cost(c, (0,) + comb) for comb in itertools.combinations(range(1, n), m - 1))
        assert abs(schedule_cost(c, dp_refresh(c, m)) - best) < 1e-12
    u = uniform_refresh(40, 8)
    assert u == [0, 5, 10, 15, 20, 25, 30, 35] and uniform_refresh(40, 40) == list(range(40))
    passed("dp_refresh_matches_brute_force")


def check_repo_files():
    from scripts._common import load_config, read_prompts

    for cfg in sorted((ROOT / "configs").glob("*.json")):
        c = load_config(cfg)
        assert c["methods"][0].predictor == "exact"
        for m in c["methods"]:
            m.refresh_steps(m.num_steps or c["num_steps"])
    cal, dev = read_prompts(ROOT / "data/calibration_prompts.tsv"), read_prompts(ROOT / "data/dev_prompts.tsv")
    assert len(cal) == 32 and len(dev) == 64
    assert not {r["prompt"] for r in cal} & {r["prompt"] for r in dev}
    cats = sorted({r["category"] for r in cal + dev})
    for script in (ROOT / "scripts").glob("*.py"):
        py_compile.compile(str(script), doraise=True)
    passed("configs_prompts_scripts", categories=cats)


def check_download_entrypoint():
    from scripts.download_model import DEFAULT_REPO, download_model

    with tempfile.TemporaryDirectory() as tmp:
        destination = Path(tmp) / "weights"
        # A dry run must work even if huggingface_hub is not installed.
        with patch.dict(sys.modules, {"huggingface_hub": None}):
            plan = download_model(local_dir=destination, dry_run=True)
        assert plan["status"] == "dry_run" and plan["repo_id"] == DEFAULT_REPO
        assert not destination.exists()
        fake_hub = MagicMock()
        fake_hub.snapshot_download.return_value = str(destination)
        with patch.dict(sys.modules, {"huggingface_hub": fake_hub}):
            result = download_model(local_dir=destination, revision="test-revision")
        fake_hub.snapshot_download.assert_called_once_with(
            repo_id=DEFAULT_REPO, revision="test-revision", local_dir=str(destination))
        assert result["status"] == "downloaded"
        cli = subprocess.run([sys.executable, str(ROOT / "scripts/download_model.py"), "--dry-run",
                              "--local-dir", str(destination)], cwd=tmp, capture_output=True, text=True,
                             check=True, timeout=30)
        assert json.loads(cli.stdout)["status"] == "dry_run" and not destination.exists()
    passed("model_download_dry_run_and_mocked_download")


def check_cli_entrypoints():
    for script in sorted((ROOT / "scripts").glob("*.py")):
        if script.name.startswith("_"):
            continue
        result = subprocess.run([sys.executable, str(script), "--help"], cwd=tempfile.gettempdir(),
                                capture_output=True, text=True, timeout=30)
        assert result.returncode == 0, f"{script.name}: {result.stderr}"
    passed("cli_help_from_outside_project")


def check_local_loading():
    from sarcache.pipelines import load_pipeline

    factory = MagicMock()
    with patch("sarcache.pipelines.pipeline_class", return_value=factory):
        load_pipeline("qwenimage21", "/missing/checkpoint", "float32", "cpu")
        factory.from_pretrained.assert_called_once_with(
            "/missing/checkpoint", torch_dtype=torch.float32, local_files_only=True)
        factory.reset_mock()
        load_pipeline("qwenimage21", "example/model", "float32", "cpu", local_files_only=False)
        assert factory.from_pretrained.call_args.kwargs["local_files_only"] is False
        factory.reset_mock()
        try:
            load_pipeline("qwenimage21", "unused", device="cpu", offload=True)
        except ValueError:
            pass
        else:
            raise AssertionError("CPU execution cannot use CUDA offload")
        factory.from_pretrained.assert_not_called()
    passed("pipeline_local_only_default_and_explicit_download_opt_in")


# ------------------------------------------------------------------------------------ tiny diffusers models
class _Tok:
    def encode(self, s):
        return [7]


class FakeProcessor:
    tokenizer = _Tok()

    def apply_chat_template(self, *args, **kwargs):
        return [[1, 2, 3]]


def tiny_qwen21(device="cpu", dtype=torch.float32):
    from diffusers import FlowMatchEulerDiscreteScheduler, QwenImage21Pipeline, QwenImage21Transformer2DModel

    torch.manual_seed(0)
    tr = QwenImage21Transformer2DModel(patch_size=1, in_channels=8, out_channels=8, num_layers=2,
                                       attention_head_dim=32, num_attention_heads=2, context_in_dim=24, mlp_ratio=2,
                                       axes_dims_rope=(8, 12, 12)).eval()
    for p in tr.parameters():
        torch.nn.init.normal_(p, std=0.05)
    tr = tr.to(device=device, dtype=dtype)
    sch = FlowMatchEulerDiscreteScheduler(use_dynamic_shifting=True, base_shift=0.5, max_shift=0.9,
                                          base_image_seq_len=256, max_image_seq_len=8192,
                                          time_shift_type="exponential")
    pipe = QwenImage21Pipeline(scheduler=sch, vae=None, text_encoder=None, processor=FakeProcessor(), transformer=tr)
    pipe.set_progress_bar_config(disable=True)
    return pipe


def check_qwen21(device="cpu", dtype=torch.float32, tag="cpu_fp32"):
    from sarcache.adapters.qwenimage21 import QwenImage21Adapter, aligned_rope, pack
    from sarcache.pipelines import build_request

    pipe = tiny_qwen21(device, dtype)
    tr = pipe.transformer
    g = torch.Generator().manual_seed(1)
    pe = torch.randn(1, 11, 24, generator=g).to(device, dtype)
    npe = torch.randn(1, 6, 24, generator=g).to(device, dtype)
    for cfg in (1.0, 3.0):
        kw = dict(prompt_embeds=pe, height=256, width=256, num_inference_steps=6, output_type="latent",
                  generator=torch.Generator(device).manual_seed(3), true_cfg_scale=cfg)
        emb = {"prompt_embeds": pe}
        if cfg > 1:
            kw["negative_prompt_embeds"] = npe
            emb["negative_prompt_embeds"] = npe
        official = pipe(**kw).images
        req = build_request(pipe, "qwenimage21", embeds=emb, height=256, width=256, num_steps=6, seed=3, cfg=cfg)
        ours = pack(sample(req.adapter, req.x_init, req.sigmas, Method(predictor="exact")).latents)
        diff = float((ours.float() - official.float()).abs().max())
        assert diff == 0.0, f"pipeline parity (cfg={cfg}) max diff {diff}"
    x = torch.randn(1, 8, 16, 16, generator=g).to(device, dtype)
    cached = QwenImage21Adapter(tr, pe, use_kv_cache=True)
    fresh = QwenImage21Adapter(tr, pe, use_kv_cache=False)
    cached(x, 0.9, "full", 1)
    view = CoarseView(4)
    g_c = view(lambda y, t: cached(y, t, "coarse", 4), x, 0.7)
    g_n = view(lambda y, t: fresh(y, t, "coarse", 4), x, 0.7)
    cache_err = float((g_c.float() - g_n.float()).abs().max() / g_n.float().abs().max())
    assert cache_err < (1e-5 if dtype == torch.float32 else 2e-2), cache_err
    r = sample(cached, x, req.sigmas, Method(predictor="diff", num_full=3, factor=4))
    assert torch.isfinite(r.latents.float()).all() and r.counts == {"full": 3, "coarse": 6}
    passed(f"qwenimage21_{tag}", official_pipeline_max_diff=0.0, coarse_shared_prefix_cache_rel_err=cache_err)


def check_qwen21_aligned_rope():
    from sarcache.adapters.qwenimage21 import aligned_positions, aligned_rope

    pipe = tiny_qwen21()
    tr = pipe.transformer
    rope = tr.pos_embed
    h = w = 4
    mask = torch.tensor([False] * 5 + [True] * (h * w))
    native = rope([(1, h, w)], mask, "cpu")
    with aligned_rope(tr, h, w, factor=3):
        aligned = rope([(1, h, w)], mask, "cpu")
    pos = aligned_positions(h, 3)
    assert pos.tolist() == [-5.0, -2.0, 1.0, 4.0]
    idx = pos.long()
    d0, d1, _ = rope.axes_dim
    a, b = d0 // 2, d0 // 2 + d1 // 2
    want_h = rope.freqs[1][idx][:, None, :].expand(h, w, -1).reshape(h * w, -1)
    want_w = rope.freqs[2][idx][None, :, :].expand(h, w, -1).reshape(h * w, -1)
    assert torch.allclose(aligned[5:, a:b], want_h, atol=1e-5) and torch.allclose(aligned[5:, b:], want_w, atol=1e-5)
    assert torch.equal(aligned[:, :a], native[:, :a]) and torch.equal(aligned[:5], native[:5])
    assert rope.forward.__func__ is type(rope).forward
    passed("qwenimage21_aligned_rope_matches_model_table")


def check_flux():
    from diffusers import FlowMatchEulerDiscreteScheduler, FluxPipeline, FluxTransformer2DModel

    from sarcache.adapters.flux import FluxAdapter, image_ids, pack
    from sarcache.pipelines import build_request

    torch.manual_seed(0)
    tr = FluxTransformer2DModel(patch_size=1, in_channels=16, num_layers=1, num_single_layers=1,
                                attention_head_dim=16, num_attention_heads=2, joint_attention_dim=32,
                                pooled_projection_dim=32, guidance_embeds=True, axes_dims_rope=(4, 6, 6)).eval()
    sch = FlowMatchEulerDiscreteScheduler(use_dynamic_shifting=True, base_shift=0.5, max_shift=1.15,
                                          base_image_seq_len=256, max_image_seq_len=4096,
                                          time_shift_type="exponential")
    pipe = FluxPipeline(scheduler=sch, vae=None, text_encoder=None, tokenizer=None, text_encoder_2=None,
                        tokenizer_2=None, transformer=tr)
    pipe.set_progress_bar_config(disable=True)
    g = torch.Generator().manual_seed(2)
    pe, pooled = torch.randn(1, 9, 32, generator=g), torch.randn(1, 32, generator=g)
    official = pipe(prompt_embeds=pe, pooled_prompt_embeds=pooled, height=128, width=128, num_inference_steps=5,
                    guidance_scale=3.5, generator=torch.Generator("cpu").manual_seed(4), output_type="latent").images
    req = build_request(pipe, "flux", embeds={"prompt_embeds": pe, "pooled_prompt_embeds": pooled}, height=128,
                        width=128, num_steps=5, seed=4, cfg=3.5)
    ours = pack(sample(req.adapter, req.x_init, req.sigmas, Method(predictor="exact")).latents)
    diff = float((ours - official).abs().max())
    assert diff == 0.0, diff
    ids = image_ids(2, 2, factor=2, aligned=True)
    assert ids[:, 1].tolist() == [0.5, 0.5, 2.5, 2.5] and ids[:, 2].tolist() == [0.5, 2.5, 0.5, 2.5]
    for pos in ("native", "aligned"):
        a = FluxAdapter(tr, pe, pooled, coarse_positions=pos)
        r = sample(a, req.x_init, req.sigmas, Method(predictor="diff", num_full=2, factor=2))
        assert torch.isfinite(r.latents).all()
    passed("flux_official_pipeline_parity_and_positions", official_pipeline_max_diff=diff)


def check_sana():
    from diffusers import SanaTransformer2DModel

    from sarcache.adapters.sana import SanaAdapter

    torch.manual_seed(0)
    tr = SanaTransformer2DModel(in_channels=8, out_channels=8, num_attention_heads=2, attention_head_dim=16,
                                num_layers=1, num_cross_attention_heads=2, cross_attention_head_dim=16,
                                cross_attention_dim=32, caption_channels=24, sample_size=16, patch_size=1).eval()
    g = torch.Generator().manual_seed(3)
    pe, npe = torch.randn(1, 7, 24, generator=g), torch.randn(1, 7, 24, generator=g)
    mask = torch.ones(1, 7, dtype=torch.long)
    a = SanaAdapter(tr, pe, mask, negative=(npe, mask), guidance_scale=4.5)
    x = torch.randn(1, 8, 16, 16, generator=g)
    sig = shifted_sigmas(6, 3.0)
    full = sample(a, x, sig, Method(predictor="exact"))
    r = sample(a, x, sig, Method(predictor="diff", num_full=2, factor=2))
    assert torch.isfinite(r.latents).all() and r.counts == {"full": 2, "coarse": 6}
    passed("sana_adapter_cfg_diff_sampler", rel_err_vs_full=rel(r.latents, full.latents))


# ----------------------------------------------------------------------------------------- optional real run
def real_model_run(spec: str, height: int | None, steps: int | None, out_dir: Path):
    from sarcache.pipelines import build_request, load_pipeline, public_meta
    from sarcache.timing import Timer

    kind, path = spec.split("=", 1)
    defaults = {"sana": (1024, 20, 2, 5), "qwenimage21": (1024, 20, 2, 5), "flux": (1024, 20, 2, 5)}
    h0, n0, f, m = defaults[kind]
    height, steps = height or h0, steps or n0
    m = min(m, steps)
    pipe = load_pipeline(kind, path, "bfloat16" if kind != "sana" else "float16", "cuda",
                         offload=kind != "sana")
    prompt = "A cozy cafe storefront with a sign that reads \"OPEN\", warm light, photorealistic"
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = {}
    base = None
    for method in (Method(name="full", predictor="exact"),
                   Method(name=f"xres_m{m}", predictor="diff", factor=f, num_full=m),
                   Method(name=f"fcache_m{m}", predictor="fcache", num_full=m)):
        req = build_request(pipe, kind, prompt, height=height, width=height, num_steps=steps, seed=0)
        t0 = time.perf_counter()
        res = sample(req.adapter, req.x_init, req.sigmas, method, timer=Timer(True, "cuda"))
        dt = time.perf_counter() - t0
        req.decode(res.latents)[0].save(out_dir / f"{kind}_{method.name}.png")
        lat = res.latents.float()
        base = lat if base is None else base
        rows[method.name] = {"sample_s": round(dt, 3), "counts": res.counts,
                             "latent_rel_l2_vs_full": rel(lat, base), "timing": res.timing}
    passed(f"real_model_{kind}", meta=public_meta(req.meta), runs=rows, images=str(out_dir))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--report", default=str(ROOT / "artifacts/smoke_report.json"))
    ap.add_argument("--real-model", default=None, help="kind=path, kind in {sana, qwenimage21, flux}")
    ap.add_argument("--real-height", type=int, default=None)
    ap.add_argument("--real-steps", type=int, default=None)
    ap.add_argument("--skip-diffusers", action="store_true")
    args = ap.parse_args()
    if sys.flags.optimize:
        ap.error("smoke tests use assertions; run without -O / PYTHONOPTIMIZE")
    if args.real_model:
        kind, separator, path = args.real_model.partition("=")
        if not separator or kind not in ("qwenimage21", "flux", "sana") or not Path(path).is_dir():
            ap.error("--real-model must be kind=/existing/local/checkpoint (no downloads)")
        if not torch.cuda.is_available():
            ap.error("--real-model requires CUDA")
    if any(v is not None and v <= 0 for v in (args.real_height, args.real_steps)):
        ap.error("real height and steps must be positive")
    CHECKS.clear()
    torch.set_num_threads(max(1, min(8, torch.get_num_threads())))
    started = time.perf_counter()
    status = "passed"
    current = "setup"
    error = None
    # Also reject raw socket connections: offline flags alone do not prove no downloads.
    with ExitStack() as stack:
        stack.enter_context(patch.dict(os.environ, {"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1"}))
        for target in ("socket.socket.connect", "socket.socket.connect_ex", "socket.create_connection"):
            stack.enter_context(patch(target, side_effect=RuntimeError("network disabled during smoke test")))
        try:
            checks = [check_operators, check_noise_alignment, check_sd3_equivalence, check_chain_rule,
                      check_method_identities, check_closed_loop, check_diagnostics, check_budget, check_dp,
                      check_repo_files, check_download_entrypoint, check_local_loading, check_cli_entrypoints]
            if args.skip_diffusers:
                skipped("diffusers_adapters", "--skip-diffusers (core checks only)")
            else:
                checks += [check_qwen21, check_qwen21_aligned_rope, check_flux, check_sana]
                if torch.cuda.is_available() and torch.cuda.is_bf16_supported():
                    checks.append(lambda: check_qwen21("cuda", torch.bfloat16, "cuda_bf16"))
                else:
                    skipped("qwenimage21_cuda_bf16", "CUDA or bf16 not available")
            for fn in checks:
                current = fn.__name__
                fn()
            if args.real_model:
                current = "real_model"
                real_model_run(args.real_model, args.real_height, args.real_steps, ROOT / "artifacts/real_smoke")
            else:
                skipped("real_model", "no --real-model given; no weights downloaded")
        except Exception as exc:
            status = "failed"
            error = exc
            CHECKS.append({"name": current, "status": "failed", "error": str(exc),
                           "traceback": traceback.format_exc()})
            traceback.print_exc()
    try:
        diffusers_version = version("diffusers")
    except PackageNotFoundError:
        diffusers_version = None
    report = {
        "status": status, "seconds": round(time.perf_counter() - started, 2), "checks": CHECKS,
        "offline": True, "scope": "core" if args.skip_diffusers else "full",
        "environment": {"python": platform.python_version(), "torch": torch.__version__,
                        "executable": sys.executable, "diffusers": diffusers_version, "cuda": torch.cuda.is_available(),
                        "gpu": torch.cuda.get_device_name() if torch.cuda.is_available() else None},
    }
    path = Path(args.report)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    n_pass = sum(c["status"] == "passed" for c in CHECKS)
    n_skip = sum(c["status"] == "skipped" for c in CHECKS)
    print(f"smoke test {status}: {n_pass} checks passed, {n_skip} skipped, "
          f"{report['seconds']} s -> {path}")
    if error is not None:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
