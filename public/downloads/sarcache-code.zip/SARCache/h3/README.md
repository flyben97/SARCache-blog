# Optional H3 integration

This directory contains the Python adapter, cache controller, pipeline wrappers, and metric utilities for the MiniMax-H3 integration. It is an optional integration layer, not a self-contained model distribution.

A separate ComfyUI environment and the corresponding model weights are required. The adapter records the expected ComfyUI commit and model revision in `h3/__init__.py`. Third-party source code, model weights, generated media, run records, and environment dumps are intentionally not included.

The image pipeline in `sarcache/` does not import this H3 integration layer.
