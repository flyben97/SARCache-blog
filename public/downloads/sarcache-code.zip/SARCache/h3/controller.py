"""SARCache(sarcache)/Sea 的 H3 刷新状态机。

移植自 sarcache/sampler.py 的 sarcache 分支语义（SARCache §3，10-10 锁定版），
适配 H3 的联合 video/audio gate：gate 只产出"是否 full"的判决，残差预测与
提交在 adapter/wrappers 侧完成。纯 Python + torch，CPU 可测。

模式：
  - "full"/"off"      : 每步 full（off = 禁用缓存；thresh<=0 的语义）
  - "fixed"           : sarcache_fixed_refresh 固定位置回放（gate/cap/warmup 全旁路，
                        末步自动补 full 并计数 fixed_refresh_auto_tail）
  - "sar"             : 自适应 gate + warmup + cap + forecast_age_window 预测
  - "sea"             : 同一 gate/边界；strategy="hold"(a=0) 或 "linear"(a=∞，
                        相对社区 SeaCache-H3 端口的移植扩展，单独标注)

Sea 的 hold/linear 也走 forecast_residual，window 分别为 0/"unbounded"。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .adapter import forecast_residual

WINDOWS = (0, 1, 2, 3, 4, "unbounded")


@dataclass
class H3CacheConfig:
    mode: str = "full"                    # full|off|fixed|sar|sea|teacache|taylor|ecp
    thresh: float = 0.0                   # 联合 gate 阈值；<=0 视为禁用（恒 full）
    warmup: int = 1                       # 前 warmup 步强制 full（1=官方 retention_steps=1）
    max_reuse: int = 2                    # 连续复用上限 q；0=禁用 cap
    forecast_age_window: int | str = "unbounded"   # SAR: 0..4 | "unbounded"
    sea_strategy: str = "hold"            # sea: hold | linear
    fixed_refresh: list[int] | None = None
    metric_stride: int = 4
    taylor_order: int = 2                 # taylor: 1..3（velocity Newton 差商外推阶数）

    def __post_init__(self):
        if self.mode not in ("full", "off", "fixed", "sar", "sea",
                             "teacache", "taylor", "ecp"):
            raise ValueError(f"unknown mode {self.mode!r}")
        if self.forecast_age_window not in WINDOWS:
            raise ValueError(f"forecast_age_window must be one of {WINDOWS}")
        if self.sea_strategy not in ("hold", "linear"):
            raise ValueError("sea_strategy must be hold|linear")
        if not (1 <= self.taylor_order <= 3):
            raise ValueError("taylor_order must be 1..3")
        if self.mode != "taylor" and self.taylor_order != 2:
            raise ValueError("taylor_order only applies to taylor")
        if self.mode == "fixed" and self.fixed_refresh is None:
            raise ValueError("fixed mode needs fixed_refresh positions")
        if self.fixed_refresh is not None and self.mode not in ("fixed", "sar", "sea"):
            raise ValueError("fixed_refresh applies to fixed|sar|sea "
                             "(Figure3：sar/sea 的策略在固定位置回放)")
        if self.max_reuse < 0:
            raise ValueError("max_reuse(q) must be >= 0 (0 = cap disabled)")
        if self.thresh < 0:
            raise ValueError("thresh must be >= 0")


@dataclass
class StepRecord:
    step: int
    sigma: float
    decision: str              # "full" | "reuse"
    reason: str                # first|last|warmup|gate|cap|fixed|fixed_auto_tail|off
    video_score: float | None = None
    audio_score: float | None = None
    acc_video: float | None = None
    acc_audio: float | None = None
    age: int | None = None
    forecast: str | None = None    # reuse 时: hold|linear


class H3CacheController:
    """每 sampling run 一个新实例（计划：每方法/每任务重新初始化 cache 状态）。"""

    def __init__(self, config: H3CacheConfig):
        self.cfg = config
        self.prev_video = None     # 上一步 video monitor（gate 参考，每步更新）
        self.prev_audio = None
        self.acc_video = 0.0
        self.acc_audio = 0.0
        self.reuse_n = 0
        # fresh 残差历史（只用真实 full；预测结果绝不进入）
        self.r_j = None
        self.r_k = None
        self.j = None
        self.k = None
        # 窗口激活率统计（eligible = 有两个 fresh 可外推的 reuse 步）
        self.win_eligible = 0
        self.win_fallback = 0
        self.counts = {"full": 0, "reuse": 0, "fixed_refresh_auto_tail": 0}
        self.records: list[StepRecord] = []
        self._fixed_set: set[int] | None = None
        self._num_steps: int | None = None
        self._window = self._resolve_window()
        # 输出级方法（teacache/taylor/ecp）：fresh 输出缓存（只用真实 full）
        self.out_hist: list[tuple[int, tuple]] = []   # [(step_i, (v_video, v_audio)), ...]
        self.out_cache = None                          # teacache/ecp 的最近 full 输出
        self.krate_k = None                            # ecp 传播率 k=|Δv|/|Δemb|
        self._v_mean = 1.0                             # ecp |v| 均值（full 步刷新）
        self._prev_raw_emb = None                      # ecp 上一步 raw embed 探针
        self._prev_full_emb = None                     # ecp 上一次 full 的 raw embed
        self._last_raw_emb = None                      # block-0 探针暂存（commit 用）
        self._last_full = None                         # 最近一次 full 步索引

    def _resolve_window(self):
        c = self.cfg
        if c.mode == "sea":
            return 0 if c.sea_strategy == "hold" else "unbounded"
        if c.mode == "sar":
            return c.forecast_age_window
        return 0  # full/off/fixed/teacache/taylor/ecp 不使用残差窗口预测

    def is_output_level(self) -> bool:
        """reuse 提交策略：输出级（缓存 velocity 重放/外推）而非残差重组。"""
        return self.cfg.mode in ("teacache", "taylor", "ecp")

    def _resolve_window(self):
        c = self.cfg
        if c.mode == "sea":
            return 0 if c.sea_strategy == "hold" else "unbounded"
        if c.mode == "sar":
            return c.forecast_age_window
        return 0  # full/off/fixed 不使用预测

    def begin_run(self, num_steps: int):
        """在采样开始前调用；解析固定刷新位置（补 0 与末步）。"""
        self._num_steps = num_steps
        if self.cfg.fixed_refresh is not None:
            pts = sorted(set(int(p) for p in (self.cfg.fixed_refresh or [])))
            pts = [p for p in pts if 0 <= p < num_steps]
            auto = (num_steps - 1) not in pts
            if auto:
                pts.append(num_steps - 1)
            self._fixed_set = set(pts)
            self._auto_tail = auto

    @property
    def needs_monitors(self) -> bool:
        """gate 探针是否需要在 block-0 计算（fixed/full/off 或禁用阈值时跳过）。"""
        c = self.cfg
        return c.mode in ("sar", "sea", "teacache", "taylor", "ecp") and c.thresh > 0

    def _ecp_scores(self, monitors):
        """EC-P 传播率门（图像 sarcache_krate 语义的 H3 版）：raw embed 的步间
        rel-L1 × 观测传播率 k（最近两个 full 的 |Δv|/|Δemb|），velocity 归一。
        返回 (gate_score, None)（单信号，音频行并入 max 前先分开算）。"""
        from .adapter import relative_l1
        v_raw, a_raw = monitors
        self._last_raw_emb = (v_raw, a_raw)
        if self._prev_raw_emb is None:
            self._prev_raw_emb = (v_raw, a_raw)
            return 0.0, None
        rel = max(relative_l1(v_raw, self._prev_raw_emb[0]),
                  relative_l1(a_raw, self._prev_raw_emb[1]))
        self._prev_raw_emb = (v_raw, a_raw)
        if self.krate_k is None or self.out_cache is None:
            # k 需要两个真实 full 才能估计：此前 gate 失明，保守 full
            return None, None
        gate = self.krate_k * rel / (self._v_mean + 1e-8)
        self.acc_video = gate
        return gate, None

    def _gate_fire(self, video_score, audio_score) -> bool:
        """探针分数已累加；返回是否触发刷新。max 判决（联合刷新）。"""
        return max(self.acc_video, self.acc_audio) > self.cfg.thresh

    def decide(self, i: int, sigma: float, monitors) -> StepRecord:
        """monitors: (video_monitor, audio_monitor) 或 None（fixed/full 模式可省）。

        返回 StepRecord；decision=="reuse" 时调用方需再取 predict_residual()。
        """
        c = self.cfg
        n = self._num_steps
        assert n is not None, "begin_run() first"

        video_score = audio_score = None
        if monitors is not None and c.mode in ("sar", "sea", "teacache", "taylor", "ecp") \
                and c.thresh > 0:
            if c.mode == "ecp":
                video_score, audio_score = self._ecp_scores(monitors)
            elif self.prev_video is not None:
                from .adapter import relative_l1
                video_score = relative_l1(monitors[0], self.prev_video)
                audio_score = relative_l1(monitors[1], self.prev_audio)
                self.acc_video += video_score
                self.acc_audio += audio_score
            if c.mode != "ecp" and monitors[0] is not None:
                self.prev_video = monitors[0]
                self.prev_audio = monitors[1]

        # ---- 判决 ----
        reason = None
        if c.mode in ("full", "off") or c.thresh <= 0 and c.mode in (
                "sar", "sea", "teacache", "taylor", "ecp"):
            decision, reason = "full", "off"
        elif c.fixed_refresh is not None:
            decision = "full" if i in self._fixed_set else "reuse"
            if decision == "full":
                reason = "fixed_auto_tail" if (self._auto_tail and i == n - 1 and
                                               i not in set(self.cfg.fixed_refresh or [])) else "fixed"
        else:
            if i == 0:
                decision, reason = "full", "first"
            elif i == n - 1:
                decision, reason = "full", "last"
            elif c.warmup > 1 and i < c.warmup:
                decision, reason = "full", "warmup"
            elif video_score is None:
                # 无探针分数（monitors=None 且非 fixed/off——防御性 full）
                decision, reason = "full", "first"
            else:
                fire = self._gate_fire(video_score, audio_score)
                cap = c.max_reuse > 0 and self.reuse_n >= c.max_reuse
                if fire or cap:
                    decision, reason = "full", "gate" if fire else "cap"
                else:
                    decision, reason = "reuse", "reuse"

        rec = StepRecord(step=i, sigma=float(sigma), decision=decision, reason=reason,
                         video_score=video_score, audio_score=audio_score,
                         acc_video=self.acc_video, acc_audio=self.acc_audio)

        if decision == "full":
            self.counts["full"] += 1
            self.acc_video = 0.0
            self.acc_audio = 0.0
            self.reuse_n = 0
            self._last_full = i
            if reason == "fixed_auto_tail":
                self.counts["fixed_refresh_auto_tail"] += 1
        else:
            self.counts["reuse"] += 1
            self.reuse_n += 1
            rec.age = i - self._last_full if self._last_full is not None else None
        self.records.append(rec)
        return rec

    def predict_residual(self, i: int):
        """返回 (r_used, forecast_kind)；仅 reuse 步调用。full 步请用 commit_full。"""
        window = self._window
        if self.r_j is None:
            raise RuntimeError("reuse without any fresh residual")
        if self.r_k is not None and self.cfg.mode in ("sar", "sea"):
            self.win_eligible += 1
            if window != "unbounded" and (i - self.j) > window:
                self.win_fallback += 1
        r_used, kind = forecast_residual(self.r_k, self.r_j, self.k, self.j, i, window)
        self.records[-1].forecast = kind
        return r_used, kind

    # ---- 输出级方法（teacache/taylor/ecp）：fresh 输出缓存与提交 ----

    def commit_full_output(self, i: int, out):
        """full 步提交真实模型输出 out=[v_video, v_audio]（_forward 格式）。
        预测/外推结果绝不进入缓存。ecp 在此刷新传播率 k 与 |v| 均值。"""
        import torch
        cached = tuple(t.detach().clone() for t in out)
        if self.cfg.mode == "ecp" and self._last_raw_emb is not None:
            emb = torch.cat([self._last_raw_emb[0].reshape(-1).double(),
                             self._last_raw_emb[1].reshape(-1).double()])
            v = torch.cat([cached[0].reshape(-1).double(), cached[1].reshape(-1).double()])
            self._v_mean = float(v.abs().mean())
            if self.out_cache is not None:
                v_prev = torch.cat([self.out_cache[0].reshape(-1).double(),
                                    self.out_cache[1].reshape(-1).double()])
                # 与上一次的 raw emb 差（上一次 full 时记录的）
                if self._prev_full_emb is not None:
                    demb = float((emb - self._prev_full_emb).abs().mean())
                    dv = float((v - v_prev).abs().mean())
                    if demb > 1e-12:
                        self.krate_k = dv / demb
            self._prev_full_emb = emb
        self.out_cache = cached
        self.out_hist.append((i, cached))
        keep = self.cfg.taylor_order + 1 if self.cfg.mode == "taylor" else 2
        self.out_hist = self.out_hist[-keep:]
        self._last_full = i

    def predict_output(self, i: int):
        """输出级 reuse 提交：teacache/ecp 重放最近 full 输出；taylor 用
        step-index Newton 差商外推（点数不足自动降阶，单点退化为 hold）。
        返回 ([v_video, v_audio], kind)。"""
        if self.out_cache is None:
            raise RuntimeError("output reuse without any fresh output")
        if self.cfg.mode != "taylor":
            self.records[-1].forecast = "hold"
            return list(self.out_cache), "hold"
        m = self.cfg.taylor_order + 1
        hist = self.out_hist[-m:]
        if len(hist) == 1:
            self.records[-1].forecast = "hold"
            return list(self.out_cache), "hold"
        # Newton 前向差商（节点为 step index），在最新点求值并外推到 i
        import torch
        xs = [float(h[0]) for h in hist]
        coef = []   # 差商表第一行
        vals = [tuple(t.double() for t in h[1]) for h in hist]
        n = len(hist)
        table = [[vals[r] for r in range(n)]]
        for order in range(1, n):
            row = []
            for r in range(n - order):
                denom = xs[r + order] - xs[r]
                prev, nxt = table[order - 1][r], table[order - 1][r + 1]
                row.append(tuple((nxt[c] - prev[c]) / denom for c in range(2)))
            table.append(row)
        x_eval = float(i)
        # Newton 标准形：节点自旧到新，系数为差商表对角线
        result = [t.clone() for t in table[0][0]]
        basis = 1.0
        for order in range(1, n):
            basis *= (x_eval - xs[order - 1])
            for c in range(2):
                result[c] = result[c] + table[order][0][c] * basis
        kind = f"taylor{min(n - 1, self.cfg.taylor_order)}"
        self.records[-1].forecast = kind
        return [r.to(self.out_cache[0].dtype) for r in result], kind

    def commit_full(self, i: int, r_i):
        """full 步提交 fresh 残差 r_i（真实全计算；预测结果禁止进入）。"""
        self.r_k = self.r_j
        self.k = self.j
        self.r_j = r_i
        self.j = i
        self._last_full = i

    @property
    def window_activation_rate(self):
        return (self.win_fallback / self.win_eligible) if self.win_eligible else None

    def summary(self) -> dict:
        return {
            "counts": dict(self.counts),
            "win_eligible": self.win_eligible,
            "win_fallback": self.win_fallback,
            "window_activation_rate": self.window_activation_rate,
            "window": self._window if self.cfg.mode in ("sar", "sea") else None,
            "mode": self.cfg.mode,
        }
