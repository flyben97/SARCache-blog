"""原生 H3 音视频流水线（ComfyUI 锁定代码同路径驱动，无服务器）。

覆盖官方 T2V 模板（h3/workflows/video_minimax_h3_t2v.json 的子图）：
UNETLoader(int8_convrot, default) + CLIPLoader(minimax, NVFP4/AWQ) +
双 VAELoader + MiniMaxH3ImageToVideo(无 keyframe = t2va) + BasicGuider +
KSamplerSelect(res_multistep) + BasicScheduler(simple, steps, 1.0) +
RandomNoise(fixed seed) + VAEDecode/VAEDecodeAudio。
Turbo LoRA/插帧/超分/稀疏注意力全部关闭；默认注意力（INT8 convrot 检查点
不支持 Comfy Kitchen 注意力，见官方文档）。
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path

import torch

COMFY_ROOT = Path(__file__).resolve().parent / "vendor" / "ComfyUI"

MODEL_DIRS = {
    "diffusion_models": "diffusion_models",
    "text_encoders": "text_encoders",
    "vae": "vae",
}

DIT_NAME = "minimax_h3_fl2va_pruned_int8_convrot.safetensors"
TE_NAME = "qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors"
VAE_VIDEO_NAME = "minimax_h3_video_vae_int8_convrot.safetensors"
VAE_AUDIO_NAME = "minimax_h3_audio_vae_fp32.safetensors"


def init_comfy(models_root: str | None = None, output_dir: str | None = None,
               verbose: bool = False):
    """把 vendored ComfyUI 挂进 sys.path 并配置 folder_paths（不改动 vendor 树）。

    无 GPU 的环境（登录节点）在导入任何 comfy 模块前注入 --cpu，避免
    model_management 模块级 get_torch_device() 崩溃。"""
    root = str(COMFY_ROOT)
    if root not in sys.path:
        sys.path.insert(0, root)
    os.chdir(root)  # ComfyUI 若干模块以 cwd 定位资源
    if not torch.cuda.is_available():
        # model_management 在模块导入期读取 args.cpu 决定设备；cli_args 默认
        # parse_args([])（args_parsing=False），这里直接注入 CPU 模式。
        import comfy.cli_args as _cli_args
        _cli_args.args.cpu = True
    import folder_paths
    if models_root:
        for kind, sub in MODEL_DIRS.items():
            folder_paths.add_model_folder_path(kind, os.path.join(models_root, sub))
    if output_dir:
        folder_paths.set_output_directory(output_dir)
    import logging
    if not verbose:
        logging.getLogger().setLevel(logging.WARNING)
    return folder_paths


def load_stack(models_root: str, verbose: bool = False):
    """按官方模板加载 model/clip/双 VAE（每进程一次）。"""
    init_comfy(models_root, verbose=verbose)
    import nodes
    unet = nodes.UNETLoader().load_unet(DIT_NAME, "default")[0]
    clip = nodes.CLIPLoader().load_clip(TE_NAME, "minimax", "default")[0]
    vae = nodes.VAELoader().load_vae(VAE_VIDEO_NAME)[0]
    audio_vae = nodes.VAELoader().load_vae(VAE_AUDIO_NAME)[0]
    return unet, clip, vae, audio_vae


def temporal_shape(length: int):
    """nodes_minimax_h3 的 17k+5 帧数网格（56 帧 = 2.333s@24fps）。"""
    from comfy_extras.nodes_minimax_h3 import align_frame_count, video_latent_t, FPS, AUDIO_LATENT_FPS
    frame_count = align_frame_count(max(5, length))
    return frame_count, video_latent_t(frame_count), round(frame_count / FPS * AUDIO_LATENT_FPS)


def make_conditioning(clip, vae, prompt: str, width: int, height: int, length: int):
    """MiniMaxH3ImageToVideo.execute（无 first/last frame → t2va）。

    inference_mode：32B 编码激活若在常态 grad 下会被保留（OOM 隐患）；
    产物 cond 随后在 no_grad 采样中消费，语义安全。"""
    from comfy_extras.nodes_minimax_h3 import MiniMaxH3ImageToVideo
    with torch.inference_mode():
        out = MiniMaxH3ImageToVideo.execute(clip=clip, vae=vae, prompt=prompt,
                                            width=width, height=height, length=length,
                                            first_frame=None, last_frame=None)
    return out[0], out[1]   # (cond, latent)


def prepare_noise_nested(latent_samples, seed: int):
    """与 RandomNoise(fixed).generate_noise 同式：单一 CPU generator 顺序画
    video/audio 两个流（共享初始噪声的生成与复用都走这个函数）。"""
    import comfy.sample
    return comfy.sample.prepare_noise(latent_samples, seed)


def load_noise_nested(noise_dir: str | Path):
    """读取保存的共享初始噪声（video/audio fp32 tensor）。"""
    import comfy.nested_tensor
    v = torch.load(os.path.join(noise_dir, "video_noise.pt"), map_location="cpu", weights_only=True)
    a = torch.load(os.path.join(noise_dir, "audio_noise.pt"), map_location="cpu", weights_only=True)
    return comfy.nested_tensor.NestedTensor([v, a])


def save_noise_nested(noise_nested, noise_dir: str | Path) -> dict:
    os.makedirs(noise_dir, exist_ok=True)
    v, a = noise_nested.unbind()
    torch.save(v, os.path.join(noise_dir, "video_noise.pt"))
    torch.save(a, os.path.join(noise_dir, "audio_noise.pt"))
    info = {}
    for name, t in (("video_noise", v), ("audio_noise", a)):
        b = t.contiguous().to(torch.float32).numpy().tobytes()
        info[name] = {"shape": list(t.shape), "dtype": str(t.dtype),
                      "sha256": hashlib.sha256(b).hexdigest()}
    return info


def compute_sigmas(model_patcher, steps: int):
    """BasicScheduler(simple, steps, 1.0) 同式；返回 cpu FloatTensor。"""
    import comfy.samplers
    return comfy.samplers.calculate_sigmas(
        model_patcher.get_model_object("model_sampling"), "simple", steps).cpu()


def sigma_schedule_record(sigmas, steps: int) -> dict:
    """原生 sigma 序列存档：video sigma（sampler 网格）+ 每步派生 audio sigma
    （time_shift_sigma shift12→3）与 t=1-sigma（从锁定代码核实的映射）。"""
    from .adapter import time_shift_sigma
    sig = [float(s) for s in sigmas]
    steps_out = []
    for i in range(len(sig) - 1):
        sv = sig[i]
        sa = time_shift_sigma(max(sv, 1e-6), 12.0, 3.0) if sv > 0 else 0.0
        steps_out.append({"step": i, "sigma_video": sv, "sigma_audio": sa,
                          "t_video": 1.0 - sv, "t_audio": 1.0 - sa})
    return {"scheduler": "simple", "sampler": "res_multistep", "steps": steps,
            "shift_video": 12.0, "shift_audio": 3.0,
            "sigmas": sig, "per_step": steps_out,
            "note": "video shift=12/audio shift=3 核实自 comfy/supported_models.py "
                    "MiniMaxH3.sampling_settings 与 comfy/ldm/minimax/model.py"}


def run_sampling(model_patcher, cond, noise_nested, sigmas, num_steps: int,
                 controller=None, seed: int = 0, step_trace: bool = False):
    """Guider_Basic + res_multistep 原生采样（SamplerCustomAdvanced 同路径）。

    controller 非 None 时经 wrappers.install 的 patcher 调用（runner 负责
    install 与每 run 换新 controller）；返回 (packed_samples_flat, controller)。
    """
    import comfy.samplers
    from comfy_extras.nodes_custom_sampler import Guider_Basic

    if controller is not None:
        from . import wrappers
        to = model_patcher.model_options["transformer_options"]
        to[wrappers.CONTROLLER_KEY] = controller
        if step_trace:
            controller.step_trace = []

    guider = Guider_Basic(model_patcher)
    guider.set_conds(cond)
    sampler = comfy.samplers.sampler_object("res_multistep")
    controller.begin_run(num_steps) if controller is not None else None

    samples = guider.sample(noise_nested, _zeros_like_latent(noise_nested), sampler,
                            sigmas, denoise_mask=None, callback=None,
                            disable_pbar=True, seed=seed)
    return samples, controller


def _zeros_like_latent(noise_nested):
    import comfy.nested_tensor
    return comfy.nested_tensor.NestedTensor([torch.zeros_like(t) for t in noise_nested.unbind()])


def decode_and_save(vae, audio_vae, samples_nested, out_dir: str | Path,
                    stem: str, fps: int = 24, keep_rgb_master: bool = True) -> dict:
    """VAEDecode/VAEDecodeAudio（原生）→ 保存无损母版（RGB fp32 .pt + WAV）
    与浏览用 MP4（H264 有损，仅浏览，评估不用）。samples_nested 为 guider.sample
    返回的 NestedTensor（video/audio 两个流）。返回文件清单+hash+分相计时。

    必须在 inference_mode 下调用：ViT3D 视频 VAE 36 层全 token 注意力，常态
    grad 会保留全部激活（>130GB）；Comfy 图执行器自带 no_grad 环境，程序化
    驱动必须显式补上（k_diffusion 采样器自带 @torch.no_grad，编码器内部自带，
    唯解码路径裸露）。"""
    import nodes
    from comfy_extras.nodes_audio import VAEDecodeAudio
    os.makedirs(out_dir, exist_ok=True)
    manifest = {}

    streams = samples_nested.unbind()
    latent_dict_v = {"samples": streams[0]}
    latent_dict_a = {"samples": streams[1]}
    t0 = time.perf_counter()
    with torch.inference_mode():
        frames = nodes.VAEDecode().decode(vae, latent_dict_v)[0]   # [T,H,W,C] float
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    manifest["video_decode_s"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    with torch.inference_mode():
        audio = VAEDecodeAudio().decode(audio_vae, latent_dict_a)[0]  # {waveform, sample_rate}
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    manifest["audio_decode_s"] = time.perf_counter() - t0

    rgb = frames.float().cpu()
    wav = audio["waveform"].float().cpu()   # [1, C, L]
    sr = int(audio["sample_rate"])

    if keep_rgb_master:
        torch.save(rgb, os.path.join(out_dir, f"{stem}_rgb.pt"))
        manifest["rgb"] = _hash_file(os.path.join(out_dir, f"{stem}_rgb.pt"))
    else:
        # 瘦留存（fixed_refresh/Figure3）：只存冻结 12 帧的 uint8 评估子集
        from .metrics import video_frame_indices
        idx = video_frame_indices(rgb.shape[0])
        import numpy as _np
        f12 = (rgb[idx] * 255.0).round().clamp(0, 255).to(torch.uint8).numpy()
        _np.savez_compressed(os.path.join(out_dir, "frames12.npz"),
                             frames=f12, indices=_np.array(idx))
        manifest["rgb"] = {"note": "slim_f3: frames12.npz only (uint8, frozen 12-frame indices)"}

    import soundfile as sf
    wav_path = os.path.join(out_dir, f"{stem}.wav")
    sf.write(wav_path, wav.squeeze(0).transpose(0, 1).numpy(), sr, subtype="FLOAT")
    manifest["wav"] = _hash_file(wav_path)
    manifest["wav_meta"] = {"sample_rate": sr, "channels": wav.shape[1],
                            "frames": int(wav.shape[-1]),
                            "duration_s": wav.shape[-1] / sr}

    mp4_path = os.path.join(out_dir, f"{stem}.mp4")
    _mux_mp4(rgb.numpy(), wav.squeeze(0).transpose(0, 1).numpy(), sr, fps, mp4_path)
    manifest["mp4"] = _hash_file(mp4_path)
    manifest["frames_shape"] = list(rgb.shape)
    return manifest


def _mux_mp4(rgb_hwc, wav_cl, sr, fps, path):
    """av 复用：H264/yuv420p 浏览用 MP4（仅视频轨；评估一律用 RGB 母版/WAV）。

    注：容器内 av 17 的音频轨 mux（aac 与 pcm）在本调用模式下触发
    Packet._rebase_time 崩溃，属浏览便利而非流水线组件；音频以同目录 WAV
    母版为准（协议 §10：MP4 仅用于浏览）。"""
    import av
    container = av.open(path, mode="w")
    stream = container.add_stream("libx264", rate=fps)
    stream.width, stream.height = rgb_hwc.shape[2], rgb_hwc.shape[1]
    stream.pix_fmt = "yuv420p"
    stream.options = {"crf": "18"}
    for idx, frame in enumerate(rgb_hwc):
        f = av.VideoFrame.from_ndarray((frame * 255.0).round().clip(0, 255).astype("uint8"), format="rgb24")
        f.pts = idx
        for packet in stream.encode(f):
            container.mux(packet)
    for packet in stream.encode():
        container.mux(packet)
    container.close()


def _hash_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return {"path": str(path), "sha256": h.hexdigest(),
            "size_bytes": os.path.getsize(path)}
