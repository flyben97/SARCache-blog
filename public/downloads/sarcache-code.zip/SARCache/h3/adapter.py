"""MiniMax-H3 联合 video/audio/text packed-token 的 SARCache/SeaCache 边界映射。

边界定义（从 h3/vendor/ComfyUI 锁定代码核实，comfy/ldm/minimax/model.py）：

  packed 序列（t2va，无 keyframe/ref）::  [text | audio | video]
    - e_i = `_embed_and_pack` 输出（[S, hidden]）：video/audio patch proj（fp32
      权重，当前噪声 latent 每步重算）+ refined text embed（Qwen3-VL hidden 经
      condition_proj+token_refiner，每个 sampling run 预算一次）。即"当前步
      embedding"。
    - h_i = 50 个 DiTBlock 全栈输出（[S, hidden]，同一 packed 网格）。
    - head = `FinalLayer`（norm + adaln + video_out/audio_out fp32 投影）+
      unpatchify_video/unpack_audio；本 checkpoint head bank n=1（非 PDD），
      head 按当前步 sigma 的 adaln 调制。
    - fresh 残差 r_i = h_i - e_i（全部 packed 行；复用时 commit e_i' + r_used）。

  输出参数化（核实，不默认 velocity）：
    `_forward` 返回 [-video_out, -audio_out]；model_base 经
    `calculate_denoised = x - model_output * sigma`（ModelSamplingDiscreteFlow）
    消费，即 flow-matching velocity（video 在 sigma_v 网格，audio 在 sigma_a
    网格，外层 forward() 把 audio velocity 换算回共享携带网格后交给 sampler；
    该换算对 full 与 reuse 输出一视同仁地套用——reuse 的 wrapper 返回值就是
    forward 的 graph_out，社区 SeaCache-H3 端口同样如此，无双换算/漏换算）。

  联合 gate（Sea 与 SAR 共用同一边界、同一 gate，计划 §3）：
    probe = block-0 modulated 输入（社区 SeaCache-H3 定义）：
      modulated = norm1(e) 按 block0.adaln_proj(t_emb) 的 (shift_msa, scale_msa)
      逐 mod_segment 调制。
    video gate：video 行 reshape (T, H, W, C)，空间 stride s（默认 4，仅 H/W），
      3D SEA Wiener 滤波（轴=(0,1,2)=T,H,W，power=3.0，全复数 FFT，
      flow 调度 a=1-sigma_v, b=sigma_v），与参考的 rel-L1 累加。
    audio gate：audio 行原始（无滤波），同样 stride 采样，rel-L1 独立累加。
    判决：max(acc_video, acc_audio) > thresh 触发联合 full 刷新
      （共同全栈跳过时音频变化强制刷新，音频状态与视频同一决策）。
    参考（previous monitor）每步更新（step-to-step drift 语义）。

  声明的 video gate 轴/滤波参数/stride：
    轴 = (T, H, W)（视频 token 网格，patch 2x2 后 latent_h/2 x latent_w/2）；
    滤波 = SEA 分离 Wiener，逐轴 gain = (a*S)/(a^2*S + b^2)，S=1/(f^p+eps)，
      p=3.0，gain 按均值归一化，全复数 fftn/ifftn 后取实部；
    stride = 4（H、W 两轴，社区默认 metric_stride；时间轴不采样）。
  声明的 audio gate：无滤波（raw），stride = 4（按 (frame, channel) 行采样）。

  移植语义（sarcache/sampler.py 的 sarcache 分支 + SARCache §3）：
    - 预测只用最近两个"真实全计算"残差 (r_k, r_j)，预测结果不提交为 fresh
      history；full 步才更新 fresh 历史 (k<-j, r_k<-r_j, j<-i, r_j<-r_i)。
    - age = i - j；两个 fresh 且 (window=="unbounded" 或 age<=a)：
      r_used = r_j + age/(j-k) * (r_j - r_k)；否则 hold r_j；单个 fresh 恒 hold。
    - window a ∈ {0,1,2,3,4,"unbounded"}；a=0 纯 hold；窗口本身不触发刷新；
      刷新由 gate/warmup/cap/首末步独立决定；q=0 禁用 cap。
    - Sea(on H3) = 同一 gate/边界，strategy ∈ {hold, linear}；
      linear（无界线性外推）为相对社区端口的移植扩展，单独标注。
"""

from __future__ import annotations

import math

import torch

SEA_POWER = 3.0
SEA_EPS = 1e-16
DEFAULT_METRIC_STRIDE = 4


def time_shift_sigma(sigma: float, from_shift: float, to_shift: float) -> float:
    """model.py 同式的 shift 换算：sigma = s*b/(1+(s-1)*b) 的逆映射再重映射。"""
    base = sigma / (from_shift + sigma * (1.0 - from_shift))
    return to_shift * base / (1.0 + (to_shift - 1.0) * base)


def sea_filter(x: torch.Tensor, a: float, b: float, dims: tuple[int, ...],
               power: float = SEA_POWER) -> torch.Tensor:
    """SEA 分离 Wiener 滤波（与社区 SeaCache H3 端口同式：全复数 FFT）。

    dims 为滤波轴（video gate: (0,1,2)=T,H,W）。gain 逐轴
    (a*S)/(a^2*S+b^2)，S=1/(f^power+eps)，再按均值归一化。
    """
    original_dtype = x.dtype
    x32 = x.contiguous().float()
    gain = None
    for dim in dims:
        frequency = torch.fft.fftfreq(x32.shape[dim], device=x32.device,
                                      dtype=torch.float32).abs()
        spectrum = 1.0 / (frequency.pow(power) + SEA_EPS)
        axis_gain = (a * spectrum) / (a * a * spectrum + b * b + SEA_EPS)
        shape = [1] * x32.ndim
        shape[dim] = axis_gain.shape[0]
        axis_gain = axis_gain.reshape(shape)
        gain = axis_gain if gain is None else gain * axis_gain
    mean_gain = gain.mean()
    if torch.isfinite(mean_gain) and mean_gain > 0:
        gain = gain / mean_gain
    return torch.fft.ifftn(torch.fft.fftn(x32, dim=dims) * gain, dim=dims).real.to(original_dtype)


def relative_l1(current: torch.Tensor, previous: torch.Tensor) -> float:
    numerator = (current - previous).abs().mean()
    denominator = previous.abs().mean().clamp_min(SEA_EPS)
    return float((numerator / denominator).detach().float().cpu())


def gate_monitors(packed_e: torch.Tensor, t_emb: torch.Tensor, mod_segments,
                  block0, video_range, audio_range, video_grid, sigma_v: float,
                  stride: int = DEFAULT_METRIC_STRIDE):
    """联合 gate 探针（社区 SeaCache-H3 的 begin() 公式）。

    返回 (video_monitor, audio_monitor)（均已 detach；驻留 device 由调用方决定）。
    """
    shift, scale, _, _, _, _ = block0.adaln_proj(t_emb)
    modulated = block0.norm1(packed_e).clone()
    for start, end, row in mod_segments:
        modulated[start:end].mul_(1.0 + _row(scale, row, modulated.dtype))
        modulated[start:end].add_(_row(shift, row, modulated.dtype))

    sigma_n = max(1e-6, min(1.0 - 1e-6, float(sigma_v)))
    a, b = 1.0 - sigma_n, sigma_n

    vt, vh, vw = video_grid
    v_rows = modulated[video_range[0]:video_range[1]]
    if vt * vh * vw != v_rows.shape[0]:
        video_monitor = v_rows[::stride, ::stride].float()
    else:
        sampled = v_rows.reshape(vt, vh, vw, v_rows.shape[-1])[:, ::stride, ::stride]
        video_monitor = sea_filter(sampled, a, b, (0, 1, 2), SEA_POWER).detach()
    audio_monitor = modulated[audio_range[0]:audio_range[1]][::stride, ::stride].float()
    return video_monitor, audio_monitor


def _row(vecs, row, dtype):
    return vecs[row].to(dtype)


def forecast_residual(r_k, r_j, k: int, j: int, i: int, window):
    """SARCache §3 残差预测：age<=a 线性外推，否则 hold；单 fresh 恒 hold。

    只用真实全计算残差；返回值仅用于当前步 commit，不进入 fresh 历史。
    """
    age = i - j
    if r_k is None or window == 0:
        return r_j, "hold"
    if window != "unbounded" and age > window:
        return r_j, "hold"
    scale = age / max(j - k, 1)
    return r_j + (r_j - r_k) * scale, "linear"


def head_forward(model, hidden, t_emb, video_seg, audio_seg, sigma_v, sample_sigmas, shifts):
    """FinalLayer head（含 PDD head bank 分支，本 checkpoint n=1 走单头路径）。"""
    return model.final_layer(hidden, t_emb, video_seg, audio_seg, sigma_v,
                             sample_sigmas, shifts)


def reuse_epilogue(model, x_streams, hidden, t_emb, layout, mod_segments,
                   sigma_v: float, sample_sigmas, shifts, audio_scale: float,
                   patch_size=(1, 2, 2), latents_dim=24):
    """cache 复用路径的输出重建：head(e_i' + r_used) + unpatchify_video +
    unpack_audio + 取负，返回与 `_forward` 完全同构的 [-video_out, -audio_out]
    （各自网格上的 velocity；外层 forward() 的音频 carry 换算与 mask 处理随后
    原生套用，full/reuse 走同一个 forward 尾部，无双换算风险）。

    x_streams 仅用于取原始 T/H/W 与 dtype（pad/crop 对齐 _forward）。
    """
    import comfy.ldm.common_dit
    from comfy.ldm.minimax.model import unpatchify_video, unpack_audio

    video_x = x_streams[0]
    orig_t, orig_h, orig_w = video_x.shape[2], video_x.shape[3], video_x.shape[4]
    padded = comfy.ldm.common_dit.pad_to_patch_size(video_x, model.patch_size)
    latent_t, latent_h, latent_w = padded.shape[2], padded.shape[3], padded.shape[4]

    va, vb, _ = next(s for s in layout.segments if s[2] == "video")
    aa, ab, _ = next(s for s in layout.segments if s[2] == "audio")
    video_row = mod_segments[-1][2] // 3
    audio_row = mod_segments[-2][2] // 3
    video_seg = (va, vb, video_row)
    audio_seg = (aa, ab, audio_row)

    v, a = head_forward(model, hidden, t_emb, video_seg, audio_seg, sigma_v,
                        sample_sigmas, shifts)
    video_out = unpatchify_video(v, latent_t, latent_h // patch_size[1],
                                 latent_w // patch_size[2], latents_dim, patch_size)
    video_out = video_out[:, :, :orig_t, :orig_h, :orig_w]
    audio_out = unpack_audio(a)

    return [-video_out.to(video_x.dtype), -audio_out.to(video_x.dtype)]
