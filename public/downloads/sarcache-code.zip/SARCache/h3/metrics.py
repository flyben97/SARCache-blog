"""H3 decoded-media 指标管线（SARCache_集群实验执行计划.md §9 口径）。

- 视频 LPIPS：alex v0.1，输入 RGB[-1,1]（normalize=False）；12 个均匀帧索引
  round(linspace(0,F-1,12))（冻结实现，存档于指标记录）；逐帧得分先汇成视频分，
  再汇 prompt。权重共享 models/torch_home（只读），加载前校验 sha256：
  lpips_alex_v0.1.pth = df73285e…60835c0，alexnet-owt-7be5be79.pth = 7be5be79…cdee02。
- SSIM：scikit-image structural_similarity，data_range=1，channel_axis=-1，
  gaussian_weights=True，sigma=1.5，use_sample_covariance=False；逐帧后均值。
- RGB PSNR：RGB[0,1] 全部评估帧像素汇 MSE，10*log10(1/MSE)；MSE==0 →
  psnr=inf 并标 self_reference（不伪装有限值）。
- E_temp = mean(|(I_c[t]−I_c[t−1]) − (I_f[t]−I_f[t−1])|)，RGB[0,1]，全相邻帧。
- 音频 log-STFT 距离：每声道 Hann n_fft=1024、hop=256、center=False，
  mean(|log(|STFT_c|+1e−5) − log(|STFT_f|+1e−5)|)，声道间再均值；长度不一致报 failure。

输入为 runner 的母版：output_rgb.pt（[T,H,W,C] fp32 [0,1]）与 output.wav。
CPU 可跑（12 帧下 LPIPS-alex 在登录节点约秒级）；GPU worker 由调用方决定。
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent
TORCH_HOME = PROJECT_ROOT / "models" / "torch_home"
LPIPS_DIR = TORCH_HOME / "hub" / "checkpoints"

LPIPS_LINEAR_SHA256 = "df73285e35b22355a2df87cdb6b70b343713b667eddbda73e1977e0c860835c0"
ALEXNET_SHA256 = "7be5be791159472b1fbf3c69796f7cb30dca7ad8466c2df70058c37116cdee02"

LPIPS_FRAME_COUNT = 12


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_lpips_weights() -> dict:
    out = {}
    for name, want in (("lpips_alex_v0.1.pth", LPIPS_LINEAR_SHA256),
                       ("alexnet-owt-7be5be79.pth", ALEXNET_SHA256)):
        p = LPIPS_DIR / name
        got = _sha256(p)
        if got != want:
            raise RuntimeError(f"LPIPS 权重 hash 不符: {name} got={got}")
        out[name] = got
    return out


_lpips_fn = None


def _get_lpips(device="cpu"):
    global _lpips_fn
    if _lpips_fn is None:
        os.environ.setdefault("TORCH_HOME", str(TORCH_HOME))
        import lpips as lpips_pkg
        verify_lpips_weights()
        _lpips_fn = lpips_pkg.LPIPS(net="alex", version="0.1", verbose=False).to(device)
        for p in _lpips_fn.parameters():
            p.requires_grad_(False)
    return _lpips_fn


def video_frame_indices(n_frames: int) -> list[int]:
    """冻结的 12 帧均匀采样：round(linspace(0,F-1,12))。"""
    return [int(round(x)) for x in np.linspace(0, n_frames - 1, LPIPS_FRAME_COUNT)]


def video_metrics(cached_rgb: torch.Tensor, ref_rgb: torch.Tensor, device="cpu") -> dict:
    """cached/ref: [T,H,W,C] fp32 [0,1]。返回逐视频 LPIPS/SSIM/PSNR/E_temp。"""
    assert cached_rgb.shape == ref_rgb.shape, (tuple(cached_rgb.shape), tuple(ref_rgb.shape))
    c = cached_rgb.detach().to(torch.float32).cpu().numpy()
    r = ref_rgb.detach().to(torch.float32).cpu().numpy()
    idx = video_frame_indices(c.shape[0])

    lpips_fn = _get_lpips(device)
    per_frame_lpips = []
    with torch.no_grad():
        for i in idx:
            a = torch.from_numpy(c[i] * 2.0 - 1.0).permute(2, 0, 1).unsqueeze(0).to(device)
            b = torch.from_numpy(r[i] * 2.0 - 1.0).permute(2, 0, 1).unsqueeze(0).to(device)
            per_frame_lpips.append(float(lpips_fn(a, b).item()))
    lpips = float(np.mean(per_frame_lpips))

    from skimage.metrics import structural_similarity as ssim_fn
    per_frame_ssim = [float(ssim_fn(c[i], r[i], data_range=1.0, channel_axis=-1,
                                    gaussian_weights=True, sigma=1.5,
                                    use_sample_covariance=False)) for i in idx]
    ssim = float(np.mean(per_frame_ssim))

    mse = float(np.mean((c - r) ** 2))
    if mse == 0.0:
        psnr = float("inf")
        psnr_note = "self_reference"
    else:
        psnr = float(10.0 * np.log10(1.0 / mse))
        psnr_note = None

    dc = np.diff(c, axis=0)
    dr = np.diff(r, axis=0)
    e_temp = float(np.mean(np.abs(dc - dr))) if c.shape[0] > 1 else 0.0

    return {"lpips": lpips, "ssim": ssim, "psnr": psnr, "psnr_note": psnr_note,
            "e_temp": e_temp, "frame_indices": idx,
            "per_frame_lpips": per_frame_lpips, "per_frame_ssim": per_frame_ssim}


def audio_metrics(cached_wav: np.ndarray, ref_wav: np.ndarray,
                  sr_c: int, sr_r: int) -> dict:
    """cached/ref: [L,C] float；同 rate/长度对齐（不一致报 failure，不重采样）。"""
    if sr_c != sr_r:
        return {"failure": f"sample_rate mismatch {sr_c} vs {sr_r}"}
    if cached_wav.shape != ref_wav.shape:
        return {"failure": f"wav shape mismatch {cached_wav.shape} vs {ref_wav.shape}"}
    import scipy.signal
    dists = []
    for ch in range(ref_wav.shape[1]):
        sc = np.abs(scipy.signal.stft(cached_wav[:, ch], fs=sr_c, window="hann",
                                      nperseg=1024, noverlap=1024 - 256,
                                      boundary=None)[2])
        sf = np.abs(scipy.signal.stft(ref_wav[:, ch], fs=sr_r, window="hann",
                                      nperseg=1024, noverlap=1024 - 256,
                                      boundary=None)[2])
        dists.append(float(np.mean(np.abs(np.log(sc + 1e-5) - np.log(sf + 1e-5)))))
    return {"log_stft_dist": float(np.mean(dists)), "per_channel": dists}


def load_attempt_media(adir: str | Path):
    import soundfile as sf
    adir = Path(adir)
    rgb = torch.load(adir / "output_rgb.pt", map_location="cpu", weights_only=True)
    wav, sr = sf.read(adir / "output.wav", dtype="float32", always_2d=True)
    return rgb, wav, int(sr)


def evaluate_pair(cached_dir: str | Path, ref_dir: str | Path, device="cpu") -> dict:
    rgb_c, wav_c, sr_c = load_attempt_media(cached_dir)
    rgb_r, wav_r, sr_r = load_attempt_media(ref_dir)
    out = {"cached": str(cached_dir), "ref": str(ref_dir),
           "lpips_weights_sha256": verify_lpips_weights(),
           "video": video_metrics(rgb_c, rgb_r, device=device),
           "audio": audio_metrics(wav_c, wav_r, sr_c, sr_r)}
    return out


if __name__ == "__main__":
    # CPU 冒烟：恒等（self-reference）+ 扰动对
    torch.manual_seed(0)
    t, h, w = 20, 64, 96
    base = torch.rand(t, h, w, 3)
    ident = video_metrics(base, base.clone())
    assert ident["lpips"] == 0.0 and ident["ssim"] == 1.0 and ident["e_temp"] == 0.0
    assert ident["psnr"] == float("inf") and ident["psnr_note"] == "self_reference"
    noisy = (base + torch.randn_like(base) * 0.05).clamp(0, 1)
    pert = video_metrics(noisy, base)
    assert 0.0 < pert["lpips"] < 1.0 and pert["ssim"] < 1.0
    assert np.isfinite(pert["psnr"]) and pert["e_temp"] > 0.0
    sr = 32000
    w0 = torch.randn(2 * sr, 2).numpy() * 0.1
    a0 = audio_metrics(w0, w0.copy(), sr, sr)
    assert a0["log_stft_dist"] == 0.0
    a1 = audio_metrics(w0 * 0.5, w0, sr, sr)
    assert a1["log_stft_dist"] > 0.0
    print(json.dumps({"identity": ident, "perturbed": {
        "lpips": pert["lpips"], "ssim": pert["ssim"], "psnr": pert["psnr"],
        "e_temp": pert["e_temp"]}, "audio_ident": a0, "audio_pert": a1["log_stft_dist"]},
        indent=1))
    print("metrics smoke OK")


def _quantize12(frames: torch.Tensor) -> torch.Tensor:
    """float [0,1] 任意帧 -> uint8 量化 -> float（双侧同量化口径）。"""
    return (frames * 255.0).round().clamp(0, 255) / 255.0


def video_metrics_from12(cached12: torch.Tensor, ref12: torch.Tensor, device="cpu") -> dict:
    """双侧已采样的 12 帧（[12,H,W,C] float [0,1]）→ LPIPS/SSIM/PSNR-12。
    双侧统一 uint8 量化（与 frames12.npz 落盘口径一致）；无 E_temp（由
    e_temp_from_mp4 另行给出）。"""
    c = _quantize12(cached12).numpy()
    r = _quantize12(ref12).numpy()
    lpips_fn = _get_lpips(device)
    per_lpips = []
    with torch.no_grad():
        for i in range(c.shape[0]):
            a = torch.from_numpy(c[i] * 2.0 - 1.0).permute(2, 0, 1).unsqueeze(0).to(device)
            b = torch.from_numpy(r[i] * 2.0 - 1.0).permute(2, 0, 1).unsqueeze(0).to(device)
            per_lpips.append(float(lpips_fn(a, b).item()))
    from skimage.metrics import structural_similarity as ssim_fn
    per_ssim = [float(ssim_fn(c[i], r[i], data_range=1.0, channel_axis=-1,
                              gaussian_weights=True, sigma=1.5,
                              use_sample_covariance=False)) for i in range(c.shape[0])]
    mse = float(np.mean((c - r) ** 2))
    psnr = float("inf") if mse == 0.0 else float(10.0 * np.log10(1.0 / mse))
    return {"lpips": float(np.mean(per_lpips)), "ssim": float(np.mean(per_ssim)),
            "psnr": psnr, "psnr_note": "self_reference" if mse == 0.0 else None,
            "per_frame_lpips": per_lpips, "per_frame_ssim": per_ssim,
            "note": "ref-slim 口径：双侧 uint8 量化 12 帧"}


def _decode_mp4_rgb(path: str) -> np.ndarray:
    import av
    c = av.open(path)
    frames = []
    for frame in c.decode(video=0):
        frames.append(frame.to_ndarray(format="rgb24").astype(np.float32) / 255.0)
    c.close()
    return np.stack(frames)


def e_temp_from_mp4(cached_mp4: str, ref_mp4: str) -> float:
    """双侧同 h264 解码口径的 E_temp（ref 无母版时的回退；双侧同处理保持 paired）。"""
    c = _decode_mp4_rgb(cached_mp4)
    r = _decode_mp4_rgb(ref_mp4)
    n = min(len(c), len(r))
    dc = np.diff(c[:n], axis=0)
    dr = np.diff(r[:n], axis=0)
    return float(np.mean(np.abs(dc - dr))) if n > 1 else 0.0


def evaluate_pair_flexible(cached_dir, ref_dir, device="cpu") -> dict:
    """统一评估入口：ref 有 fp32 母版 → 全保真；ref 已瘦留存（npz12+mp4+wav）
    → ref-slim 桥（双侧 uint8 12 帧 LPIPS/SSIM/PSNR + 双侧 mp4 E_temp +
    wav log-STFT；latent_rel=None）。口径差异写进返回 note。"""
    import os
    cached_dir = str(cached_dir); ref_dir = str(ref_dir)
    if os.path.exists(os.path.join(ref_dir, "output_rgb.pt")):
        return evaluate_pair(cached_dir, ref_dir, device=device)
    import numpy as np
    import soundfile as sf
    import torch
    z = np.load(os.path.join(ref_dir, "frames12.npz"))
    idx = [int(i) for i in z["indices"]]
    rgb_c = torch.load(os.path.join(cached_dir, "output_rgb.pt"),
                       map_location="cpu", weights_only=True)
    v12 = video_metrics_from12(rgb_c[idx], torch.from_numpy(z["frames"]).float() / 255.0,
                               device=device)
    v12["e_temp"] = e_temp_from_mp4(os.path.join(cached_dir, "output.mp4"),
                                    os.path.join(ref_dir, "output.mp4"))
    wav_c, sr_c = sf.read(os.path.join(cached_dir, "output.wav"), dtype="float32", always_2d=True)
    wav_r, sr_r = sf.read(os.path.join(ref_dir, "output.wav"), dtype="float32", always_2d=True)
    return {"video": v12,
            "audio": audio_metrics(wav_c, wav_r, int(sr_c), int(sr_r)),
            "latent_video_rel": None, "latent_audio_rel": None,
            "ref_slim_bridge": True,
            "note": "ref-slim 口径：LPIPS/SSIM/PSNR-12 双侧 uint8 量化；"
                    "E_temp 双侧同 h264(mp4) 解码；log-STFT 双侧 wav；"
                    "latent_rel 不可用（ref 母版已瘦留存）"}
