"""SARCache(sarcache) MiniMax-H3 适配层与原生流水线驱动。

H3 DiT INT8 部署（仅 diffusion 为 pruned_int8_convrot；text encoder=NVFP4/AWQ；
video VAE=INT8 convrot；audio VAE=FP32）。本包与图像管线（.venv310 /
vendor/diffusers / run_imagegen.sh）完全隔离，仅依赖 h3/vendor/ComfyUI 的
pinned checkout（见 h3/VENDOR.md）。
"""

H3_COMFY_COMMIT = "0df64eb242b7c5759c3e86afd5d1846d923b1033"
H3_MODEL_REVISION = "e5eb578a89295337b8ff433a035929ce0279e0b6"
