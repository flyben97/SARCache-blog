"""ComfyUI 侧胶水：block patches + DIFFUSION_MODEL wrapper + 安装。

机制（comfy.patcher_extension 合规通路，不改 ComfyUI 源码）：
  - patches_replace[("double_block", 0)]：block-0 前拿到 args["img"]（e_i，
    packed embed）/t_emb/mod_segments/layout；按需算联合 gate 探针；向
    controller 请示 full/reuse；reuse 时以 e_i + r_used 重组 hidden 并抛
    _SkipBlocks 跳过全部剩余 block。求解器在 wrapper 之外，只看到最终
    velocity，正常保留 res_multistep 历史。
  - patches_replace[("double_block", N-1)]：stash block-(N-1) 输出 h_i
    （零数学改动）；wrapper 在 full 返回后取 r_i = h_i - e_i 提交 fresh 历史。
  - WrappersMP.DIFFUSION_MODEL wrapper：捕获 _SkipBlocks 并跑 reuse
    epilogue（head + unpatchify/unpack + 取负，返回 _forward 同构输出；
    外层 forward 的音频换算/mask 处理原生套用）；full 路径原样 executor()。
    wrapper 同时维护 step 计数（1 iteration = 1 DiT call，run 后校验）与
    低扰动逐 call trace（sigma/dt/reused）。

parity 要点：controller 为 None 或全 full 时唯一新增工作是两个 stash patch
（无数学改动）→ wrapper-full 与 native 同代码路径同 kernel。
"""

from __future__ import annotations

import time

import torch

from . import adapter

CONTROLLER_KEY = "sarcache_h3_controller"
WRAPPER_KEY = "sarcache_h3"
_STASH_KEY = "sarcache_h3_stash"


class _SkipBlocks(Exception):
    def __init__(self, hidden, t_emb, mod_segments, layout, output_level=False):
        super().__init__()
        self.hidden = hidden
        self.t_emb = t_emb
        self.mod_segments = mod_segments
        self.layout = layout
        self.output_level = output_level   # teacache/taylor/ecp：跳过 epilogue，
                                           # 直接重放/外推缓存的 velocity 输出


def _target_ranges(mod_segments):
    """目标 audio/video 段 = packed 序列末两段（社区端口同款约定）。"""
    if len(mod_segments) < 2:
        raise RuntimeError("sarcache_h3: packed sequence has no target audio/video segments")
    audio_start, audio_end = int(mod_segments[-2][0]), int(mod_segments[-2][1])
    video_start, video_end = int(mod_segments[-1][0]), int(mod_segments[-1][1])
    if audio_start >= audio_end or audio_end != video_start:
        raise RuntimeError("sarcache_h3: unsupported packed layout")
    return (audio_start, audio_end), (video_start, video_end)


def _cleanup_prefetch(model):
    """cache 命中后丢弃 H3 block 预取队列（社区端口的 prefetch 清理，原样保留）。"""
    import comfy.model_prefetch
    queues = getattr(comfy.model_prefetch, "PREFETCH_QUEUES", ())
    block_ids = {id(block) for block in model.blocks}
    for queue in reversed(queues):
        if not any(id(entry[1][0] if isinstance(entry, tuple) else entry) in block_ids
                   for entry in queue if entry is not None):
            continue
        for entry in queue:
            if not isinstance(entry, tuple):
                continue
            module, comfy_modules = entry[1]
            if comfy_modules is not None:
                try:
                    comfy.model_prefetch.cleanup_prefetched_modules(module, comfy_modules)
                except TypeError:
                    comfy.model_prefetch.cleanup_prefetched_modules(comfy_modules)
        queue[:] = [None]
        return


def _video_grid_from_x(video_x, patch_size):
    return tuple((video_x.shape[index + 2] + p - 1) // p
                 for index, p in enumerate(patch_size))


def make_block0_patch():
    def block0_patch(args, extra_options):
        transformer_options = args["transformer_options"]
        controller = transformer_options.get(CONTROLLER_KEY)
        if controller is None:
            return extra_options["original_block"](args)
        model = transformer_options["sarcache_h3_model"]
        e_i = args["img"]
        t_emb = args["t_emb"]
        mod_segments = args["mod_segments"]
        layout = args["layout"]
        step_index = transformer_options["sarcache_h3_step"]
        sigma_v = float(transformer_options["sigmas"].flatten()[0])

        monitors = None
        if controller.needs_monitors:
            video_range, audio_range = _target_ranges(mod_segments)
            if controller.cfg.mode == "ecp":
                # EC-P 用 raw embed 行（未调制）作探针（官方 raw_input 语义）
                monitors = (e_i[video_range[0]:video_range[1]].detach().float(),
                            e_i[audio_range[0]:audio_range[1]].detach().float())
            else:
                grid = transformer_options["sarcache_h3_video_grid"]
                monitors = adapter.gate_monitors(
                    e_i, t_emb, mod_segments, model.blocks[0], video_range, audio_range,
                    grid, sigma_v, stride=controller.cfg.metric_stride)
                monitors = (monitors[0].detach(), monitors[1].detach())

        rec = controller.decide(step_index, sigma_v, monitors)

        if rec.decision == "reuse":
            if controller.is_output_level():
                raise _SkipBlocks(None, t_emb, mod_segments, layout, output_level=True)
            r_used, kind = controller.predict_residual(step_index)
            hidden = e_i + r_used.to(e_i.dtype)
            raise _SkipBlocks(hidden, t_emb, mod_segments, layout)
        # e_i 必须克隆：DiT block 就地变异 h（_mod_gate 的 addcmul_），
        # 直接引用会让残差 r_i = h_i − e_i 在同一块存储上退化为 0（S2 实测 bug）。
        transformer_options[_STASH_KEY] = {"e_i": e_i.detach().clone()}
        return extra_options["original_block"](args)
    return block0_patch


def make_blockN_patch():
    def blockN_patch(args, extra_options):
        out = extra_options["original_block"](args)
        stash = args["transformer_options"].get(_STASH_KEY)
        if stash is not None:
            stash["h_i"] = out["img"]
        return out
    return blockN_patch


def _diffusion_wrapper(executor, *args, **kwargs):
    transformer_options = args[3]
    controller = transformer_options.get(CONTROLLER_KEY)
    if controller is None:
        return executor(*args, **kwargs)

    model = executor.class_obj
    x = args[0]
    transformer_options["sarcache_h3_model"] = model
    if x[0].dim() == 5:
        transformer_options["sarcache_h3_video_grid"] = _video_grid_from_x(x[0], model.patch_size)

    step_index = getattr(controller, "_step_counter", 0)
    controller._step_counter = step_index + 1
    transformer_options["sarcache_h3_step"] = step_index

    t0 = time.perf_counter()
    try:
        out = executor(*args, **kwargs)
    except _SkipBlocks as hit:
        _cleanup_prefetch(model)
        if hit.output_level:
            # 输出级方法（teacache/taylor/ecp）：重放/外推缓存 velocity，无 head 重算
            out, _kind = controller.predict_output(step_index)
            _record_step(controller, transformer_options, time.perf_counter() - t0, reused=True)
            return out
        sigma_v = float(transformer_options["sigmas"].flatten()[0])
        shifts = (float(transformer_options.get("minimax_h3_sigma_shift_video", model.sigma_shift_video)),
                  float(transformer_options.get("minimax_h3_sigma_shift_audio", model.sigma_shift_audio)))
        sample_sigmas = transformer_options.get("sample_sigmas")
        out = adapter.reuse_epilogue(
            model, x, hit.hidden, hit.t_emb, hit.layout, hit.mod_segments,
            sigma_v, sample_sigmas, shifts, 1.0,
            patch_size=model.patch_size, latents_dim=model.latents_dim)
        _record_step(controller, transformer_options, time.perf_counter() - t0, reused=True)
        return out

    # full 路径：残差历史 + 输出级缓存（均只用真实全计算结果）
    stash = transformer_options.get(_STASH_KEY)
    if stash is not None and "h_i" in stash:
        controller.commit_full(step_index, (stash["h_i"] - stash["e_i"]).detach())
    if controller.is_output_level():
        controller.commit_full_output(step_index, out)
    _record_step(controller, transformer_options, time.perf_counter() - t0, reused=False)
    return out


def _record_step(controller, transformer_options, dt, reused):
    trace = getattr(controller, "step_trace", None)
    if trace is not None:
        sig = float(transformer_options["sigmas"].flatten()[0])
        trace.append({"sigma": sig, "reused": reused, "dt_wall": dt})


def install(model_patcher, controller):
    """clone patcher 并注册 patches/wrapper；controller 随即挂在克隆体的
    model_options transformer_options（每 run 由 runner 换新实例，状态零串扰）。"""
    import comfy.patcher_extension
    patched = model_patcher.clone()
    diffusion_model = patched.get_model_object("diffusion_model")
    n = len(diffusion_model.blocks)
    patched.set_model_patch_replace(make_block0_patch(), "dit", "double_block", 0)
    patched.set_model_patch_replace(make_blockN_patch(), "dit", "double_block", n - 1)
    patched.add_wrapper_with_key(
        comfy.patcher_extension.WrappersMP.DIFFUSION_MODEL, WRAPPER_KEY, _diffusion_wrapper)
    to = patched.model_options["transformer_options"] = \
        dict(patched.model_options.get("transformer_options", {}))
    to[CONTROLLER_KEY] = controller
    return patched
